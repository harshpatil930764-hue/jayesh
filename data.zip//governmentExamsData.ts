import { 
  Trophy, 
  FileText, 
  Users, 
  Calendar, 
  GraduationCap, 
  BookOpen, 
  Shield, 
  Train, 
  Building, 
  Heart,
  Briefcase,
  MapPin,
  School,
  Truck,
  Plane,
  Ship
} from 'lucide-react';

export interface CutOffData {
  category: string;
  cutoff2024: number | string;
  cutoff2023: number | string;
  cutoff2022: number | string;
  trend: 'up' | 'down' | 'stable';
  color: string;
}

export interface SyllabusSection {
  subject: string;
  topics: string[];
  marks: number;
  questions: number;
}

export interface ExamDetails {
  name: string;
  fullName: string;
  description: string;
  conductingBody: string;
  eligibility: {
    education: string;
    ageLimit: string;
    nationality: string;
    attempts?: string;
  };
  examDates: {
    notification: string;
    application: string;
    exam: string;
    result: string;
  };
  examPattern: {
    mode: string;
    stages: string[];
    duration: string;
    subjects: string[];
    totalMarks: string;
    negativeMarking: string;
  };
  syllabus: SyllabusSection[];
  salary: {
    range: string;
    allowances: string[];
    benefits: string[];
  };
  posts: {
    total: string;
    reservation: {
      general: string;
      obc: string;
      sc: string;
      st: string;
      ews: string;
    };
  };
  applicationFee: {
    general: string;
    reserved: string;
  };
  officialWebsite: string;
  importantInfo: string[];
  cutOffs?: CutOffData[];
  bgColor: string;
  accentColor: string;
  iconColor: string;
}

export interface ExamCategory {
  title: string;
  icon: any;
  exams: ExamDetails[];
  categoryColor: string;
  description: string;
}

export const examCategoriesData: ExamCategory[] = [
  {
    title: 'Central Government',
    icon: Trophy,
    categoryColor: 'from-indigo-500 to-purple-600',
    description: 'Central government exams conducted by UPSC, SSC, and other central agencies',
    exams: [
      {
        name: 'UPSC CSE',
        fullName: 'Union Public Service Commission - Civil Services Examination',
        description: 'Premier examination for recruitment to Indian Administrative Service, Indian Police Service, and other central services',
        conductingBody: 'Union Public Service Commission (UPSC)',
        bgColor: 'bg-gradient-to-br from-indigo-50 to-purple-50',
        accentColor: 'text-indigo-600',
        iconColor: 'text-indigo-500',
        eligibility: {
          education: 'Bachelor\'s degree from recognized university',
          ageLimit: '21-32 years (Gen), 21-35 (OBC), 21-37 (SC/ST)',
          nationality: 'Indian citizen',
          attempts: '6 attempts (Gen), 9 (OBC), Unlimited (SC/ST)'
        },
        examDates: {
          notification: 'February 2025',
          application: 'February - March 2025',
          exam: 'Prelims: June 2025, Mains: October 2025',
          result: 'Final Result: May 2026'
        },
        examPattern: {
          mode: 'Offline (OMR) for Prelims, Written for Mains, Interview',
          stages: ['Preliminary Exam', 'Main Examination', 'Personality Test (Interview)'],
          duration: 'Prelims: 4 hours, Mains: 9 papers, Interview: 45 minutes',
          subjects: ['General Studies', 'CSAT', 'Optional Subject', 'Essay', 'English', 'Hindi'],
          totalMarks: '2025 marks (Mains: 1750 + Interview: 275)',
          negativeMarking: 'Yes in Prelims (1/3 marks per wrong answer)'
        },
        syllabus: [
          {
            subject: 'General Studies Paper I',
            topics: ['History of India', 'Geography', 'Indian Polity', 'Economic and Social Development', 'Environmental Ecology', 'General Science'],
            marks: 200,
            questions: 100
          },
          {
            subject: 'General Studies Paper II (CSAT)',
            topics: ['Comprehension', 'Interpersonal skills', 'Logical reasoning', 'Analytical ability', 'Decision making', 'Problem solving', 'General mental ability', 'Basic numeracy', 'Data interpretation'],
            marks: 200,
            questions: 80
          }
        ],
        salary: {
          range: '₹56,100 - ₹2,50,000 per month',
          allowances: ['DA', 'HRA', 'TA', 'Medical Allowance'],
          benefits: ['Government Accommodation', 'Medical Facilities', 'Pension', 'LTC', 'Children Education Allowance']
        },
        posts: {
          total: '861 posts (2024)',
          reservation: {
            general: '42%',
            obc: '27%',
            sc: '15%',
            st: '7.5%',
            ews: '10%'
          }
        },
        applicationFee: {
          general: '₹100',
          reserved: '₹25 (SC/ST/PwD), ₹100 (Others)'
        },
        officialWebsite: 'upsc.gov.in',
        importantInfo: [
          'Most prestigious civil service examination in India',
          'Three-stage selection process with interview carrying 275 marks',
          'Optional subject choice is crucial for success',
          'Requires 12-18 months of dedicated preparation',
          'Current affairs and newspaper reading is essential',
          'Previous year toppers emphasize on answer writing practice'
        ],
        cutOffs: [
          { category: 'General', cutoff2024: '108.33', cutoff2023: '107.45', cutoff2022: '106.89', trend: 'up', color: 'bg-red-100 text-red-800' },
          { category: 'OBC-NCL', cutoff2024: '105.89', cutoff2023: '105.12', cutoff2022: '104.56', trend: 'up', color: 'bg-orange-100 text-orange-800' },
          { category: 'SC', cutoff2024: '101.23', cutoff2023: '100.78', cutoff2022: '100.34', trend: 'up', color: 'bg-green-100 text-green-800' },
          { category: 'ST', cutoff2024: '98.45', cutoff2023: '97.89', cutoff2022: '97.23', trend: 'up', color: 'bg-blue-100 text-blue-800' },
          { category: 'EWS', cutoff2024: '107.12', cutoff2023: '106.45', cutoff2022: '105.89', trend: 'up', color: 'bg-yellow-100 text-yellow-800' }
        ]
      },
      {
        name: 'SSC CGL',
        fullName: 'Staff Selection Commission - Combined Graduate Level',
        description: 'Combined examination for recruitment to Group B and Group C posts in various ministries/departments',
        conductingBody: 'Staff Selection Commission (SSC)',
        bgColor: 'bg-gradient-to-br from-blue-50 to-cyan-50',
        accentColor: 'text-blue-600',
        iconColor: 'text-blue-500',
        eligibility: {
          education: 'Bachelor\'s degree from recognized university',
          ageLimit: '18-32 years (varies by post)',
          nationality: 'Indian citizen',
          attempts: 'No limit on attempts'
        },
        examDates: {
          notification: 'April 2025',
          application: 'April - May 2025',
          exam: 'Tier-I: July 2025, Tier-II: October 2025',
          result: 'Final Result: January 2026'
        },
        examPattern: {
          mode: 'Computer Based Test (CBT)',
          stages: ['Tier-I', 'Tier-II', 'Tier-III (for some posts)', 'Document Verification'],
          duration: 'Tier-I: 1 hour, Tier-II: varies by paper',
          subjects: ['General Intelligence', 'General Awareness', 'Quantitative Aptitude', 'English Comprehension'],
          totalMarks: 'Tier-I: 200 marks, Tier-II: varies',
          negativeMarking: 'Yes (0.50 marks per wrong answer)'
        },
        syllabus: [
          {
            subject: 'General Intelligence & Reasoning',
            topics: ['Analogies', 'Similarities', 'Differences', 'Space visualization', 'Problem solving', 'Analysis', 'Judgment', 'Decision making', 'Visual memory', 'Discrimination', 'Observation', 'Relationship', 'Arithmetical reasoning', 'Verbal and figure classification'],
            marks: 50,
            questions: 25
          },
          {
            subject: 'General Awareness',
            topics: ['History', 'Geography', 'Polity', 'Economics', 'General Science', 'Current Affairs', 'Sports', 'Culture', 'Books and Authors', 'Important Days'],
            marks: 50,
            questions: 25
          },
          {
            subject: 'Quantitative Aptitude',
            topics: ['Number Systems', 'Computation of Whole Numbers', 'Decimals and Fractions', 'Percentage', 'Ratio and Proportion', 'Square roots', 'Averages', 'Interest', 'Profit and Loss', 'Discount', 'Partnership Business', 'Mixture and Alligation', 'Time and distance', 'Time and work', 'Basic algebraic identities', 'Linear equations', 'Graphs of Linear Equations', 'Triangle and its various kinds of centres', 'Congruence and similarity of triangles', 'Circle and its chords', 'tangents', 'angles subtended by chords of a circle', 'common tangents to two or more circles', 'Regular Polygons', 'Right Prism', 'Right Circular Cone', 'Right Circular Cylinder', 'Sphere', 'Heights and Distances', 'Histogram', 'Frequency polygon', 'Bar diagram & Pie chart', 'Hemispheres', 'Rectangular Parallelepiped', 'Trigonometric ratio', 'Degree and Radian Measures', 'Standard Identities', 'Complementary angles'],
            marks: 50,
            questions: 25
          },
          {
            subject: 'English Comprehension',
            topics: ['Spot the Error', 'Fill in the Blanks', 'Synonyms/Homonyms', 'Antonyms', 'Spellings/Detecting misspelled words', 'Idioms & Phrases', 'One word substitution', 'Improvement of Sentences', 'Active/Passive Voice of Verbs', 'Conversion into Direct/Indirect narration', 'Shuffling of Sentence parts', 'Shuffling of Sentences in a passage', 'Cloze Passage', 'Comprehension Passage'],
            marks: 50,
            questions: 25
          }
        ],
        salary: {
          range: '₹25,500 - ₹81,100 per month',
          allowances: ['DA', 'HRA', 'TA'],
          benefits: ['Medical facilities', 'Pension', 'LTC']
        },
        posts: {
          total: '17,727 posts (2024)',
          reservation: {
            general: '48.5%',
            obc: '27%',
            sc: '15%',
            st: '7.5%',
            ews: '10%'
          }
        },
        applicationFee: {
          general: '₹100',
          reserved: 'No fee for SC/ST/PwD/Women'
        },
        officialWebsite: 'ssc.nic.in',
        importantInfo: [
          'One of the most popular government exams in India',
          'Multiple posts across different ministries',
          'Good work-life balance compared to other government jobs',
          'Regular increments and promotions available',
          'Tier-II exam has different papers for different posts',
          'Physical documents verification is mandatory after selection'
        ],
        cutOffs: [
          { category: 'General', cutoff2024: '143.75', cutoff2023: '142.25', cutoff2022: '141.50', trend: 'up', color: 'bg-red-100 text-red-800' },
          { category: 'OBC', cutoff2024: '139.50', cutoff2023: '138.25', cutoff2022: '137.75', trend: 'up', color: 'bg-orange-100 text-orange-800' },
          { category: 'SC', cutoff2024: '125.25', cutoff2023: '124.50', cutoff2022: '123.75', trend: 'up', color: 'bg-green-100 text-green-800' },
          { category: 'ST', cutoff2024: '118.50', cutoff2023: '117.75', cutoff2022: '117.25', trend: 'up', color: 'bg-blue-100 text-blue-800' },
          { category: 'EWS', cutoff2024: '141.25', cutoff2023: '140.50', cutoff2022: '139.75', trend: 'up', color: 'bg-yellow-100 text-yellow-800' }
        ]
      }
    ]
  },
  {
    title: 'State PSC Exams',
    icon: MapPin,
    categoryColor: 'from-green-500 to-teal-600',
    description: 'State Public Service Commission examinations for administrative services in various states',
    exams: [
      {
        name: 'UPPSC PCS',
        fullName: 'Uttar Pradesh Public Service Commission - Provincial Civil Services',
        description: 'State civil services examination for administrative posts in Uttar Pradesh government',
        conductingBody: 'Uttar Pradesh Public Service Commission',
        bgColor: 'bg-gradient-to-br from-green-50 to-teal-50',
        accentColor: 'text-green-600',
        iconColor: 'text-green-500',
        eligibility: {
          education: 'Bachelor\'s degree from recognized university',
          ageLimit: '21-40 years (General), up to 45 (Reserved)',
          nationality: 'Indian citizen',
          attempts: 'No limit on attempts'
        },
        examDates: {
          notification: 'March 2025',
          application: 'March - April 2025',
          exam: 'Prelims: August 2025, Mains: December 2025',
          result: 'Final Result: July 2026'
        },
        examPattern: {
          mode: 'OMR for Prelims, Written for Mains, Interview',
          stages: ['Preliminary Examination', 'Main Examination', 'Interview'],
          duration: 'Prelims: 4 hours, Mains: 8 papers, Interview',
          subjects: ['General Studies', 'General Aptitude', 'Optional Subjects', 'Hindi'],
          totalMarks: '1500 marks (Mains: 1200 + Interview: 300)',
          negativeMarking: 'Yes in Prelims (1/3 marks deducted)'
        },
        syllabus: [
          {
            subject: 'General Studies Paper I',
            topics: ['History of India with special reference to UP', 'Geography of India with special reference to UP', 'Indian Polity and Governance', 'Economic and Social Development', 'General Science', 'Current Affairs'],
            marks: 200,
            questions: 150
          },
          {
            subject: 'General Studies Paper II',
            topics: ['General Mental Ability', 'General Science', 'General Hindi', 'Mathematics', 'Reasoning', 'Current Affairs'],
            marks: 200,
            questions: 100
          }
        ],
        salary: {
          range: '₹35,400 - ₁,12,400 per month',
          allowances: ['DA', 'HRA', 'TA', 'Medical'],
          benefits: ['Government quarters', 'Medical facilities', 'Pension', 'LTC']
        },
        posts: {
          total: '416 posts (2024)',
          reservation: {
            general: '48.5%',
            obc: '27%',
            sc: '21%',
            st: '2%',
            ews: '10%'
          }
        },
        applicationFee: {
          general: '₹125',
          reserved: '₹65 (SC/ST), ₹25 (PwD)'
        },
        officialWebsite: 'uppsc.up.nic.in',
        importantInfo: [
          'One of the largest state civil services in India',
          'UP specific questions carry significant weightage',
          'Hindi language paper is compulsory',
          'District Magistrate and SP level posts available',
          'Good career progression within state administration',
          'Local language advantage for UP residents'
        ],
        cutOffs: [
          { category: 'General', cutoff2024: '142.67', cutoff2023: '141.33', cutoff2022: '140.67', trend: 'up', color: 'bg-red-100 text-red-800' },
          { category: 'OBC', cutoff2024: '138.67', cutoff2023: '137.33', cutoff2022: '136.67', trend: 'up', color: 'bg-orange-100 text-orange-800' },
          { category: 'SC', cutoff2024: '128.00', cutoff2023: '127.33', cutoff2022: '126.67', trend: 'up', color: 'bg-green-100 text-green-800' },
          { category: 'ST', cutoff2024: '120.00', cutoff2023: '119.33', cutoff2022: '118.67', trend: 'up', color: 'bg-blue-100 text-blue-800' }
        ]
      },
      {
        name: 'MPSC State Services',
        fullName: 'Maharashtra Public Service Commission - State Services',
        description: 'State civil services examination for administrative posts in Maharashtra government',
        conductingBody: 'Maharashtra Public Service Commission',
        bgColor: 'bg-gradient-to-br from-emerald-50 to-green-50',
        accentColor: 'text-emerald-600',
        iconColor: 'text-emerald-500',
        eligibility: {
          education: 'Bachelor\'s degree from recognized university',
          ageLimit: '19-38 years (General), relaxation for reserved',
          nationality: 'Indian citizen',
          attempts: 'No limit on attempts'
        },
        examDates: {
          notification: 'February 2025',
          application: 'February - March 2025',
          exam: 'Prelims: June 2025, Mains: October 2025',
          result: 'Final Result: April 2026'
        },
        examPattern: {
          mode: 'OMR for Prelims, Written for Mains, Interview',
          stages: ['Preliminary Examination', 'Main Examination', 'Interview'],
          duration: 'Prelims: 4 hours, Mains: 6 papers, Interview',
          subjects: ['General Studies', 'Aptitude', 'Optional Subjects', 'Marathi'],
          totalMarks: '1200 marks (Mains: 1000 + Interview: 200)',
          negativeMarking: 'Yes in Prelims'
        },
        syllabus: [
          {
            subject: 'General Studies Paper I',
            topics: ['History with special reference to Maharashtra', 'Geography of Maharashtra and India', 'Indian Polity', 'Economics', 'General Science', 'Current Affairs'],
            marks: 200,
            questions: 100
          },
          {
            subject: 'General Aptitude Test',
            topics: ['Mental Ability', 'Logical Reasoning', 'Quantitative Aptitude', 'English Language', 'Marathi Language'],
            marks: 200,
            questions: 100
          }
        ],
        salary: {
          range: '₹36,200 - ₹1,14,800 per month',
          allowances: ['DA', 'HRA', 'TA'],
          benefits: ['Medical facilities', 'Pension', 'LTC', 'Government accommodation']
        },
        posts: {
          total: '761 posts (2024)',
          reservation: {
            general: '48%',
            obc: '19%',
            sc: '13%',
            st: '7%',
            ews: '10%'
          }
        },
        applicationFee: {
          general: '₹524',
          reserved: '₹324 (Reserved categories)'
        },
        officialWebsite: 'mpsc.gov.in',
        importantInfo: [
          'Maharashtra specific questions are important',
          'Marathi language knowledge is advantageous',
          'Good work opportunities in developed districts',
          'Regular recruitment drives conducted',
          'Group A and Group B services available',
          'Interview carries significant weightage'
        ],
        cutOffs: [
          { category: 'General', cutoff2024: '102.50', cutoff2023: '101.75', cutoff2022: '101.25', trend: 'up', color: 'bg-red-100 text-red-800' },
          { category: 'OBC', cutoff2024: '95.25', cutoff2023: '94.50', cutoff2022: '94.00', trend: 'up', color: 'bg-orange-100 text-orange-800' },
          { category: 'SC', cutoff2024: '85.75', cutoff2023: '85.00', cutoff2022: '84.50', trend: 'up', color: 'bg-green-100 text-green-800' },
          { category: 'ST', cutoff2024: '78.25', cutoff2023: '77.50', cutoff2022: '77.00', trend: 'up', color: 'bg-blue-100 text-blue-800' }
        ]
      }
    ]
  },
  {
    title: 'Railway Exams',
    icon: Train,
    categoryColor: 'from-blue-500 to-indigo-600',
    description: 'Railway Recruitment Board examinations for various technical and non-technical posts',
    exams: [
      {
        name: 'RRB NTPC',
        fullName: 'Railway Recruitment Board - Non-Technical Popular Categories',
        description: 'Recruitment for non-technical posts in Indian Railways including Station Master, Goods Guard, etc.',
        conductingBody: 'Railway Recruitment Board (RRB)',
        bgColor: 'bg-gradient-to-br from-blue-50 to-indigo-50',
        accentColor: 'text-blue-600',
        iconColor: 'text-blue-500',
        eligibility: {
          education: 'Graduate/12th pass depending on post',
          ageLimit: '18-33 years (varies by post and category)',
          nationality: 'Indian citizen',
          attempts: 'No limit'
        },
        examDates: {
          notification: 'Expected March 2025',
          application: 'March - April 2025',
          exam: 'CBT 1: June 2025, CBT 2: September 2025',
          result: 'Final Result: January 2026'
        },
        examPattern: {
          mode: 'Computer Based Test (CBT)',
          stages: ['CBT 1', 'CBT 2', 'Typing Skill Test/Computer Based Aptitude Test', 'Document Verification', 'Medical Examination'],
          duration: 'CBT 1: 90 minutes, CBT 2: 90 minutes',
          subjects: ['General Awareness', 'Mathematics', 'General Intelligence & Reasoning'],
          totalMarks: 'CBT 1: 100 marks, CBT 2: 120 marks',
          negativeMarking: 'Yes (1/3 marks deducted for wrong answer)'
        },
        syllabus: [
          {
            subject: 'General Awareness',
            topics: ['Current Affairs', 'Indian Geography', 'Culture and History of India', 'Indian Polity', 'Indian Economy', 'General Science', 'Environmental Studies', 'Sports'],
            marks: 40,
            questions: 40
          },
          {
            subject: 'Mathematics',
            topics: ['Number System', 'BODMAS', 'Decimals', 'Fractions', 'LCM, HCF', 'Ratio and Proportion', 'Percentages', 'Mensuration', 'Time and Work', 'Time and Distance', 'Simple and Compound Interest', 'Profit and Loss', 'Algebra', 'Geometry and Trigonometry', 'Elementary Statistics', 'Square Root', 'Age Calculations', 'Calendar & Clock', 'Pipes and Cistern'],
            marks: 30,
            questions: 30
          },
          {
            subject: 'General Intelligence and Reasoning',
            topics: ['Analogies', 'Alphabetical and Number Series', 'Coding and Decoding', 'Mathematical Operations', 'Similarities and Differences', 'Relationships', 'Analytical Reasoning', 'Syllogism', 'Jumbling', 'Venn Diagram', 'Puzzle', 'Data Sufficiency', 'Statement- Action', 'Statement- Argument', 'Statement- Assumption', 'Statement- Conclusion', 'Decision Making', 'Maps', 'Interpretation', 'Classification'],
            marks: 30,
            questions: 30
          }
        ],
        salary: {
          range: '₹19,900 - ₹63,200 per month',
          allowances: ['DA', 'HRA', 'Running Allowance', 'Night Duty Allowance'],
          benefits: ['Free/Subsidized travel', 'Medical facilities', 'Pension', 'Railway quarters']
        },
        posts: {
          total: '35,208 posts (Last recruitment)',
          reservation: {
            general: '48.5%',
            obc: '27%',
            sc: '15%',
            st: '7.5%',
            ews: '10%'
          }
        },
        applicationFee: {
          general: '₹500',
          reserved: '₹250 (SC/ST/PwD/Female/Transgender/Ex-servicemen/Minorities)'
        },
        officialWebsite: 'indianrailways.gov.in',
        importantInfo: [
          'One of the largest government recruitments in India',
          'Multiple chances with 21 RRBs conducting exams',
          'Good career progression opportunities in Railways',
          'Travel benefits for employees and family',
          'Job security with pension benefits',
          'Various posts from clerical to supervisory levels'
        ],
        cutOffs: [
          { category: 'General', cutoff2024: '78.43137', cutoff2023: '77.04348', cutoff2022: '76.52174', trend: 'up', color: 'bg-red-100 text-red-800' },
          { category: 'OBC-NCL', cutoff2024: '73.91304', cutoff2023: '72.82609', cutoff2022: '72.17391', trend: 'up', color: 'bg-orange-100 text-orange-800' },
          { category: 'SC', cutoff2024: '60.86957', cutoff2023: '59.78261', cutoff2022: '59.13043', trend: 'up', color: 'bg-green-100 text-green-800' },
          { category: 'ST', cutoff2024: '56.52174', cutoff2023: '55.65217', cutoff2022: '55.00000', trend: 'up', color: 'bg-blue-100 text-blue-800' }
        ]
      },
      {
        name: 'RRB Group D',
        fullName: 'Railway Recruitment Board - Group D',
        description: 'Recruitment for Level 1 posts in Indian Railways including Track Maintainer, Helper, etc.',
        conductingBody: 'Railway Recruitment Board (RRB)',
        bgColor: 'bg-gradient-to-br from-cyan-50 to-blue-50',
        accentColor: 'text-cyan-600',
        iconColor: 'text-cyan-500',
        eligibility: {
          education: '10th pass with ITI or 12th pass',
          ageLimit: '18-33 years (relaxation for reserved categories)',
          nationality: 'Indian citizen',
          attempts: 'No limit'
        },
        examDates: {
          notification: 'Expected April 2025',
          application: 'April - May 2025',
          exam: 'CBT: August 2025',
          result: 'Final Result: December 2025'
        },
        examPattern: {
          mode: 'Computer Based Test (CBT)',
          stages: ['CBT', 'Physical Efficiency Test', 'Document Verification', 'Medical Examination'],
          duration: '90 minutes',
          subjects: ['General Science', 'Mathematics', 'General Intelligence & Reasoning', 'General Awareness'],
          totalMarks: '100 marks',
          negativeMarking: 'Yes (1/3 marks deducted)'
        },
        syllabus: [
          {
            subject: 'General Science',
            topics: ['Physics', 'Chemistry', 'Life Sciences (Biology) up to 10th standard'],
            marks: 25,
            questions: 25
          },
          {
            subject: 'Mathematics',
            topics: ['Number System', 'BODMAS', 'Decimals', 'Fractions', 'LCM, HCF', 'Ratio and Proportion', 'Percentages', 'Mensuration', 'Time and Work', 'Time and Distance', 'Simple and Compound Interest', 'Profit and Loss', 'Algebra', 'Geometry', 'Trigonometry', 'Elementary Statistics', 'Square Root', 'Age Calculations', 'Calendar & Clock'],
            marks: 25,
            questions: 25
          },
          {
            subject: 'General Intelligence and Reasoning',
            topics: ['Analogies', 'Alphabetical and Number Series', 'Coding and Decoding', 'Mathematical Operations', 'Similarities and Differences', 'Relationships', 'Analytical Reasoning', 'Syllogism', 'Jumbling', 'Venn Diagram', 'Puzzle', 'Data Sufficiency', 'Statement-Conclusion', 'Decision Making', 'Maps', 'Classification'],
            marks: 30,
            questions: 30
          },
          {
            subject: 'General Awareness and Current Affairs',
            topics: ['Science & Technology', 'Sports', 'Culture', 'Personalities', 'Economics', 'Politics', 'Current Affairs', 'History', 'Geography'],
            marks: 20,
            questions: 20
          }
        ],
        salary: {
          range: '₹18,000 - ₹56,900 per month',
          allowances: ['DA', 'HRA', 'Running Allowance'],
          benefits: ['Free/Subsidized travel', 'Medical facilities', 'Pension', 'Railway quarters']
        },
        posts: {
          total: '1,03,769 posts (Last recruitment)',
          reservation: {
            general: '48.5%',
            obc: '27%',
            sc: '15%',
            st: '7.5%',
            ews: '10%'
          }
        },
        applicationFee: {
          general: '₹500',
          reserved: '₹250 (SC/ST/PwD/Female/Ex-servicemen/Minorities)'
        },
        officialWebsite: 'indianrailways.gov.in',
        importantInfo: [
          'Largest recruitment in Railway Group D category',
          'Physical Efficiency Test is mandatory',
          'Basic qualification sufficient for application',
          'Job security with government benefits',
          'Opportunities for promotion to higher grades',
          'Posted across all railway zones in India'
        ],
        cutOffs: [
          { category: 'General', cutoff2024: '68.23529', cutoff2023: '67.05882', cutoff2022: '66.47059', trend: 'up', color: 'bg-red-100 text-red-800' },
          { category: 'OBC-NCL', cutoff2024: '64.11765', cutoff2023: '63.23529', cutoff2022: '62.64706', trend: 'up', color: 'bg-orange-100 text-orange-800' },
          { category: 'SC', cutoff2024: '52.94118', cutoff2023: '52.05882', cutoff2022: '51.47059', trend: 'up', color: 'bg-green-100 text-green-800' },
          { category: 'ST', cutoff2024: '47.05882', cutoff2023: '46.47059', cutoff2022: '45.88235', trend: 'up', color: 'bg-blue-100 text-blue-800' }
        ]
      }
    ]
  },
  {
    title: 'Banking Exams',
    icon: Building,
    categoryColor: 'from-emerald-500 to-green-600',
    description: 'Banking sector examinations for various officer and clerk positions',
    exams: [
      {
        name: 'IBPS PO',
        fullName: 'Institute of Banking Personnel Selection - Probationary Officer',
        description: 'Common recruitment process for Probationary Officers in public sector banks',
        conductingBody: 'Institute of Banking Personnel Selection',
        bgColor: 'bg-gradient-to-br from-emerald-50 to-green-50',
        accentColor: 'text-emerald-600',
        iconColor: 'text-emerald-500',
        eligibility: {
          education: 'Bachelor\'s degree in any discipline with minimum 60%',
          ageLimit: '20-30 years',
          nationality: 'Indian citizen',
          attempts: 'No limit on attempts'
        },
        examDates: {
          notification: 'August 2025',
          application: 'August - September 2025',
          exam: 'Prelims: October 2025, Mains: November 2025',
          result: 'Final Result: March 2026'
        },
        examPattern: {
          mode: 'Computer Based Test + Interview',
          stages: ['Preliminary Examination', 'Main Examination', 'Interview'],
          duration: 'Prelims: 1 hour, Mains: 3 hours, Interview: 30 minutes',
          subjects: ['English Language', 'Quantitative Aptitude', 'Reasoning Ability', 'General Awareness', 'Computer Knowledge'],
          totalMarks: 'Prelims: 100, Mains: 200, Interview: 100',
          negativeMarking: 'Yes (0.25 marks for each wrong answer)'
        },
        syllabus: [
          {
            subject: 'English Language',
            topics: ['Reading Comprehension', 'Cloze Test', 'Para Jumbles', 'Spotting Errors', 'Sentence Improvement', 'Fill in the Blanks', 'Multiple Meaning/Error Spotting', 'Paragraph Completion'],
            marks: 30,
            questions: 30
          },
          {
            subject: 'Quantitative Aptitude',
            topics: ['Simplification', 'Profit & Loss', 'Mixtures & Allegations', 'Simple Interest & Compound Interest', 'Time & Work', 'Time & Distance', 'Percentage', 'Ratio & Proportion', 'Average', 'Age Problems', 'Mensuration', 'Data Interpretation', 'Quadratic Equations', 'Number Series', 'Probability'],
            marks: 35,
            questions: 35
          },
          {
            subject: 'Reasoning Ability',
            topics: ['Logical Reasoning', 'Alphanumeric Series', 'Ranking/Direction/Alphabet Test', 'Data Sufficiency', 'Coded Inequalities', 'Seating Arrangement', 'Puzzle', 'Tabulation', 'Syllogism', 'Blood Relations', 'Input Output', 'Coding Decoding'],
            marks: 35,
            questions: 35
          }
        ],
        salary: {
          range: '₹23,700 - ₹42,020 per month (Starting: ₹57,000 approx)',
          allowances: ['DA', 'HRA', 'CCA', 'Special Allowance', 'Medical'],
          benefits: ['LFC', 'Medical for family', 'Pension', 'Gratuity', 'Loan facilities']
        },
        posts: {
          total: '4,135 posts (2024)',
          reservation: {
            general: '49.5%',
            obc: '27%',
            sc: '15%',
            st: '7.5%',
            ews: '10%'
          }
        },
        applicationFee: {
          general: '₹775',
          reserved: '₹175 (SC/ST/PwD)'
        },
        officialWebsite: 'ibps.in',
        importantInfo: [
          'Common process for 12 public sector banks',
          'Probationary period of 2 years',
          'Good career progression to managerial levels',
          'Bank-wise allocation based on preference and merit',
          'Interview carries significant weightage (100 marks)',
          'Current affairs especially banking awareness important'
        ],
        cutOffs: [
          { category: 'General', cutoff2024: '82.50', cutoff2023: '81.75', cutoff2022: '81.25', trend: 'up', color: 'bg-red-100 text-red-800' },
          { category: 'OBC', cutoff2024: '79.25', cutoff2023: '78.50', cutoff2022: '78.00', trend: 'up', color: 'bg-orange-100 text-orange-800' },
          { category: 'SC', cutoff2024: '74.50', cutoff2023: '73.75', cutoff2022: '73.25', trend: 'up', color: 'bg-green-100 text-green-800' },
          { category: 'ST', cutoff2024: '69.75', cutoff2023: '69.00', cutoff2022: '68.50', trend: 'up', color: 'bg-blue-100 text-blue-800' },
          { category: 'EWS', cutoff2024: '80.75', cutoff2023: '80.00', cutoff2022: '79.50', trend: 'up', color: 'bg-yellow-100 text-yellow-800' }
        ]
      },
      {
        name: 'SBI PO',
        fullName: 'State Bank of India - Probationary Officer',
        description: 'Recruitment for Probationary Officers in State Bank of India',
        conductingBody: 'State Bank of India',
        bgColor: 'bg-gradient-to-br from-teal-50 to-emerald-50',
        accentColor: 'text-teal-600',
        iconColor: 'text-teal-500',
        eligibility: {
          education: 'Graduation in any discipline with minimum 60%',
          ageLimit: '21-30 years',
          nationality: 'Indian citizen',
          attempts: 'No limit on attempts'
        },
        examDates: {
          notification: 'March 2025',
          application: 'March - April 2025',
          exam: 'Prelims: June 2025, Mains: August 2025',
          result: 'Final Result: November 2025'
        },
        examPattern: {
          mode: 'Online CBT + Group Exercise + Interview',
          stages: ['Preliminary Examination', 'Main Examination', 'Group Exercise & Interview'],
          duration: 'Prelims: 1 hour, Mains: 3 hours',
          subjects: ['English Language', 'Quantitative Aptitude', 'Reasoning Ability', 'General/Economy/Banking Awareness', 'Data Analysis & Interpretation'],
          totalMarks: 'Prelims: 100, Mains: 200, GE & Interview: 50',
          negativeMarking: 'Yes (0.25 marks deducted)'
        },
        syllabus: [
          {
            subject: 'Reasoning & Computer Aptitude',
            topics: ['Logical Reasoning', 'Alphanumeric Series', 'Ranking/Direction/Alphabet Test', 'Data Sufficiency', 'Coded Inequalities', 'Seating Arrangement', 'Puzzle', 'Tabulation', 'Syllogism', 'Blood Relations', 'Input Output', 'Coding Decoding', 'Computer Terminology', 'Internet', 'MS Office', 'Networking', 'Computer Software and Hardware', 'Computer Abbreviations'],
            marks: 45,
            questions: 45
          },
          {
            subject: 'Data Analysis & Interpretation',
            topics: ['Tabulation', 'Bar Graph', 'Line Chart', 'Pie Chart', 'Probability', 'Permutation and Combination', 'Simple Interest & Compound Interest', 'Partnership', 'Percentage', 'Ratio & Proportion', 'Average', 'Time & Work', 'Mensuration', 'Sequence & Series', 'Quadratic Equations'],
            marks: 35,
            questions: 35
          },
          {
            subject: 'General/Economy/Banking Awareness',
            topics: ['Banking Awareness', 'Indian Financial System', 'Current Affairs (Last 6 months)', 'Indian Economy', 'International Economics', 'Government Schemes', 'Budget', 'RBI Functions', 'Banking Terms', 'Capital Market', 'Insurance'],
            marks: 40,
            questions: 40
          }
        ],
        salary: {
          range: '₹27,620 - ₹54,500 per month (Starting: ₹64,000 approx)',
          allowances: ['DA', 'HRA', 'CCA', 'Special Allowance', 'Medical'],
          benefits: ['LFC', 'Medical insurance', 'Pension', 'Housing loan', 'Car loan']
        },
        posts: {
          total: '2,280 posts (2024)',
          reservation: {
            general: '49.5%',
            obc: '27%',
            sc: '15%',
            st: '7.5%',
            ews: '10%'
          }
        },
        applicationFee: {
          general: '₹750',
          reserved: '₹125 (SC/ST/PwD)'
        },
        officialWebsite: 'sbi.co.in/careers',
        importantInfo: [
          'India\'s largest bank with extensive network',
          'Group Exercise is unique to SBI PO selection',
          'Better salary structure compared to other PSBs',
          'Fast track career progression opportunities',
          'Pan India posting during probation',
          'Strong alumni network in banking sector'
        ],
        cutOffs: [
          { category: 'General', cutoff2024: '78.25', cutoff2023: '77.50', cutoff2022: '77.00', trend: 'up', color: 'bg-red-100 text-red-800' },
          { category: 'OBC', cutoff2024: '75.00', cutoff2023: '74.25', cutoff2022: '73.75', trend: 'up', color: 'bg-orange-100 text-orange-800' },
          { category: 'SC', cutoff2024: '68.50', cutoff2023: '67.75', cutoff2022: '67.25', trend: 'up', color: 'bg-green-100 text-green-800' },
          { category: 'ST', cutoff2024: '63.75', cutoff2023: '63.00', cutoff2022: '62.50', trend: 'up', color: 'bg-blue-100 text-blue-800' },
          { category: 'EWS', cutoff2024: '76.50', cutoff2023: '75.75', cutoff2022: '75.25', trend: 'up', color: 'bg-yellow-100 text-yellow-800' }
        ]
      }
    ]
  },
  {
    title: 'Defense Services',
    icon: Shield,
    categoryColor: 'from-red-500 to-orange-600',
    description: 'Defense recruitment examinations for Army, Navy, and Air Force',
    exams: [
      {
        name: 'NDA',
        fullName: 'National Defence Academy',
        description: 'Joint training academy for Army, Navy and Air Force officers',
        conductingBody: 'Union Public Service Commission (UPSC)',
        bgColor: 'bg-gradient-to-br from-red-50 to-orange-50',
        accentColor: 'text-red-600',
        iconColor: 'text-red-500',
        eligibility: {
          education: '12th pass (Any stream for Army/Navy, PCM for Air Force)',
          ageLimit: '16.5-19.5 years',
          nationality: 'Indian citizen',
          attempts: 'No limit until age limit'
        },
        examDates: {
          notification: 'December 2024 & June 2025',
          application: 'December-January & June-July 2025',
          exam: 'April & September 2025',
          result: 'June & November 2025'
        },
        examPattern: {
          mode: 'OMR (Offline) + SSB Interview',
          stages: ['Written Examination', 'SSB Interview', 'Medical Examination'],
          duration: 'GAT: 2.5 hours, Maths: 2.5 hours',
          subjects: ['General Ability Test', 'Mathematics'],
          totalMarks: '900 marks (GAT: 600, Maths: 300)',
          negativeMarking: 'Yes (1/3 marks deducted for wrong answer)'
        },
        syllabus: [
          {
            subject: 'Mathematics',
            topics: ['Algebra', 'Matrices and Determinants', 'Trigonometry', 'Analytical Geometry of two and three dimensions', 'Differential Calculus', 'Integral Calculus and Differential Equations', 'Vector Algebra', 'Statistics and Probability'],
            marks: 300,
            questions: 120
          },
          {
            subject: 'General Ability Test',
            topics: ['English (Grammar, Vocabulary, Comprehension)', 'General Knowledge (Physics, Chemistry, General Science, History, Geography, Current Events)'],
            marks: 600,
            questions: 150
          }
        ],
        salary: {
          range: '₹56,100 - ₹1,77,500 per month (as Lieutenant)',
          allowances: ['DA', 'Field Area Allowance', 'Transport Allowance', 'Kit Maintenance'],
          benefits: ['CSD facilities', 'Medical for family', 'Pension', 'Accommodation', 'Leave Travel Concession']
        },
        posts: {
          total: '395 posts (2024)',
          reservation: {
            general: '50%',
            obc: '27%',
            sc: '15%',
            st: '7.5%',
            ews: 'No reservation'
          }
        },
        applicationFee: {
          general: '₹100',
          reserved: '₹25 (SC/ST), ₹100 (Others)'
        },
        officialWebsite: 'upsc.gov.in',
        importantInfo: [
          'Prestigious tri-service academy training',
          'Three years training at NDA Khadakwasla',
          'Commission as Lieutenant/Sub-Lieutenant/Flying Officer',
          'Only unmarried male candidates eligible',
          'Physical fitness standards must be met',
          'SSB interview process spans 5 days'
        ],
        cutOffs: [
          { category: 'General', cutoff2024: '425', cutoff2023: '420', cutoff2022: '415', trend: 'up', color: 'bg-red-100 text-red-800' },
          { category: 'OBC', cutoff2024: '395', cutoff2023: '390', cutoff2022: '385', trend: 'up', color: 'bg-orange-100 text-orange-800' },
          { category: 'SC', cutoff2024: '365', cutoff2023: '360', cutoff2022: '355', trend: 'up', color: 'bg-green-100 text-green-800' },
          { category: 'ST', cutoff2024: '335', cutoff2023: '330', cutoff2022: '325', trend: 'up', color: 'bg-blue-100 text-blue-800' }
        ]
      }
    ]
  },
  {
    title: 'Teaching Exams',
    icon: School,
    categoryColor: 'from-purple-500 to-pink-600',
    description: 'Teaching eligibility and recruitment examinations',
    exams: [
      {
        name: 'CTET',
        fullName: 'Central Teacher Eligibility Test',
        description: 'National level teacher eligibility test for teaching in central government schools',
        conductingBody: 'Central Board of Secondary Education (CBSE)',
        bgColor: 'bg-gradient-to-br from-purple-50 to-pink-50',
        accentColor: 'text-purple-600',
        iconColor: 'text-purple-500',
        eligibility: {
          education: 'Senior Secondary + Diploma in Elementary Education/B.Ed',
          ageLimit: 'No age limit',
          nationality: 'Indian citizen',
          attempts: 'No limit on attempts'
        },
        examDates: {
          notification: 'May & October 2025',
          application: 'May-June & October-November 2025',
          exam: 'July & December 2025',
          result: 'September & February 2026'
        },
        examPattern: {
          mode: 'Computer Based Test (CBT)',
          stages: ['Paper I (Classes I-V)', 'Paper II (Classes VI-VIII)'],
          duration: '2.5 hours each paper',
          subjects: ['Child Development & Pedagogy', 'Language I & II', 'Mathematics/Science/Social Studies'],
          totalMarks: '150 marks each paper',
          negativeMarking: 'No negative marking'
        },
        syllabus: [
          {
            subject: 'Child Development and Pedagogy',
            topics: ['Development of child', 'Concept of Inclusive education', 'Learning and Pedagogy', 'Individual differences', 'Learning difficulties', 'Talented and creative children'],
            marks: 30,
            questions: 30
          },
          {
            subject: 'Language I (Hindi)',
            topics: ['Language Comprehension', 'Language Development', 'Language Skills', 'Pedagogy of Language Development'],
            marks: 30,
            questions: 30
          },
          {
            subject: 'Language II (English)',
            topics: ['Comprehension', 'Language Development', 'Language Skills', 'Pedagogy of Language Development'],
            marks: 30,
            questions: 30
          },
          {
            subject: 'Mathematics and Science/Social Studies',
            topics: ['Mathematics: Number System, Algebra, Geometry, Mensuration, Data Handling, Pedagogy', 'Science: Food, Materials, World of Living, Moving Things, Natural Phenomena, Pedagogy', 'Social Studies: History, Geography, Social and Political Life, Pedagogy'],
            marks: 60,
            questions: 60
          }
        ],
        salary: {
          range: '₹35,400 - ₹1,12,400 per month',
          allowances: ['DA', 'HRA', 'TA'],
          benefits: ['Medical facilities', 'Pension', 'LTC', 'Maternity/Paternity leave']
        },
        posts: {
          total: 'Ongoing recruitment (Various schools)',
          reservation: {
            general: '50%',
            obc: '27%',
            sc: '15%',
            st: '7.5%',
            ews: '10%'
          }
        },
        applicationFee: {
          general: '₹1000 (One paper), ₹1200 (Both papers)',
          reserved: '₹500 (One paper), ₹600 (Both papers) for SC/ST'
        },
        officialWebsite: 'ctet.nic.in',
        importantInfo: [
          'Mandatory for teaching in central government schools',
          'Certificate valid for 7 years from declaration date',
          'Can appear for both papers in same sitting',
          'Qualifying marks: 60% (90 out of 150)',
          'No limit on number of attempts',
          'State TET also conducted by various states'
        ],
        cutOffs: [
          { category: 'All Categories', cutoff2024: '90', cutoff2023: '90', cutoff2022: '90', trend: 'stable', color: 'bg-green-100 text-green-800' }
        ]
      }
    ]
  },
  {
    title: 'Police Exams',
    icon: Shield,
    categoryColor: 'from-amber-500 to-yellow-600',
    description: 'State and central police force recruitment examinations',
    exams: [
      {
        name: 'UP Police Constable',
        fullName: 'Uttar Pradesh Police Constable Recruitment',
        description: 'Recruitment for Constable posts in Uttar Pradesh Police',
        conductingBody: 'Uttar Pradesh Police Recruitment & Promotion Board',
        bgColor: 'bg-gradient-to-br from-amber-50 to-yellow-50',
        accentColor: 'text-amber-600',
        iconColor: 'text-amber-500',
        eligibility: {
          education: '12th pass from recognized board',
          ageLimit: '18-22 years (relaxation for reserved categories)',
          nationality: 'Indian citizen',
          attempts: 'No limit on attempts'
        },
        examDates: {
          notification: 'Expected June 2025',
          application: 'June - July 2025',
          exam: 'September 2025',
          result: 'November 2025'
        },
        examPattern: {
          mode: 'Computer Based Test (CBT)',
          stages: ['Written Examination', 'Document Verification', 'Physical Efficiency Test', 'Medical Examination'],
          duration: '2 hours',
          subjects: ['General Hindi', 'Law/Constitution', 'General Knowledge', 'Numerical & Mental Ability', 'Mental Aptitude/IQ/Reasoning Ability'],
          totalMarks: '300 marks',
          negativeMarking: 'Yes (0.25 marks deducted)'
        },
        syllabus: [
          {
            subject: 'General Hindi',
            topics: ['Hindi Grammar', 'Vocabulary', 'Sentence Formation', 'Synonyms and Antonyms', 'Comprehension', 'Letter Writing'],
            marks: 75,
            questions: 75
          },
          {
            subject: 'Law/Constitution',
            topics: ['Indian Constitution', 'Indian Penal Code', 'Criminal Procedure Code', 'Juvenile Justice Act', 'Rights of Women and Children', 'Traffic Rules'],
            marks: 75,
            questions: 75
          },
          {
            subject: 'General Knowledge',
            topics: ['Current Affairs', 'History of India', 'Geography', 'Indian Economy', 'General Science', 'Sports', 'Arts and Culture'],
            marks: 75,
            questions: 75
          },
          {
            subject: 'Numerical & Mental Ability',
            topics: ['Number System', 'Simplification', 'Percentage', 'Ratio and Proportion', 'Average', 'Time and Work', 'Time and Distance', 'Simple and Compound Interest', 'Profit and Loss'],
            marks: 75,
            questions: 75
          }
        ],
        salary: {
          range: '₹21,700 - ₹69,100 per month',
          allowances: ['DA', 'HRA', 'Uniform Allowance', 'Washing Allowance'],
          benefits: ['Medical facilities', 'Pension', 'Group insurance', 'Housing facilities']
        },
        posts: {
          total: '60,244 posts (2023)',
          reservation: {
            general: '48%',
            obc: '27%',
            sc: '21%',
            st: '2%',
            ews: '10%'
          }
        },
        applicationFee: {
          general: '₹400',
          reserved: '₹200 (SC/ST)'
        },
        officialWebsite: 'uppbpb.gov.in',
        importantInfo: [
          'Largest police recruitment in India',
          'Physical Efficiency Test includes running, high jump, long jump',
          'Hindi language proficiency is essential',
          'Medical standards as per police manual',
          'Character verification is mandatory',
          'Training period of approximately 6 months'
        ],
        cutOffs: [
          { category: 'General Male', cutoff2024: '225', cutoff2023: '220', cutoff2022: '218', trend: 'up', color: 'bg-red-100 text-red-800' },
          { category: 'General Female', cutoff2024: '245', cutoff2023: '240', cutoff2022: '238', trend: 'up', color: 'bg-pink-100 text-pink-800' },
          { category: 'OBC Male', cutoff2024: '210', cutoff2023: '205', cutoff2022: '203', trend: 'up', color: 'bg-orange-100 text-orange-800' },
          { category: 'SC Male', cutoff2024: '185', cutoff2023: '180', cutoff2022: '178', trend: 'up', color: 'bg-green-100 text-green-800' },
          { category: 'ST Male', cutoff2024: '170', cutoff2023: '165', cutoff2022: '163', trend: 'up', color: 'bg-blue-100 text-blue-800' }
        ]
      }
    ]
  }
];