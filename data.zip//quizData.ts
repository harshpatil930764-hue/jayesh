export const quizQuestions = [
  {
    question: "What type of activities do you enjoy most?",
    options: [
      { value: "science", label: "Conducting experiments and solving problems" },
      { value: "commerce", label: "Managing money and business activities" },
      { value: "arts", label: "Creative writing, art, and social activities" }
    ]
  },
  {
    question: "Which subjects did you perform best in during school?",
    options: [
      { value: "science", label: "Mathematics, Physics, Chemistry, Biology" },
      { value: "commerce", label: "Mathematics, Economics, Accountancy" },
      { value: "arts", label: "History, Geography, Political Science, Languages" }
    ]
  },
  {
    question: "What kind of work environment appeals to you?",
    options: [
      { value: "science", label: "Research labs, hospitals, tech companies" },
      { value: "commerce", label: "Corporate offices, banks, business firms" },
      { value: "arts", label: "Creative studios, government offices, media houses" }
    ]
  },
  {
    question: "Which career goal motivates you most?",
    options: [
      { value: "science", label: "Making scientific discoveries or innovations" },
      { value: "commerce", label: "Building successful businesses or managing finances" },
      { value: "arts", label: "Serving society or expressing creativity" }
    ]
  }
];

export const quizRecommendations = {
  science: {
    title: "Science Stream",
    description: "Based on your interests, Science stream would be perfect for you! You show aptitude for analytical thinking and problem-solving.",
    careers: ["Engineering", "Medical", "Research", "Data Science", "Biotechnology"]
  },
  commerce: {
    title: "Commerce Stream", 
    description: "Commerce stream aligns well with your interests! You have a good understanding of business and financial concepts.",
    careers: ["CA/CS", "MBA", "Banking", "Economics", "Digital Marketing"]
  },
  arts: {
    title: "Arts/Humanities Stream",
    description: "Arts stream would suit you well! You show interest in creative and social activities with good communication skills.",
    careers: ["Civil Services", "Law", "Journalism", "Psychology", "Teaching"]
  }
};