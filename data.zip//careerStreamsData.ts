import { Microscope, Calculator, Palette, GraduationCap, Briefcase, Heart } from 'lucide-react';

export interface StreamOption {
  name: string;
  description: string;
  entranceExams: string[];
  averageSalary: string;
  jobProspects: string;
}

export interface StreamData {
  title: string;
  icon: any;
  description: string;
  eligibility: string;
  duration: string;
  careers: StreamOption[];
  scope: string;
  color: string;
  advantages: string[];
  challenges: string[];
  bestFor: string[];
}

export const streamsData: StreamData[] = [
  {
    title: 'Science Stream (PCM/PCB)',
    icon: Microscope,
    description: 'Perfect for those interested in research, technology, innovation, and healthcare',
    eligibility: 'Minimum 60% in 10th grade with strong foundation in Maths and Science',
    duration: '2 years (11th & 12th)',
    careers: [
      {
        name: 'Engineering (PCM)',
        description: 'Design, build, and maintain technical systems and infrastructure',
        entranceExams: ['JEE Main', 'JEE Advanced', 'BITSAT', 'MHT CET', 'WBJEE', 'KCET'],
        averageSalary: '₹3-25 LPA',
        jobProspects: 'Excellent - High demand in IT, manufacturing, construction, automotive'
      },
      {
        name: 'Medical (PCB)',
        description: 'Healthcare professionals including doctors, dentists, nurses, pharmacists',
        entranceExams: ['NEET UG', 'AIIMS', 'JIPMER', 'State Medical Entrance Tests'],
        averageSalary: '₹6-50 LPA',
        jobProspects: 'Outstanding - Always in demand, respected profession, job security'
      },
      {
        name: 'BSc Programs',
        description: 'Specialized bachelor\'s degrees in various science subjects',
        entranceExams: ['University Entrance Tests', 'Merit-based admission', 'CUCET', 'BHU UET'],
        averageSalary: '₹2.5-8 LPA',
        jobProspects: 'Good - Research, teaching, industry jobs, higher studies options'
      },
      {
        name: 'Architecture',
        description: 'Design and plan buildings, spaces, and urban environments',
        entranceExams: ['NATA', 'JEE Main Paper 2', 'CEED'],
        averageSalary: '₹3-15 LPA',
        jobProspects: 'Good - Growing construction industry, creative field'
      },
      {
        name: 'Data Science & AI',
        description: 'Emerging field focused on data analysis and artificial intelligence',
        entranceExams: ['JEE Main', 'University Entrance Tests', 'Merit-based'],
        averageSalary: '₹5-30 LPA',
        jobProspects: 'Excellent - High growth field, tech companies, startups'
      },
      {
        name: 'Biotechnology',
        description: 'Application of technology in biological systems and living organisms',
        entranceExams: ['JEE Main', 'NEET', 'University Tests'],
        averageSalary: '₹3-12 LPA',
        jobProspects: 'Good - Pharmaceutical, research, agriculture, healthcare sectors'
      }
    ],
    scope: 'Highest demand with excellent growth opportunities across multiple sectors',
    color: 'bg-blue-50 border-blue-200',
    advantages: [
      'Wide range of career options',
      'High salary potential',
      'Job security and stability',
      'Opportunities for innovation and research',
      'Global career prospects',
      'Respected professions in society'
    ],
    challenges: [
      'Highly competitive entrance exams',
      'Requires strong mathematical and analytical skills',
      'Extensive study hours and preparation needed',
      'Pressure to perform well in competitive exams',
      'May require additional coaching expenses'
    ],
    bestFor: [
      'Students with strong analytical and logical thinking',
      'Those interested in problem-solving',
      'Students who enjoy mathematics and science subjects',
      'Individuals seeking high-paying technical careers',
      'Those interested in research and innovation'
    ]
  },
  {
    title: 'Commerce Stream',
    icon: Calculator,
    description: 'Ideal for business-minded individuals and financial enthusiasts',
    eligibility: 'Minimum 50% in 10th grade, good in mathematics and logical reasoning',
    duration: '2 years (11th & 12th)',
    careers: [
      {
        name: 'Chartered Accountancy (CA)',
        description: 'Financial expertise in auditing, taxation, and business advisory',
        entranceExams: ['CA Foundation', 'Direct Entry to Intermediate'],
        averageSalary: '₹6-25 LPA',
        jobProspects: 'Excellent - High demand, independent practice options, corporate roles'
      },
      {
        name: 'Bachelor of Commerce (BCom)',
        description: 'Comprehensive business and commerce education',
        entranceExams: ['DU JAT', 'IPU CET', 'University Merit Lists', 'CUET'],
        averageSalary: '₹2.5-8 LPA',
        jobProspects: 'Good - Banking, finance, accounting, government jobs'
      },
      {
        name: 'Bachelor of Business Administration (BBA)',
        description: 'Management and leadership skills for business careers',
        entranceExams: ['IPU CET', 'NPAT', 'SET', 'University Tests'],
        averageSalary: '₹3-10 LPA',
        jobProspects: 'Good - Management roles, entrepreneurship, MBA preparation'
      },
      {
        name: 'Company Secretary (CS)',
        description: 'Corporate legal and compliance expertise',
        entranceExams: ['CS Foundation', 'Direct Entry available'],
        averageSalary: '₹4-15 LPA',
        jobProspects: 'Good - Corporate sector, legal compliance, independent practice'
      },
      {
        name: 'Cost and Management Accountant (CMA)',
        description: 'Cost accounting and financial management specialization',
        entranceExams: ['CMA Foundation', 'Direct Entry available'],
        averageSalary: '₹4-12 LPA',
        jobProspects: 'Good - Manufacturing, consulting, financial services'
      },
      {
        name: 'Economics Honors',
        description: 'Economic analysis, policy, and research',
        entranceExams: ['DU JAT', 'University Merit Lists', 'CUET'],
        averageSalary: '₹3-15 LPA',
        jobProspects: 'Good - Government, research, banking, policy making'
      }
    ],
    scope: 'Growing rapidly with digital transformation and expanding business opportunities',
    color: 'bg-green-50 border-green-200',
    advantages: [
      'Lower entrance exam pressure compared to science',
      'Multiple career paths available',
      'Good scope for entrepreneurship',
      'Professional courses with high recognition',
      'Opportunities in both government and private sectors',
      'Skills applicable globally'
    ],
    challenges: [
      'Some courses require articleship/practical training',
      'Competition for top college admissions',
      'Need to stay updated with changing business laws',
      'Professional exams can be lengthy and demanding',
      'Initial salaries might be lower than technical fields'
    ],
    bestFor: [
      'Students interested in business and finance',
      'Those with good mathematical and analytical skills',
      'Future entrepreneurs and business leaders',
      'Students interested in economics and commerce',
      'Those seeking professional qualifications'
    ]
  },
  {
    title: 'Arts/Humanities Stream',
    icon: Palette,
    description: 'Great for creative minds, social science enthusiasts, and future administrators',
    eligibility: 'Minimum 45% in 10th grade, no specific subject restrictions',
    duration: '2 years (11th & 12th)',
    careers: [
      {
        name: 'Civil Services (UPSC)',
        description: 'Administrative services including IAS, IPS, IFS, and other central services',
        entranceExams: ['UPSC CSE', 'State PCS', 'SSC CGL'],
        averageSalary: '₹56,100 - ₹2,50,000 per month',
        jobProspects: 'Excellent - Highest respect, job security, policy-making roles'
      },
      {
        name: 'Bachelor of Arts (BA)',
        description: 'Liberal arts education with specialization in various subjects',
        entranceExams: ['DU JAT', 'University Merit Lists', 'CUET', 'BHU UET'],
        averageSalary: '₹2-6 LPA',
        jobProspects: 'Good - Teaching, media, government jobs, higher studies'
      },
      {
        name: 'Law (LLB/BA LLB)',
        description: 'Legal profession including advocacy, corporate law, judicial services',
        entranceExams: ['CLAT', 'AILET', 'LSAT India', 'University Tests'],
        averageSalary: '₹3-20 LPA',
        jobProspects: 'Excellent - Legal practice, corporate jobs, judicial services'
      },
      {
        name: 'Mass Communication & Journalism',
        description: 'Media, broadcasting, digital content, and communication',
        entranceExams: ['IIMC Entrance Test', 'Jamia Mass Comm', 'University Tests'],
        averageSalary: '₹2.5-12 LPA',
        jobProspects: 'Good - Media industry, digital marketing, content creation'
      },
      {
        name: 'Psychology',
        description: 'Study of human behavior, counseling, and mental health',
        entranceExams: ['University Merit Lists', 'CUET', 'Entrance Tests'],
        averageSalary: '₹3-10 LPA',
        jobProspects: 'Growing - Counseling, HR, research, clinical practice'
      },
      {
        name: 'Fine Arts & Design',
        description: 'Creative fields including painting, sculpture, graphic design',
        entranceExams: ['NID DAT', 'NIFT', 'CEED', 'University Tests'],
        averageSalary: '₹2.5-15 LPA',
        jobProspects: 'Good - Creative industries, advertising, entertainment'
      }
    ],
    scope: 'Diverse opportunities in modern society with growing importance of humanities',
    color: 'bg-purple-50 border-purple-200',
    advantages: [
      'Flexibility in subject choices',
      'Foundation for civil services preparation',
      'Develops critical thinking and communication skills',
      'Lower academic pressure compared to science',
      'Opportunities for creative expression',
      'Broad knowledge base across subjects'
    ],
    challenges: [
      'Perception of limited career options',
      'Lower starting salaries in some fields',
      'Highly competitive civil services exams',
      'Need for additional skills in digital age',
      'Family and social pressure to choose science/commerce'
    ],
    bestFor: [
      'Students interested in social sciences and humanities',
      'Future civil servants and administrators',
      'Creative individuals with artistic inclinations',
      'Those interested in law and justice',
      'Students who prefer reading and writing over calculations',
      'Individuals with strong communication skills'
    ]
  }
];

// Additional career guidance data
export const postTwelfthOptions = {
  immediate: [
    'Professional Courses (Engineering, Medical, Law)',
    'Undergraduate Degrees (BCom, BA, BSc, BBA)',
    'Diploma Courses (Polytechnic, ITI)',
    'Certificate Courses (Computer, Languages, Skills)'
  ],
  competitive: [
    'Engineering Entrance Exams (JEE, BITSAT, State CETs)',
    'Medical Entrance Exams (NEET, AIIMS)',
    'Law Entrance Exams (CLAT, AILET)',
    'Design Entrance Exams (NID, NIFT)',
    'Management Entrance Exams (Various Universities)'
  ],
  alternative: [
    'Study Abroad Programs',
    'Skill-based Courses',
    'Entrepreneurship',
    'Gap Year for Preparation',
    'Armed Forces (NDA after 12th)'
  ]
};