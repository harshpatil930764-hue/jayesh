export interface MedicalCollegeCutOff {
  collegeName: string;
  location: string;
  course: string;
  openingRank: number;
  closingRank: number;
  fees: string;
  type: 'AIIMS' | 'Government' | 'Private' | 'Deemed' | 'Central';
  rating: number;
  website: string;
  seats: number;
}

export interface MedicalCutOffTrend {
  category: string;
  cutoff2024: number;
  cutoff2023: number;
  cutoff2022: number;
  cutoff2021: number;
  trend: 'up' | 'down' | 'stable';
  color: string;
  expectedCutoff2025?: number;
}

export interface MedicalExamDetails {
  name: string;
  fullName: string;
  description: string;
  conductingBody: string;
  examLevel: 'National' | 'State' | 'University';
  eligibility: {
    education: string;
    subjects: string;
    percentage: string;
    ageLimit: string;
    attempts: string;
  };
  examSchedule: {
    notification: string;
    application: string;
    examDates: string;
    result: string;
    counseling: string;
  };
  examPattern: {
    mode: string;
    duration: string;
    totalQuestions: number;
    totalMarks: number;
    subjects: string[];
    negativeMarking: string;
    language: string[];
  };
  syllabus: {
    physics: string[];
    chemistry: string[];
    biology: string[];
    generalKnowledge?: string[];
  };
  cutoffTrends: MedicalCutOffTrend[];
  topColleges: MedicalCollegeCutOff[];
  preparationTips: string[];
  importantBooks: {
    subject: string;
    books: { name: string; author: string }[];
  }[];
  fees: {
    application: string;
    counseling: string;
  };
  seats: {
    total: number;
    government: number;
    private: number;
    deemed: number;
  };
}

export const medicalExamsData: MedicalExamDetails[] = [
  {
    name: "NEET UG",
    fullName: "National Eligibility cum Entrance Test (Undergraduate)",
    description: "NEET UG is the single entrance examination for admission to MBBS/BDS courses in India. It's conducted by NTA for admission to government and private medical colleges.",
    conductingBody: "National Testing Agency (NTA)",
    examLevel: "National",
    eligibility: {
      education: "10+2 with Physics, Chemistry, Biology/Biotechnology",
      subjects: "Physics, Chemistry, Biology/Biotechnology, English",
      percentage: "50% for General, 45% for Reserved Categories, 40% for PWD",
      ageLimit: "17 years minimum, no upper age limit",
      attempts: "No limit on attempts"
    },
    examSchedule: {
      notification: "March 2025",
      application: "March-April 2025",
      examDates: "First Sunday of May 2025",
      result: "June 2025",
      counseling: "July-October 2025"
    },
    examPattern: {
      mode: "Offline (Pen & Paper)",
      duration: "3 hours 20 minutes",
      totalQuestions: 200,
      totalMarks: 720,
      subjects: ["Physics (50 Q)", "Chemistry (50 Q)", "Botany (50 Q)", "Zoology (50 Q)"],
      negativeMarking: "-1 mark for wrong answer",
      language: ["English", "Hindi", "Assamese", "Bengali", "Gujarati", "Kannada", "Malayalam", "Marathi", "Odia", "Punjabi", "Tamil", "Telugu", "Urdu"]
    },
    syllabus: {
      physics: [
        "Mechanics - Laws of Motion, Work Energy Power",
        "Thermodynamics and Kinetic Theory",
        "Oscillations and Waves",
        "Electrostatics and Current Electricity", 
        "Magnetic Effects and Electromagnetic Induction",
        "Optics - Ray and Wave Optics",
        "Modern Physics - Atomic Structure, Nuclei"
      ],
      chemistry: [
        "Physical Chemistry - Atomic Structure, Chemical Bonding",
        "States of Matter and Thermodynamics",
        "Chemical Equilibrium and Ionic Equilibrium",
        "Electrochemistry and Chemical Kinetics",
        "Inorganic Chemistry - Periodic Table, s & p Block",
        "d & f Block Elements, Coordination Compounds",
        "Organic Chemistry - Hydrocarbons, Haloalkanes",
        "Alcohols, Aldehydes, Ketones, Carboxylic Acids",
        "Nitrogen Compounds and Biomolecules"
      ],
      biology: [
        "Diversity of Living World - Classification",
        "Structural Organization - Plant and Animal Tissues",
        "Cell Structure and Function",
        "Plant Physiology - Photosynthesis, Respiration",
        "Human Physiology - Digestion, Breathing, Circulation",
        "Reproduction in Organisms",
        "Genetics and Evolution",
        "Biology and Human Welfare",
        "Biotechnology and Applications",
        "Ecology and Environment"
      ]
    },
    cutoffTrends: [
      {
        category: "General",
        cutoff2024: 720,
        cutoff2023: 715,
        cutoff2022: 712,
        cutoff2021: 720,
        trend: "up",
        color: "text-red-600",
        expectedCutoff2025: 722
      },
      {
        category: "OBC-NCL",
        cutoff2024: 690,
        cutoff2023: 685,
        cutoff2022: 682,
        cutoff2021: 690,
        trend: "up",
        color: "text-orange-600",
        expectedCutoff2025: 692
      },
      {
        category: "SC",
        cutoff2024: 590,
        cutoff2023: 585,
        cutoff2022: 580,
        cutoff2021: 590,
        trend: "up",
        color: "text-blue-600",
        expectedCutoff2025: 592
      },
      {
        category: "ST",
        cutoff2024: 570,
        cutoff2023: 565,
        cutoff2022: 560,
        cutoff2021: 570,
        trend: "up",
        color: "text-purple-600",
        expectedCutoff2025: 572
      },
      {
        category: "EWS",
        cutoff2024: 710,
        cutoff2023: 705,
        cutoff2022: 702,
        cutoff2021: 710,
        trend: "up",
        color: "text-green-600",
        expectedCutoff2025: 712
      }
    ],
    topColleges: [
      {
        collegeName: "AIIMS New Delhi",
        location: "New Delhi",
        course: "MBBS",
        openingRank: 1,
        closingRank: 63,
        fees: "₹5,856/year",
        type: "AIIMS",
        rating: 4.8,
        website: "aiims.edu",
        seats: 125
      },
      {
        collegeName: "AIIMS Jodhpur",
        location: "Rajasthan",
        course: "MBBS", 
        openingRank: 64,
        closingRank: 150,
        fees: "₹5,856/year",
        type: "AIIMS",
        rating: 4.6,
        website: "aiimsjodhpur.edu.in",
        seats: 125
      },
      {
        collegeName: "JIPMER Puducherry",
        location: "Puducherry",
        course: "MBBS",
        openingRank: 151,
        closingRank: 350,
        fees: "₹3,608/year",
        type: "Central",
        rating: 4.5,
        website: "jipmer.edu.in",
        seats: 150
      },
      {
        collegeName: "MAMC Delhi",
        location: "New Delhi",
        course: "MBBS",
        openingRank: 200,
        closingRank: 500,
        fees: "₹15,000/year",
        type: "Government",
        rating: 4.4,
        website: "mamc.ac.in",
        seats: 250
      },
      {
        collegeName: "KGMU Lucknow",
        location: "Uttar Pradesh",
        course: "MBBS",
        openingRank: 300,
        closingRank: 800,
        fees: "₹50,000/year",
        type: "Government",
        rating: 4.3,
        website: "kgmcindia.edu",
        seats: 150
      },
      {
        collegeName: "CMC Vellore",
        location: "Tamil Nadu",
        course: "MBBS",
        openingRank: 400,
        closingRank: 1000,
        fees: "₹6,25,000/year",
        type: "Private",
        rating: 4.7,
        website: "cmcvellore.ac.in",
        seats: 100
      }
    ],
    preparationTips: [
      "Focus on NCERT books for Biology - they are the foundation",
      "Practice previous year questions extensively - at least 10 years",
      "Take regular mock tests to improve speed and accuracy",
      "Make short notes for quick revision, especially for Biology facts",
      "Focus on weak areas but don't neglect strong subjects",
      "Maintain consistency in study schedule - 8-10 hours daily",
      "Join online test series for better exam simulation",
      "Stay updated with current medical breakthroughs for GK",
      "Practice time management - 45 seconds per question average",
      "Stay healthy and manage stress through meditation/exercise"
    ],
    importantBooks: [
      {
        subject: "Physics",
        books: [
          { name: "NCERT Physics Class 11 & 12", author: "NCERT" },
          { name: "Concepts of Physics", author: "H.C. Verma" },
          { name: "Physics for Medical Entrance", author: "D.C. Pandey" }
        ]
      },
      {
        subject: "Chemistry", 
        books: [
          { name: "NCERT Chemistry Class 11 & 12", author: "NCERT" },
          { name: "Physical Chemistry", author: "O.P. Tandon" },
          { name: "Organic Chemistry", author: "Morrison & Boyd" }
        ]
      },
      {
        subject: "Biology",
        books: [
          { name: "NCERT Biology Class 11 & 12", author: "NCERT" },
          { name: "Biology Vol 1 & 2", author: "Trueman" },
          { name: "Objective Biology", author: "Dinesh" }
        ]
      }
    ],
    fees: {
      application: "₹1,700 (General), ₹900 (Reserved)",
      counseling: "₹1,000-5,000 (varies by round)"
    },
    seats: {
      total: 108298,
      government: 52720,
      private: 35378,
      deemed: 20200
    }
  },
  {
    name: "AIIMS INI-CET",
    fullName: "All Institute of Medical Sciences - Institute of National Importance Combined Entrance Test",
    description: "AIIMS INI-CET is conducted for admission to PG medical courses (MD/MS/MCh/DM) at AIIMS and other Institutes of National Importance.",
    conductingBody: "AIIMS New Delhi",
    examLevel: "National",
    eligibility: {
      education: "MBBS degree from MCI recognized institution",
      subjects: "Medical subjects",
      percentage: "55% in MBBS (50% for SC/ST/OBC)",
      ageLimit: "No age limit",
      attempts: "No limit on attempts"
    },
    examSchedule: {
      notification: "March 2025",
      application: "March-April 2025",
      examDates: "May 2025",
      result: "June 2025", 
      counseling: "July-August 2025"
    },
    examPattern: {
      mode: "Computer Based Test (CBT)",
      duration: "4.5 hours",
      totalQuestions: 200,
      totalMarks: 200,
      subjects: ["Pre-clinical (50)", "Para-clinical (50)", "Clinical (100)"],
      negativeMarking: "No negative marking",
      language: ["English"]
    },
    syllabus: {
      physics: [],
      chemistry: [],
      biology: [
        "Anatomy - Gross anatomy, Histology, Embryology",
        "Physiology - Human physiology, Applied physiology",
        "Biochemistry - Clinical biochemistry, Molecular biology",
        "Pathology - General and systemic pathology",
        "Microbiology - Bacteriology, Virology, Mycology",
        "Pharmacology - General and systemic pharmacology",
        "Forensic Medicine - Medico-legal aspects",
        "Community Medicine - Epidemiology, Biostatistics",
        "Medicine - General medicine, Specialties",
        "Surgery - General surgery, Specialties",
        "Obstetrics & Gynecology",
        "Pediatrics",
        "Orthopedics",
        "Ophthalmology",
        "ENT",
        "Dermatology",
        "Psychiatry",
        "Radiology",
        "Anesthesiology"
      ]
    },
    cutoffTrends: [
      {
        category: "General",
        cutoff2024: 85,
        cutoff2023: 82,
        cutoff2022: 80,
        cutoff2021: 85,
        trend: "up",
        color: "text-red-600",
        expectedCutoff2025: 87
      },
      {
        category: "OBC-NCL",
        cutoff2024: 78,
        cutoff2023: 75,
        cutoff2022: 73,
        cutoff2021: 78,
        trend: "up",
        color: "text-orange-600",
        expectedCutoff2025: 80
      },
      {
        category: "SC",
        cutoff2024: 65,
        cutoff2023: 62,
        cutoff2022: 60,
        cutoff2021: 65,
        trend: "up",
        color: "text-blue-600",
        expectedCutoff2025: 67
      },
      {
        category: "ST",
        cutoff2024: 60,
        cutoff2023: 57,
        cutoff2022: 55,
        cutoff2021: 60,
        trend: "up",
        color: "text-purple-600",
        expectedCutoff2025: 62
      }
    ],
    topColleges: [
      {
        collegeName: "AIIMS New Delhi",
        location: "New Delhi",
        course: "MD/MS",
        openingRank: 1,
        closingRank: 50,
        fees: "₹5,856/year",
        type: "AIIMS",
        rating: 4.8,
        website: "aiims.edu",
        seats: 350
      },
      {
        collegeName: "PGIMER Chandigarh",
        location: "Chandigarh",
        course: "MD/MS",
        openingRank: 51,
        closingRank: 150,
        fees: "₹7,000/year",
        type: "Central",
        rating: 4.7,
        website: "pgimer.edu.in",
        seats: 200
      },
      {
        collegeName: "JIPMER Puducherry",
        location: "Puducherry", 
        course: "MD/MS",
        openingRank: 151,
        closingRank: 300,
        fees: "₹3,608/year",
        type: "Central",
        rating: 4.5,
        website: "jipmer.edu.in",
        seats: 150
      }
    ],
    preparationTips: [
      "Focus on clinical subjects as they carry maximum weightage",
      "Refer to standard textbooks like Harrison's, Bailey & Love's",
      "Practice MCQs from previous years and online test series",
      "Join coaching or online courses for structured preparation",
      "Make clinical correlations for better understanding",
      "Focus on recent advances in medical science",
      "Practice image-based questions extensively",
      "Revise basic sciences in clinical context",
      "Join study groups for peer learning",
      "Stay updated with latest medical guidelines"
    ],
    importantBooks: [
      {
        subject: "Medicine",
        books: [
          { name: "Harrison's Principles of Internal Medicine", author: "Kasper et al." },
          { name: "API Textbook of Medicine", author: "YP Munjal" },
          { name: "Medicine Prep Manual", author: "Medicos" }
        ]
      },
      {
        subject: "Surgery",
        books: [
          { name: "Bailey & Love's Short Practice of Surgery", author: "Williams" },
          { name: "SRB's Manual of Surgery", author: "Sriram Bhat" },
          { name: "Manipal Manual of Surgery", author: "K Rajgopal Shenoy" }
        ]
      },
      {
        subject: "Basic Sciences",
        books: [
          { name: "Robbins Basic Pathology", author: "Kumar et al." },
          { name: "Review of Medical Physiology", author: "Ganong" },
          { name: "Harper's Biochemistry", author: "Murray" }
        ]
      }
    ],
    fees: {
      application: "₹1,500",
      counseling: "₹2,000 per round"
    },
    seats: {
      total: 1500,
      government: 1500,
      private: 0,
      deemed: 0
    }
  },
  {
    name: "FMGE",
    fullName: "Foreign Medical Graduate Examination",
    description: "FMGE is a screening test for Indian citizens who have completed their medical degree from foreign medical colleges to practice in India.",
    conductingBody: "National Board of Examinations (NBE)",
    examLevel: "National",
    eligibility: {
      education: "MBBS from MCI/NMC recognized foreign medical college",
      subjects: "Medical subjects",
      percentage: "50% in MBBS",
      ageLimit: "No age limit",
      attempts: "Maximum 5 attempts"
    },
    examSchedule: {
      notification: "April & October 2025",
      application: "May & November 2025",
      examDates: "June & December 2025",
      result: "Within 15 days of exam",
      counseling: "Not applicable"
    },
    examPattern: {
      mode: "Computer Based Test (CBT)",
      duration: "3.5 hours",
      totalQuestions: 300,
      totalMarks: 300,
      subjects: ["Pre-clinical (75)", "Para-clinical (75)", "Clinical (150)"],
      negativeMarking: "No negative marking",
      language: ["English"]
    },
    syllabus: {
      physics: [],
      chemistry: [],
      biology: [
        "Anatomy",
        "Physiology", 
        "Biochemistry",
        "Pathology",
        "Microbiology",
        "Pharmacology",
        "Forensic Medicine",
        "Community Medicine",
        "General Medicine",
        "General Surgery",
        "Obstetrics & Gynecology", 
        "Pediatrics",
        "Orthopedics",
        "Ophthalmology",
        "ENT",
        "Dermatology",
        "Psychiatry",
        "Radiology",
        "Anesthesiology"
      ]
    },
    cutoffTrends: [
      {
        category: "General",
        cutoff2024: 150,
        cutoff2023: 147,
        cutoff2022: 145,
        cutoff2021: 150,
        trend: "stable",
        color: "text-gray-600",
        expectedCutoff2025: 150
      }
    ],
    topColleges: [],
    preparationTips: [
      "Focus on Indian medical curriculum and guidelines",
      "Practice with Indian medical textbooks",
      "Take online mock tests regularly",
      "Understand Indian medical practice patterns",
      "Join FMGE preparation courses",
      "Study recent advances in Indian medical field",
      "Practice clinical case scenarios",
      "Focus on public health and epidemiology",
      "Understand medicolegal aspects in Indian context",
      "Stay updated with latest medical protocols in India"
    ],
    importantBooks: [
      {
        subject: "General Preparation",
        books: [
          { name: "FMGE Solutions", author: "Elsevier" },
          { name: "FMGE MQS", author: "Marrow" },
          { name: "Review of Medical Physiology", author: "Ganong" }
        ]
      }
    ],
    fees: {
      application: "₹3,500",
      counseling: "Not applicable"
    },
    seats: {
      total: 0,
      government: 0,
      private: 0,
      deemed: 0
    }
  }
];

export const medicalExamStats = {
  totalCandidates: "18,72,341",
  totalSeats: "1,08,298",
  averageScore: "565/720",
  passPercentage: "14.2%",
  competitionRatio: "17:1",
  successRate: "5.8%"
};