import { BookOpen, Video, FileText, Users, Calendar, Download, ExternalLink, Globe } from 'lucide-react';

export interface Resource {
  title: string;
  description: string;
  type: 'free' | 'paid' | 'government';
  category: string;
  link: string;
  features: string[];
  suitableFor: string[];
  language: string[];
}

export interface ResourceCategory {
  title: string;
  icon: any;
  description: string;
  resources: Resource[];
}

export const resourcesData: ResourceCategory[] = [
  {
    title: 'Free Online Learning',
    icon: Globe,
    description: 'High-quality educational content available for free',
    resources: [
      {
        title: 'Khan Academy',
        description: 'World-class education for anyone, anywhere. Completely free.',
        type: 'free',
        category: 'General Education',
        link: 'https://khanacademy.org',
        features: [
          'Personalized learning dashboard',
          'Practice exercises and videos',
          'Progress tracking',
          'Available in multiple languages'
        ],
        suitableFor: ['Class 6-12 students', 'Competitive exam preparation', 'Concept building'],
        language: ['English', 'Hindi', 'Bengali', 'Gujarati']
      },
      {
        title: 'NPTEL',
        description: 'National Programme on Technology Enhanced Learning by IITs/IISc',
        type: 'government',
        category: 'Higher Education',
        link: 'https://nptel.ac.in',
        features: [
          'University-level courses',
          'Certification available',
          'Video lectures by IIT/IISc professors',
          'Engineering and Science focus'
        ],
        suitableFor: ['Engineering students', 'Science graduates', 'Research aspirants'],
        language: ['English', 'Hindi']
      },
      {
        title: 'SWAYAM',
        description: 'Government of India\'s education platform with courses from top institutions',
        type: 'government',
        category: 'All Levels',
        link: 'https://swayam.gov.in',
        features: [
          'Courses from IITs, IIMs, central universities',
          'Credit transfer facility',
          'Free certification',
          'Wide range of subjects'
        ],
        suitableFor: ['All students', 'Working professionals', 'Skill development'],
        language: ['English', 'Hindi', 'Regional languages']
      },
      {
        title: 'DIKSHA',
        description: 'National digital infrastructure for teachers and students',
        type: 'government',
        category: 'School Education',
        link: 'https://diksha.gov.in',
        features: [
          'NCERT textbooks and solutions',
          'State board content',
          'Interactive content',
          'Works on basic smartphones'
        ],
        suitableFor: ['Class 1-12 students', 'Teachers', 'Rural students'],
        language: ['Hindi', 'English', 'All regional languages']
      }
    ]
  },
  {
    title: 'Competitive Exam Prep',
    icon: BookOpen,
    description: 'Specialized resources for entrance exams and competitive tests',
    resources: [
      {
        title: 'Unacademy',
        description: 'India\'s largest online learning platform for competitive exams',
        type: 'free',
        category: 'Competitive Exams',
        link: 'https://unacademy.com',
        features: [
          'Live classes and recorded sessions',
          'Free and paid content',
          'Expert educators',
          'Mock tests and practice'
        ],
        suitableFor: ['JEE/NEET aspirants', 'UPSC candidates', 'Banking exam prep'],
        language: ['Hindi', 'English']
      },
      {
        title: 'Testbook',
        description: 'Comprehensive test preparation platform',
        type: 'free',
        category: 'Government Exams',
        link: 'https://testbook.com',
        features: [
          'Free mock tests',
          'Previous year papers',
          'Study materials',
          'Performance analysis'
        ],
        suitableFor: ['SSC aspirants', 'Banking exams', 'Railway exams', 'State PSC'],
        language: ['Hindi', 'English']
      },
      {
        title: 'Embibe',
        description: 'AI-powered personalized learning for competitive exams',
        type: 'free',
        category: 'JEE/NEET',
        link: 'https://embibe.com',
        features: [
          'AI-based learning analysis',
          'Unlimited practice tests',
          'Detailed performance insights',
          'Improvement suggestions'
        ],
        suitableFor: ['JEE Main/Advanced aspirants', 'NEET candidates'],
        language: ['English', 'Hindi']
      },
      {
        title: 'Gradeup (BYJU\'S Exam Prep)',
        description: 'Government exam preparation platform',
        type: 'free',
        category: 'Government Jobs',
        link: 'https://gradeup.co',
        features: [
          'Daily current affairs',
          'Mock tests',
          'Study notes',
          'Expert guidance'
        ],
        suitableFor: ['UPSC CSE', 'SSC CGL', 'Banking exams', 'Teaching exams'],
        language: ['Hindi', 'English']
      }
    ]
  },
  {
    title: 'Career Guidance',
    icon: Users,
    description: 'Professional counseling and career planning resources',
    resources: [
      {
        title: 'Mindler',
        description: 'Online career counseling and guidance platform',
        type: 'paid',
        category: 'Career Counseling',
        link: 'https://mindler.com',
        features: [
          'Psychometric assessments',
          'One-on-one counseling',
          'Career roadmaps',
          'Industry insights'
        ],
        suitableFor: ['Class 10-12 students', 'College students', 'Career changers'],
        language: ['English', 'Hindi']
      },
      {
        title: 'iDreamCareer',
        description: 'Career discovery and planning platform',
        type: 'free',
        category: 'Career Exploration',
        link: 'https://idreamcareer.com',
        features: [
          'Career exploration tools',
          'Industry guides',
          'Skill assessments',
          'College and course information'
        ],
        suitableFor: ['High school students', 'College students', 'Parents'],
        language: ['English', 'Hindi']
      },
      {
        title: 'Careers360',
        description: 'Comprehensive career and education portal',
        type: 'free',
        category: 'Educational Information',
        link: 'https://careers360.com',
        features: [
          'College rankings and reviews',
          'Admission guidance',
          'Scholarship information',
          'Career articles'
        ],
        suitableFor: ['Students seeking admissions', 'Parents', 'Career guidance'],
        language: ['English', 'Hindi']
      }
    ]
  },
  {
    title: 'Study Materials',
    icon: FileText,
    description: 'Books, notes, and study resources for various exams',
    resources: [
      {
        title: 'NCERT Books Online',
        description: 'Official textbooks for CBSE and other state boards',
        type: 'government',
        category: 'School Textbooks',
        link: 'https://ncert.nic.in/textbook.php',
        features: [
          'Free PDF downloads',
          'All subjects available',
          'Class 1-12 coverage',
          'Basis for most competitive exams'
        ],
        suitableFor: ['All school students', 'Competitive exam prep', 'Teachers'],
        language: ['English', 'Hindi', 'Urdu']
      },
      {
        title: 'Oswaal Books',
        description: 'Sample papers and study materials for boards and competitive exams',
        type: 'paid',
        category: 'Study Materials',
        link: 'https://oswaalbooks.com',
        features: [
          'Previous year papers',
          'Sample papers',
          'Revision notes',
          'Board exam preparation'
        ],
        suitableFor: ['Class 10-12 students', 'Board exam preparation'],
        language: ['English', 'Hindi']
      },
      {
        title: 'Arihant Publications',
        description: 'Books for competitive examinations',
        type: 'paid',
        category: 'Competitive Books',
        link: 'https://arihantbooks.com',
        features: [
          'JEE/NEET preparation books',
          'Government exam materials',
          'Practice sets',
          'Previous year solved papers'
        ],
        suitableFor: ['JEE/NEET aspirants', 'Government job aspirants'],
        language: ['English', 'Hindi']
      }
    ]
  },
  {
    title: 'Scholarships & Financial Aid',
    icon: Download,
    description: 'Financial support opportunities for education',
    resources: [
      {
        title: 'National Scholarship Portal',
        description: 'Government scholarship schemes for students',
        type: 'government',
        category: 'Scholarships',
        link: 'https://scholarships.gov.in',
        features: [
          'Pre-matric and post-matric scholarships',
          'Merit-based and need-based support',
          'Central and state government schemes',
          'Direct benefit transfer'
        ],
        suitableFor: ['SC/ST/BC students', 'Minority students', 'Merit holders'],
        language: ['English', 'Hindi', 'Regional languages']
      },
      {
        title: 'Buddy4Study',
        description: 'Scholarship search and application platform',
        type: 'free',
        category: 'Scholarship Information',
        link: 'https://buddy4study.com',
        features: [
          'Scholarship search',
          'Application assistance',
          'Educational loans information',
          'College admissions support'
        ],
        suitableFor: ['All students', 'Economically weaker sections', 'Merit students'],
        language: ['English', 'Hindi']
      }
    ]
  },
  {
    title: 'Skill Development',
    icon: Video,
    description: 'Practical skills and vocational training resources',
    resources: [
      {
        title: 'Skill India Digital',
        description: 'Government platform for skill development',
        type: 'government',
        category: 'Skill Training',
        link: 'https://www.skillindia.gov.in',
        features: [
          'Free skill courses',
          'Industry-relevant training',
          'Certification',
          'Job placement assistance'
        ],
        suitableFor: ['Youth seeking employment', 'Skill enhancement', 'Vocational training'],
        language: ['Hindi', 'English', 'Regional languages']
      },
      {
        title: 'Coursera',
        description: 'Online courses from top universities and companies',
        type: 'free',
        category: 'Professional Skills',
        link: 'https://coursera.org',
        features: [
          'University courses',
          'Professional certificates',
          'Financial aid available',
          'Career-focused learning'
        ],
        suitableFor: ['College students', 'Working professionals', 'Skill upgrading'],
        language: ['English', 'Subtitles in multiple languages']
      }
    ]
  }
];

export const studyTips = [
  {
    category: 'Time Management',
    tips: [
      'Create a daily study schedule and stick to it',
      'Use the Pomodoro Technique: 25 minutes study, 5 minutes break',
      'Prioritize subjects based on exam weightage and difficulty',
      'Set weekly and monthly goals'
    ]
  },
  {
    category: 'Effective Studying',
    tips: [
      'Make notes in your own words',
      'Practice previous year questions regularly',
      'Form study groups with serious students',
      'Teach concepts to others to reinforce learning'
    ]
  },
  {
    category: 'Exam Preparation',
    tips: [
      'Take regular mock tests',
      'Analyze your mistakes thoroughly',
      'Focus on your weak areas',
      'Maintain a healthy sleep schedule'
    ]
  },
  {
    category: 'For Rural Students',
    tips: [
      'Use offline study materials when internet is limited',
      'Download content during good connectivity',
      'Form local study groups',
      'Seek help from teachers and educated community members'
    ]
  }
];