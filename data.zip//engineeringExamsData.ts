import { GraduationCap, Calculator, Zap, Target, Trophy, Star, TrendingUp, BookOpen } from 'lucide-react';

export interface CollegeCutOff {
  collegeName: string;
  location: string;
  branch: string;
  openingRank: number;
  closingRank: number;
  fees: string;
  placement: {
    average: string;
    highest: string;
    percentage: string;
  };
  rating: number;
  type: 'NIT' | 'IIT' | 'IIIT' | 'State' | 'Private';
  website: string;
}

export interface CutOffTrend {
  category: string;
  cutoff2024: number;
  cutoff2023: number;
  cutoff2022: number;
  cutoff2021: number;
  trend: 'up' | 'down' | 'stable';
  color: string;
  expectedCutoff2025?: number;
}

export interface ExamDetails {
  name: string;
  fullName: string;
  description: string;
  conductingBody: string;
  examLevel: 'National' | 'State' | 'University';
  eligibility: {
    education: string;
    subjects: string;
    percentage: string;
    ageLimit: string;
    attempts: string;
  };
  examSchedule: {
    notification: string;
    application: string;
    examDates: string;
    result: string;
    counseling: string;
  };
  examPattern: {
    mode: string;
    duration: string;
    subjects: string[];
    totalQuestions: number;
    totalMarks: number;
    negativeMarking: string;
    languages: string[];
  };
  syllabus: {
    physics: string[];
    chemistry: string[];
    mathematics: string[];
  };
  cutOffTrends: CutOffTrend[];
  topColleges: CollegeCutOff[];
  fees: {
    application: string;
    counseling?: string;
  };
  seats: {
    total: string;
    reservation: {
      general: string;
      obc: string;
      sc: string;
      st: string;
      ews: string;
    };
  };
  officialWebsite: string;
  keyInfo: string[];
  preparationTips: string[];
  bgGradient: string;
  accentColor: string;
  iconColor: string;
}

export const engineeringExamsData: ExamDetails[] = [
  {
    name: 'JEE Main',
    fullName: 'Joint Entrance Examination Main',
    description: 'National level engineering entrance exam for admission to NITs, IIITs, CFTIs and other engineering colleges',
    conductingBody: 'National Testing Agency (NTA)',
    examLevel: 'National',
    bgGradient: 'from-blue-500 via-cyan-500 to-teal-500',
    accentColor: 'text-blue-600',
    iconColor: 'text-blue-500',
    eligibility: {
      education: '12th pass or equivalent with PCM',
      subjects: 'Physics, Chemistry, Mathematics (Compulsory)',
      percentage: '75% in 12th (65% for SC/ST) - Relaxed from 2023',
      ageLimit: 'No age limit (from 2023)',
      attempts: 'No limit on attempts (from 2021)'
    },
    examSchedule: {
      notification: 'December 2024',
      application: 'December 2024 - January 2025',
      examDates: 'Session 1: January 2025, Session 2: April 2025',
      result: 'Session 1: February 2025, Session 2: May 2025',
      counseling: 'June - September 2025'
    },
    examPattern: {
      mode: 'Computer Based Test (CBT)',
      duration: '3 hours (180 minutes)',
      subjects: ['Physics', 'Chemistry', 'Mathematics'],
      totalQuestions: 90,
      totalMarks: 300,
      negativeMarking: '-1 mark for incorrect answer, 0 marks for unanswered',
      languages: ['English', 'Hindi', 'Assamese', 'Bengali', 'Gujarati', 'Kannada', 'Malayalam', 'Marathi', 'Odia', 'Punjabi', 'Tamil', 'Telugu', 'Urdu']
    },
    syllabus: {
      physics: [
        'Units and Measurements', 'Kinematics', 'Laws of Motion', 'Work, Energy and Power',
        'Rotational Motion', 'Gravitation', 'Properties of Solids and Liquids',
        'Thermodynamics', 'Kinetic Theory of Gases', 'Oscillations and Waves',
        'Electrostatics', 'Current Electricity', 'Magnetic Effects of Current',
        'Electromagnetic Induction', 'Electromagnetic Waves', 'Optics',
        'Dual Nature of Matter and Radiation', 'Atoms and Nuclei', 'Electronic Devices',
        'Experimental Skills'
      ],
      chemistry: [
        'Some Basic Concepts in Chemistry', 'States of Matter', 'Atomic Structure',
        'Chemical Bonding and Molecular Structure', 'Chemical Thermodynamics',
        'Solutions', 'Equilibrium', 'Redox Reactions and Electrochemistry',
        'Chemical Kinetics', 'Surface Chemistry', 'General Principles of Metallurgy',
        'p-Block Elements', 'd-Block and f-Block Elements', 'Coordination Compounds',
        'Purification and Characterisation of Organic Compounds',
        'Some Basic Principles of Organic Chemistry', 'Hydrocarbons',
        'Organic Compounds Containing Halogens', 'Organic Compounds Containing Oxygen',
        'Organic Compounds Containing Nitrogen', 'Polymers', 'Biomolecules',
        'Chemistry in Everyday Life', 'Principles Related to Practical Chemistry'
      ],
      mathematics: [
        'Sets, Relations and Functions', 'Complex Numbers and Quadratic Equations',
        'Matrices and Determinants', 'Permutations and Combinations',
        'Mathematical Induction', 'Binomial Theorem', 'Sequences and Series',
        'Limit, Continuity and Differentiability', 'Integral Calculus',
        'Differential Equations', 'Coordinate Geometry', 'Three Dimensional Geometry',
        'Vector Algebra', 'Statistics and Probability', 'Trigonometry',
        'Mathematical Reasoning'
      ]
    },
    cutOffTrends: [
      {
        category: 'General',
        cutoff2024: 90.75,
        cutoff2023: 89.75,
        cutoff2022: 88.40,
        cutoff2021: 87.90,
        trend: 'up',
        color: 'from-red-400 to-red-600',
        expectedCutoff2025: 91.5
      },
      {
        category: 'EWS',
        cutoff2024: 89.12,
        cutoff2023: 88.15,
        cutoff2022: 87.23,
        cutoff2021: 86.45,
        trend: 'up',
        color: 'from-yellow-400 to-yellow-600',
        expectedCutoff2025: 90.0
      },
      {
        category: 'OBC-NCL',
        cutoff2024: 73.84,
        cutoff2023: 72.88,
        cutoff2022: 72.17,
        cutoff2021: 71.45,
        trend: 'up',
        color: 'from-orange-400 to-orange-600',
        expectedCutoff2025: 74.5
      },
      {
        category: 'SC',
        cutoff2024: 55.12,
        cutoff2023: 54.31,
        cutoff2022: 53.67,
        cutoff2021: 52.89,
        trend: 'up',
        color: 'from-green-400 to-green-600',
        expectedCutoff2025: 56.0
      },
      {
        category: 'ST',
        cutoff2024: 45.84,
        cutoff2023: 44.33,
        cutoff2022: 43.67,
        cutoff2021: 42.89,
        trend: 'up',
        color: 'from-blue-400 to-blue-600',
        expectedCutoff2025: 46.5
      },
      {
        category: 'PwD (Gen)',
        cutoff2024: 0.12,
        cutoff2023: 0.11,
        cutoff2022: 0.10,
        cutoff2021: 0.09,
        trend: 'up',
        color: 'from-purple-400 to-purple-600',
        expectedCutoff2025: 0.13
      }
    ],
    topColleges: [
      {
        collegeName: 'NIT Trichy',
        location: 'Tamil Nadu',
        branch: 'Computer Science',
        openingRank: 145,
        closingRank: 890,
        fees: '₹1.35L/year',
        placement: { average: '₹18.5L', highest: '₹45L', percentage: '95%' },
        rating: 4.8,
        type: 'NIT',
        website: 'www.nitt.edu'
      },
      {
        collegeName: 'NIT Warangal',
        location: 'Telangana',
        branch: 'Computer Science',
        openingRank: 167,
        closingRank: 978,
        fees: '₹1.35L/year',
        placement: { average: '₹17.2L', highest: '₹40L', percentage: '94%' },
        rating: 4.7,
        type: 'NIT',
        website: 'www.nitw.ac.in'
      },
      {
        collegeName: 'IIIT Hyderabad',
        location: 'Telangana',
        branch: 'Computer Science',
        openingRank: 98,
        closingRank: 456,
        fees: '₹2.8L/year',
        placement: { average: '₹25.8L', highest: '₹74L', percentage: '100%' },
        rating: 4.9,
        type: 'IIIT',
        website: 'www.iiit.ac.in'
      },
      {
        collegeName: 'NIT Surathkal',
        location: 'Karnataka',
        branch: 'Computer Science',
        openingRank: 234,
        closingRank: 1245,
        fees: '₹1.35L/year',
        placement: { average: '₹16.8L', highest: '₹39L', percentage: '92%' },
        rating: 4.6,
        type: 'NIT',
        website: 'www.nitk.ac.in'
      },
      {
        collegeName: 'IIIT Allahabad',
        location: 'Uttar Pradesh',
        branch: 'Computer Science',
        openingRank: 189,
        closingRank: 823,
        fees: '₹1.65L/year',
        placement: { average: '₹20.8L', highest: '₹43L', percentage: '96%' },
        rating: 4.5,
        type: 'IIIT',
        website: 'www.iiita.ac.in'
      },
      {
        collegeName: 'DTU Delhi',
        location: 'Delhi',
        branch: 'Computer Science',
        openingRank: 456,
        closingRank: 2145,
        fees: '₹1.85L/year',
        placement: { average: '₹15.2L', highest: '₹42L', percentage: '89%' },
        rating: 4.4,
        type: 'State',
        website: 'www.dtu.ac.in'
      }
    ],
    fees: {
      application: '₹650 (General), ₹325 (SC/ST/PwD/Female)',
      counseling: '₹17,500 - ₹35,000 (varies by category)'
    },
    seats: {
      total: '1,08,882 (2024)',
      reservation: {
        general: '49.5%',
        obc: '27%',
        sc: '15%',
        st: '7.5%',
        ews: '10%'
      }
    },
    officialWebsite: 'jeemain.nta.nic.in',
    keyInfo: [
      'Two attempts per year - January and April sessions',
      'Best of two session scores considered for ranking',
      'No restriction on number of attempts from 2021',
      'Qualifying exam for JEE Advanced (top 2.5 lakh)',
      'Direct admission to NITs, IIITs, and GFTIs',
      'Normalization process used for multi-session exams'
    ],
    preparationTips: [
      'Focus on NCERT books for building strong fundamentals',
      'Practice previous 10 years question papers',
      'Take regular mock tests to improve speed and accuracy',
      'Maintain equal focus on all three subjects',
      'Solve numerical problems daily in Physics and Chemistry',
      'Create formula sheets for quick revision'
    ]
  },
  {
    name: 'MHT CET',
    fullName: 'Maharashtra Common Entrance Test',
    description: 'State level engineering entrance exam for admission to engineering colleges in Maharashtra',
    conductingBody: 'State Common Entrance Test Cell, Maharashtra',
    examLevel: 'State',
    bgGradient: 'from-orange-500 via-red-500 to-pink-500',
    accentColor: 'text-orange-600',
    iconColor: 'text-orange-500',
    eligibility: {
      education: '12th pass with PCM from Maharashtra State Board or equivalent',
      subjects: 'Physics, Chemistry, Mathematics (Compulsory)',
      percentage: '50% in PCM (45% for reserved categories)',
      ageLimit: 'No age limit',
      attempts: 'No limit on attempts'
    },
    examSchedule: {
      notification: 'February 2025',
      application: 'March - April 2025',
      examDates: 'May 2025 (multiple sessions)',
      result: 'June 2025',
      counseling: 'July - September 2025'
    },
    examPattern: {
      mode: 'Computer Based Test (CBT)',
      duration: '3 hours (180 minutes)',
      subjects: ['Physics', 'Chemistry', 'Mathematics'],
      totalQuestions: 150,
      totalMarks: 200,
      negativeMarking: 'No negative marking',
      languages: ['English', 'Marathi', 'Hindi']
    },
    syllabus: {
      physics: [
        'Measurements', 'Motion in a Plane', 'Laws of Motion', 'Momentum and Energy',
        'Rotational Motion', 'Gravitation', 'Thermal Properties of Matter',
        'Sound', 'Electrostatics', 'Current Electricity', 'Magnetic Effect of Electric Current',
        'Electromagnetic Induction', 'Dual Nature of Radiation and Matter',
        'Structure of Atoms and Nuclei', 'Semiconductor Devices'
      ],
      chemistry: [
        'Some Basic Concepts of Chemistry', 'States of Matter', 'Atomic Structure',
        'Chemical Bonding', 'Redox Reactions', 'Chemical Thermodynamics',
        'Chemical Equilibrium', 'Ionic Equilibrium', 'Adsorption and Colloids',
        'Chemical Kinetics', 'Elements of Groups 16, 17 and 18',
        'Transition and Inner Transition Elements', 'Coordination Compounds',
        'Halogen Derivatives', 'Alcohols, Phenols and Ethers', 'Aldehydes, Ketones and Carboxylic Acids',
        'Organic Compounds Containing Nitrogen', 'Polymers', 'Biomolecules'
      ],
      mathematics: [
        'Trigonometry', 'Complex Numbers', 'Pair of Straight Lines',
        'Circle', 'Measures of Dispersion', 'Probability', 'Vectors',
        'Three Dimensional Geometry', 'Line', 'Plane', 'Linear Programming',
        'Integration', 'Differential Equations', 'Probability Distribution',
        'Binomial Distribution', 'Matrices', 'Mathematical Logic',
        'Statistics'
      ]
    },
    cutOffTrends: [
      {
        category: 'Open (General)',
        cutoff2024: 99.89,
        cutoff2023: 99.85,
        cutoff2022: 99.78,
        cutoff2021: 99.73,
        trend: 'up',
        color: 'from-red-400 to-red-600',
        expectedCutoff2025: 99.92
      },
      {
        category: 'EWS',
        cutoff2024: 99.23,
        cutoff2023: 99.18,
        cutoff2022: 99.12,
        cutoff2021: 99.05,
        trend: 'up',
        color: 'from-yellow-400 to-yellow-600',
        expectedCutoff2025: 99.28
      },
      {
        category: 'OBC',
        cutoff2024: 98.45,
        cutoff2023: 98.31,
        cutoff2022: 98.18,
        cutoff2021: 98.02,
        trend: 'up',
        color: 'from-orange-400 to-orange-600',
        expectedCutoff2025: 98.55
      },
      {
        category: 'SC',
        cutoff2024: 89.67,
        cutoff2023: 89.23,
        cutoff2022: 88.89,
        cutoff2021: 88.45,
        trend: 'up',
        color: 'from-green-400 to-green-600',
        expectedCutoff2025: 90.1
      },
      {
        category: 'ST',
        cutoff2024: 82.34,
        cutoff2023: 81.89,
        cutoff2022: 81.45,
        cutoff2021: 80.97,
        trend: 'up',
        color: 'from-blue-400 to-blue-600',
        expectedCutoff2025: 82.8
      },
      {
        category: 'NT (B)',
        cutoff2024: 95.67,
        cutoff2023: 95.23,
        cutoff2022: 94.89,
        cutoff2021: 94.45,
        trend: 'up',
        color: 'from-indigo-400 to-indigo-600',
        expectedCutoff2025: 96.1
      },
      {
        category: 'NT (C)',
        cutoff2024: 93.45,
        cutoff2023: 93.01,
        cutoff2022: 92.67,
        cutoff2021: 92.23,
        trend: 'up',
        color: 'from-purple-400 to-purple-600',
        expectedCutoff2025: 93.9
      }
    ],
    topColleges: [
      {
        collegeName: 'VJTI Mumbai',
        location: 'Mumbai',
        branch: 'Computer Engineering',
        openingRank: 25,
        closingRank: 189,
        fees: '₹1.08L/year',
        placement: { average: '₹12.5L', highest: '₹45L', percentage: '98%' },
        rating: 4.7,
        type: 'State',
        website: 'www.vjti.ac.in'
      },
      {
        collegeName: 'COEP Pune',
        location: 'Pune',
        branch: 'Computer Engineering',
        openingRank: 45,
        closingRank: 278,
        fees: '₹1.25L/year',
        placement: { average: '₹11.8L', highest: '₹38L', percentage: '96%' },
        rating: 4.6,
        type: 'State',
        website: 'www.coep.org.in'
      },
      {
        collegeName: 'ICT Mumbai',
        location: 'Mumbai',
        branch: 'Computer Engineering',
        openingRank: 67,
        closingRank: 345,
        fees: '₹1.85L/year',
        placement: { average: '₹13.2L', highest: '₹42L', percentage: '94%' },
        rating: 4.5,
        type: 'State',
        website: 'www.ictmumbai.edu.in'
      },
      {
        collegeName: 'PICT Pune',
        location: 'Pune',
        branch: 'Computer Engineering',
        openingRank: 189,
        closingRank: 1245,
        fees: '₹2.65L/year',
        placement: { average: '₹8.5L', highest: '₹28L', percentage: '92%' },
        rating: 4.3,
        type: 'Private',
        website: 'www.pictr.edu'
      },
      {
        collegeName: 'SPIT Mumbai',
        location: 'Mumbai',
        branch: 'Computer Engineering',
        openingRank: 345,
        closingRank: 1890,
        fees: '₹3.15L/year',
        placement: { average: '₹7.8L', highest: '₹25L', percentage: '89%' },
        rating: 4.2,
        type: 'Private',
        website: 'www.spit.ac.in'
      },
      {
        collegeName: 'VIT Pune',
        location: 'Pune',
        branch: 'Computer Engineering',
        openingRank: 567,
        closingRank: 2345,
        fees: '₹2.85L/year',
        placement: { average: '₹6.8L', highest: '₹22L', percentage: '87%' },
        rating: 4.1,
        type: 'Private',
        website: 'www.vit.edu'
      }
    ],
    fees: {
      application: '₹800 (General), ₹600 (Reserved Categories)'
    },
    seats: {
      total: '92,024 (2024)',
      reservation: {
        general: '48%',
        obc: '19%',
        sc: '13%',
        st: '7%',
        ews: '10%'
      }
    },
    officialWebsite: 'cetcell.mahacet.org',
    keyInfo: [
      'State domicile advantage available for Maharashtra students',
      'No negative marking - attempt all questions',
      '85% state quota and 15% All India quota',
      'Accepts scores from other national exams like JEE Main',
      'Separate counseling for different engineering branches',
      'Good ROI compared to national level colleges'
    ],
    preparationTips: [
      'Focus on Maharashtra State Board syllabus',
      'Practice MCQs extensively as there\'s no negative marking',
      'Solve previous 5 years MHT CET papers',
      'Time management is crucial - 3 hours for 150 questions',
      'Strong command over 11th and 12th state board curriculum',
      'Take advantage of no negative marking policy'
    ]
  },
  {
    name: 'JEE Advanced',
    fullName: 'Joint Entrance Examination Advanced',
    description: 'Premier engineering entrance exam for admission to Indian Institutes of Technology (IITs)',
    conductingBody: 'Joint Admission Board (JAB)',
    examLevel: 'National',
    bgGradient: 'from-indigo-600 via-purple-600 to-pink-600',
    accentColor: 'text-indigo-600',
    iconColor: 'text-indigo-500',
    eligibility: {
      education: 'Must qualify JEE Main and be among top 2.5 lakh',
      subjects: 'Physics, Chemistry, Mathematics',
      percentage: 'Minimum 75% in 12th (65% for SC/ST)',
      ageLimit: 'Born on or after October 1, 1999',
      attempts: 'Maximum 2 attempts in consecutive years'
    },
    examSchedule: {
      notification: 'April 2025',
      application: 'April - May 2025',
      examDates: 'May 2025 (Two papers on same day)',
      result: 'June 2025',
      counseling: 'June - July 2025'
    },
    examPattern: {
      mode: 'Computer Based Test (CBT)',
      duration: '3 hours each paper (6 hours total)',
      subjects: ['Physics', 'Chemistry', 'Mathematics'],
      totalQuestions: 54,
      totalMarks: 360,
      negativeMarking: 'Yes, varies by question type',
      languages: ['English', 'Hindi']
    },
    syllabus: {
      physics: [
        'General Physics', 'Mechanics', 'Thermal Physics', 'Electricity and Magnetism',
        'Optics', 'Modern Physics'
      ],
      chemistry: [
        'Physical Chemistry', 'Inorganic Chemistry', 'Organic Chemistry'
      ],
      mathematics: [
        'Algebra', 'Trigonometry', 'Analytical Geometry', 'Differential Calculus',
        'Integral Calculus', 'Vectors'
      ]
    },
    cutOffTrends: [
      {
        category: 'General',
        cutoff2024: 183,
        cutoff2023: 178,
        cutoff2022: 175,
        cutoff2021: 172,
        trend: 'up',
        color: 'from-red-400 to-red-600',
        expectedCutoff2025: 186
      },
      {
        category: 'OBC-NCL',
        cutoff2024: 157,
        cutoff2023: 152,
        cutoff2022: 149,
        cutoff2021: 146,
        trend: 'up',
        color: 'from-orange-400 to-orange-600',
        expectedCutoff2025: 160
      },
      {
        category: 'SC',
        cutoff2024: 114,
        cutoff2023: 109,
        cutoff2022: 107,
        cutoff2021: 104,
        trend: 'up',
        color: 'from-green-400 to-green-600',
        expectedCutoff2025: 117
      },
      {
        category: 'ST',
        cutoff2024: 97,
        cutoff2023: 94,
        cutoff2022: 91,
        cutoff2021: 89,
        trend: 'up',
        color: 'from-blue-400 to-blue-600',
        expectedCutoff2025: 100
      }
    ],
    topColleges: [
      {
        collegeName: 'IIT Bombay',
        location: 'Mumbai',
        branch: 'Computer Science',
        openingRank: 1,
        closingRank: 65,
        fees: '₹2.53L/year',
        placement: { average: '₹19.3L', highest: '₹1.68Cr', percentage: '100%' },
        rating: 5.0,
        type: 'IIT',
        website: 'www.iitb.ac.in'
      },
      {
        collegeName: 'IIT Delhi',
        location: 'New Delhi',
        branch: 'Computer Science',
        openingRank: 1,
        closingRank: 108,
        fees: '₹2.53L/year',
        placement: { average: '₹17.9L', highest: '₹1.2Cr', percentage: '100%' },
        rating: 5.0,
        type: 'IIT',
        website: 'www.iitd.ac.in'
      },
      {
        collegeName: 'IIT Madras',
        location: 'Chennai',
        branch: 'Computer Science',
        openingRank: 1,
        closingRank: 89,
        fees: '₹2.53L/year',
        placement: { average: '₹17.4L', highest: '₹1.4Cr', percentage: '100%' },
        rating: 5.0,
        type: 'IIT',
        website: 'www.iitm.ac.in'
      },
      {
        collegeName: 'IIT Kanpur',
        location: 'Kanpur',
        branch: 'Computer Science',
        openingRank: 1,
        closingRank: 156,
        fees: '₹2.53L/year',
        placement: { average: '₹16.8L', highest: '₹1.1Cr', percentage: '100%' },
        rating: 4.9,
        type: 'IIT',
        website: 'www.iitk.ac.in'
      },
      {
        collegeName: 'IIT Kharagpur',
        location: 'Kharagpur',
        branch: 'Computer Science',
        openingRank: 1,
        closingRank: 198,
        fees: '₹2.53L/year',
        placement: { average: '₹15.9L', highest: '₹89L', percentage: '98%' },
        rating: 4.9,
        type: 'IIT',
        website: 'www.iitkgp.ac.in'
      }
    ],
    fees: {
      application: '₹2800 (General), ₹1400 (Female/SC/ST/PwD)'
    },
    seats: {
      total: '16,598 (2024)',
      reservation: {
        general: '49.5%',
        obc: '27%',
        sc: '15%',
        st: '7.5%',
        ews: '10%'
      }
    },
    officialWebsite: 'jeeadv.ac.in',
    keyInfo: [
      'Most prestigious engineering entrance exam in India',
      'Only top 2.5 lakh JEE Main qualifiers eligible',
      'Direct admission to all 23 IITs',
      'Two papers on the same day with different difficulty levels',
      'Maximum 2 attempts in consecutive years',
      'Requires deep conceptual understanding'
    ],
    preparationTips: [
      'Master JEE Main level questions first',
      'Focus on concept building rather than formula memorization',
      'Practice analytical and application-based problems',
      'Solve previous 15 years JEE Advanced papers',
      'Take guidance from IIT alumni or experienced mentors',
      'Maintain physical and mental fitness during preparation'
    ]
  }
];

export const examStats = {
  totalExams: engineeringExamsData.length,
  totalSeats: '2,17,504+',
  topColleges: '500+',
  averagePackage: '₹12-15 LPA',
  successRate: '15-20%'
};

export const preparationTimeline = [
  { phase: 'Foundation (Class 11)', duration: '12 months', focus: 'NCERT + Basic Problem Solving' },
  { phase: 'Intensive (Class 12)', duration: '10 months', focus: 'Advanced Problems + Mock Tests' },
  { phase: 'Final Revision', duration: '2 months', focus: 'Revision + Test Series' },
];

export const subjectWiseTips = {
  physics: [
    'Focus on numerical problem solving',
    'Understand concepts through real-life applications',
    'Practice derivations and their applications',
    'Master coordinate geometry in physics'
  ],
  chemistry: [
    'Memorize periodic table properties',
    'Practice organic reaction mechanisms',
    'Understand chemical bonding concepts',
    'Focus on physical chemistry calculations'
  ],
  mathematics: [
    'Practice calculus applications daily',
    'Master coordinate geometry',
    'Solve integration and differentiation',
    'Focus on probability and statistics'
  ]
};