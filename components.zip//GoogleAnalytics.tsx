import { useEffect } from 'react';

declare global {
  interface Window {
    gtag: (...args: any[]) => void;
  }
}

export function GoogleAnalytics() {
  useEffect(() => {
    // Replace 'GA_MEASUREMENT_ID' with your actual Google Analytics 4 measurement ID
    const GA_MEASUREMENT_ID = 'G-XXXXXXXXXX';
    
    // Load Google Analytics script
    const script1 = document.createElement('script');
    script1.async = true;
    script1.src = `https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`;
    document.head.appendChild(script1);

    // Initialize Google Analytics
    window.gtag = window.gtag || function() {
      (window.gtag as any).q = (window.gtag as any).q || [];
      (window.gtag as any).q.push(arguments);
    };
    
    window.gtag('js', new Date());
    window.gtag('config', GA_MEASUREMENT_ID, {
      page_title: 'Career Guide After 12th',
      page_location: window.location.href,
    });

    // Track important user interactions
    const trackInteraction = (action: string, category: string) => {
      window.gtag('event', action, {
        event_category: category,
        event_label: window.location.pathname,
      });
    };

    // Track quiz start
    const quizButtons = document.querySelectorAll('[data-track="quiz-start"]');
    quizButtons.forEach(button => {
      button.addEventListener('click', () => {
        trackInteraction('quiz_started', 'engagement');
      });
    });

    // Track career exploration
    const careerCards = document.querySelectorAll('[data-track="career-explore"]');
    careerCards.forEach(card => {
      card.addEventListener('click', () => {
        trackInteraction('career_explored', 'career_guidance');
      });
    });

    // Track exam information views
    const examTabs = document.querySelectorAll('[data-track="exam-view"]');
    examTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        trackInteraction('exam_viewed', 'exam_preparation');
      });
    });

  }, []);

  return null; // This component doesn't render anything
}