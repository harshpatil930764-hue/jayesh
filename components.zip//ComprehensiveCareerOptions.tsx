import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Heart, Stethoscope, Laptop, Palette, Briefcase, Scale, 
  GraduationCap, Shield, Plane, Tractor, Camera, Utensils,
  Car, Home, Music, Gamepad2, Megaphone, Globe, 
  TrendingUp, Star, Zap, Sparkles, ChevronRight,
  Building, Microscope, Calculator, Wrench, Book
} from 'lucide-react';

const careerCategories = [
  {
    id: 'healthcare',
    title: 'Healthcare & Medical',
    emoji: '🏥',
    gradient: 'from-red-400 to-pink-500',
    bgColor: 'from-red-50 to-pink-50',
    icon: Heart,
    description: 'Heal, care, and save lives',
    careers: [
      {
        name: 'MBBS (Doctor)',
        description: 'Medical doctor treating patients and diseases',
        duration: '5.5 years',
        exams: ['NEET UG'],
        salary: '₹6-50 LPA',
        demand: 'Very High',
        eligibility: 'PCB with 50% marks'
      },
      {
        name: 'Nursing (BSc/GNM)',
        description: 'Patient care, medical assistance, healthcare support',
        duration: '3-4 years',
        exams: ['State Nursing Entrance', 'AIIMS Nursing'],
        salary: '₹2.5-8 LPA',
        demand: 'Very High',
        eligibility: 'PCB with 45% marks'
      },
      {
        name: 'Pharmacy (B.Pharm)',
        description: 'Drug development, medicine preparation, pharmaceutical research',
        duration: '4 years',
        exams: ['State CET', 'GPAT'],
        salary: '₹3-12 LPA',
        demand: 'High',
        eligibility: 'PCB/PCM with 50% marks'
      },
      {
        name: 'Physiotherapy (BPT)',
        description: 'Physical rehabilitation, movement therapy, sports medicine',
        duration: '4.5 years',
        exams: ['NEET UG', 'State CET'],
        salary: '₹2.5-10 LPA',
        demand: 'High',
        eligibility: 'PCB with 50% marks'
      },
      {
        name: 'Dental (BDS)',
        description: 'Oral health, dental surgery, teeth treatment',
        duration: '5 years',
        exams: ['NEET UG'],
        salary: '₹4-20 LPA',
        demand: 'High',
        eligibility: 'PCB with 50% marks'
      },
      {
        name: 'Veterinary (BVSC)',
        description: 'Animal healthcare, livestock management, pet care',
        duration: '5.5 years',
        exams: ['NEET UG', 'State Veterinary Entrance'],
        salary: '₹3-15 LPA',
        demand: 'Moderate',
        eligibility: 'PCB with 50% marks'
      }
    ]
  },
  {
    id: 'technology',
    title: 'Technology & IT',
    emoji: '💻',
    gradient: 'from-blue-400 to-cyan-500',
    bgColor: 'from-blue-50 to-cyan-50',
    icon: Laptop,
    description: 'Build the digital future',
    careers: [
      {
        name: 'Computer Science Engineering',
        description: 'Software development, programming, system design',
        duration: '4 years',
        exams: ['JEE Main', 'BITSAT', 'State CET'],
        salary: '₹4-30 LPA',
        demand: 'Very High',
        eligibility: 'PCM with 60% marks'
      },
      {
        name: 'Information Technology',
        description: 'IT solutions, network management, cybersecurity',
        duration: '4 years',
        exams: ['JEE Main', 'BITSAT', 'State CET'],
        salary: '₹3.5-25 LPA',
        demand: 'Very High',
        eligibility: 'PCM with 60% marks'
      },
      {
        name: 'Data Science & AI',
        description: 'Machine learning, artificial intelligence, big data analytics',
        duration: '3-4 years',
        exams: ['JEE Main', 'University Entrance'],
        salary: '₹5-35 LPA',
        demand: 'Extremely High',
        eligibility: 'PCM with 60% marks'
      },
      {
        name: 'Cybersecurity',
        description: 'Information security, ethical hacking, digital forensics',
        duration: '3-4 years',
        exams: ['University Entrance', 'Private Colleges'],
        salary: '₹4-20 LPA',
        demand: 'Very High',
        eligibility: 'PCM with 50% marks'
      },
      {
        name: 'Game Development',
        description: 'Video game design, programming, graphics development',
        duration: '3-4 years',
        exams: ['University Entrance', 'Portfolio Based'],
        salary: '₹3-18 LPA',
        demand: 'High',
        eligibility: 'Any stream with 50% marks'
      }
    ]
  },
  {
    id: 'creative',
    title: 'Creative & Design',
    emoji: '🎨',
    gradient: 'from-purple-400 to-pink-500',
    bgColor: 'from-purple-50 to-pink-50',
    icon: Palette,
    description: 'Express creativity and innovation',
    careers: [
      {
        name: 'Graphic Design',
        description: 'Visual communication, branding, digital art',
        duration: '3-4 years',
        exams: ['NIFT', 'NID DAT', 'CEED'],
        salary: '₹2.5-12 LPA',
        demand: 'High',
        eligibility: 'Any stream with 50% marks'
      },
      {
        name: 'Fashion Design',
        description: 'Clothing design, textile innovation, fashion industry',
        duration: '4 years',
        exams: ['NIFT', 'AIEED', 'Private College Entrance'],
        salary: '₹3-15 LPA',
        demand: 'Moderate',
        eligibility: 'Any stream with 50% marks'
      },
      {
        name: 'Animation & VFX',
        description: 'Digital animation, visual effects, film production',
        duration: '3-4 years',
        exams: ['University Entrance', 'Portfolio Based'],
        salary: '₹3-20 LPA',
        demand: 'High',
        eligibility: 'Any stream with 50% marks'
      },
      {
        name: 'Interior Design',
        description: 'Space planning, home decoration, commercial design',
        duration: '4 years',
        exams: ['CEED', 'NIFT', 'Private Entrance'],
        salary: '₹2.5-15 LPA',
        demand: 'Moderate',
        eligibility: 'Any stream with 50% marks'
      },
      {
        name: 'Film Making',
        description: 'Direction, cinematography, video production',
        duration: '3-4 years',
        exams: ['FTII Entrance', 'University Tests'],
        salary: '₹3-25 LPA',
        demand: 'Moderate',
        eligibility: 'Any stream with 50% marks'
      }
    ]
  },
  {
    id: 'management',
    title: 'Management & Business',
    emoji: '💼',
    gradient: 'from-green-400 to-emerald-500',
    bgColor: 'from-green-50 to-emerald-50',
    icon: Briefcase,
    description: 'Lead and manage organizations',
    careers: [
      {
        name: 'Business Administration (BBA)',
        description: 'General management, leadership, business operations',
        duration: '3 years',
        exams: ['IPU CET', 'NPAT', 'University Entrance'],
        salary: '₹3-12 LPA',
        demand: 'High',
        eligibility: 'Any stream with 50% marks'
      },
      {
        name: 'Hotel Management',
        description: 'Hospitality industry, hotel operations, tourism',
        duration: '3-4 years',
        exams: ['NCHM JEE', 'State Hotel Management'],
        salary: '₹2.5-15 LPA',
        demand: 'Moderate',
        eligibility: 'Any stream with 50% marks'
      },
      {
        name: 'Event Management',
        description: 'Event planning, coordination, entertainment industry',
        duration: '3 years',
        exams: ['University Entrance', 'Private Colleges'],
        salary: '₹2-10 LPA',
        demand: 'Moderate',
        eligibility: 'Any stream with 50% marks'
      },
      {
        name: 'Digital Marketing',
        description: 'Online marketing, social media, e-commerce',
        duration: '3 years',
        exams: ['University Entrance', 'Private Colleges'],
        salary: '₹2.5-15 LPA',
        demand: 'Very High',
        eligibility: 'Any stream with 50% marks'
      }
    ]
  },
  {
    id: 'law',
    title: 'Law & Legal',
    emoji: '⚖️',
    gradient: 'from-yellow-400 to-orange-500',
    bgColor: 'from-yellow-50 to-orange-50',
    icon: Scale,
    description: 'Justice, legal expertise, advocacy',
    careers: [
      {
        name: 'Law (BA LLB/BBA LLB)',
        description: 'Legal practice, advocacy, corporate law',
        duration: '5 years',
        exams: ['CLAT', 'AILET', 'LSAT India'],
        salary: '₹3-25 LPA',
        demand: 'High',
        eligibility: 'Any stream with 50% marks'
      },
      {
        name: 'Legal Studies',
        description: 'Paralegal work, legal research, documentation',
        duration: '3 years',
        exams: ['University Entrance'],
        salary: '₹2-8 LPA',
        demand: 'Moderate',
        eligibility: 'Any stream with 45% marks'
      }
    ]
  },
  {
    id: 'defense',
    title: 'Defense & Security',
    emoji: '🛡️',
    gradient: 'from-indigo-400 to-purple-500',
    bgColor: 'from-indigo-50 to-purple-50',
    icon: Shield,
    description: 'Serve the nation with honor',
    careers: [
      {
        name: 'Army Officer (NDA)',
        description: 'Military leadership, national defense, army operations',
        duration: '4 years',
        exams: ['NDA', 'CDS'],
        salary: '₹56,100 - ₹1,77,500 per month',
        demand: 'Moderate',
        eligibility: 'Any stream with 60% marks'
      },
      {
        name: 'Navy Officer',
        description: 'Naval operations, maritime security, ship command',
        duration: '4 years',
        exams: ['NDA', 'CDS', 'INET'],
        salary: '₹56,100 - ₹1,77,500 per month',
        demand: 'Moderate',
        eligibility: 'PCM for technical, Any for non-technical'
      },
      {
        name: 'Air Force Officer',
        description: 'Aviation, air defense, pilot training',
        duration: '4 years',
        exams: ['NDA', 'CDS', 'AFCAT'],
        salary: '₹56,100 - ₹1,77,500 per month',
        demand: 'Moderate',
        eligibility: 'PCM for technical, Any for non-technical'
      },
      {
        name: 'Police Services',
        description: 'Law enforcement, investigation, public safety',
        duration: 'Various',
        exams: ['State Police Recruitment', 'UPSC CSE'],
        salary: '₹25,000 - ₹2,00,000 per month',
        demand: 'High',
        eligibility: 'Any stream with graduation'
      }
    ]
  },
  {
    id: 'aviation',
    title: 'Aviation & Aerospace',
    emoji: '✈️',
    gradient: 'from-sky-400 to-blue-500',
    bgColor: 'from-sky-50 to-blue-50',
    icon: Plane,
    description: 'Soar high in the skies',
    careers: [
      {
        name: 'Commercial Pilot',
        description: 'Airline pilot, aircraft operation, passenger safety',
        duration: '1.5-2 years',
        exams: ['DGCA Exams', 'Medical Tests'],
        salary: '₹2-50 LPA',
        demand: 'High',
        eligibility: 'PCM with 50% marks'
      },
      {
        name: 'Air Traffic Controller',
        description: 'Aircraft traffic management, airport operations',
        duration: '1-2 years',
        exams: ['AAI ATC Exam'],
        salary: '₹40,000 - ₹1,60,000 per month',
        demand: 'Moderate',
        eligibility: 'PCM/Electronics with 60% marks'
      },
      {
        name: 'Aerospace Engineering',
        description: 'Aircraft design, space technology, rocket science',
        duration: '4 years',
        exams: ['JEE Main', 'JEE Advanced'],
        salary: '₹4-25 LPA',
        demand: 'Moderate',
        eligibility: 'PCM with 60% marks'
      },
      {
        name: 'Aircraft Maintenance',
        description: 'Aircraft servicing, technical maintenance, safety checks',
        duration: '2-3 years',
        exams: ['DGCA AME License'],
        salary: '₹3-12 LPA',
        demand: 'High',
        eligibility: 'PCM with 50% marks'
      }
    ]
  },
  {
    id: 'agriculture',
    title: 'Agriculture & Food',
    emoji: '🌾',
    gradient: 'from-green-500 to-lime-500',
    bgColor: 'from-green-50 to-lime-50',
    icon: Tractor,
    description: 'Feed the nation, grow the future',
    careers: [
      {
        name: 'Agricultural Engineering',
        description: 'Farming technology, irrigation, crop production',
        duration: '4 years',
        exams: ['JEE Main', 'State Agriculture Entrance'],
        salary: '₹3-12 LPA',
        demand: 'Moderate',
        eligibility: 'PCM with 50% marks'
      },
      {
        name: 'Food Technology',
        description: 'Food processing, quality control, nutrition science',
        duration: '4 years',
        exams: ['JEE Main', 'State Entrance'],
        salary: '₹3-15 LPA',
        demand: 'High',
        eligibility: 'PCB/PCM with 50% marks'
      },
      {
        name: 'Horticulture',
        description: 'Fruit cultivation, vegetable farming, landscaping',
        duration: '4 years',
        exams: ['State Agriculture Entrance'],
        salary: '₹2.5-10 LPA',
        demand: 'Moderate',
        eligibility: 'PCB with 50% marks'
      },
      {
        name: 'Dairy Technology',
        description: 'Milk processing, dairy farm management, animal nutrition',
        duration: '4 years',
        exams: ['State Agriculture Entrance'],
        salary: '₹2.5-12 LPA',
        demand: 'Moderate',
        eligibility: 'PCB with 50% marks'
      }
    ]
  }
];

export function ComprehensiveCareerOptions() {
  const [selectedCategory, setSelectedCategory] = useState(0);

  const CareerCard = ({ career, categoryGradient }: { career: any; categoryGradient: string }) => (
    <Card className="h-full bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg font-bold text-gray-800 mb-2">{career.name}</CardTitle>
            <CardDescription className="text-gray-600 text-sm">{career.description}</CardDescription>
          </div>
          <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${categoryGradient} flex items-center justify-center`}>
            <Star className="h-6 w-6 text-white" />
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-blue-50 rounded-lg p-3">
            <p className="text-xs text-blue-600 font-semibold mb-1">Duration</p>
            <p className="text-sm font-bold text-blue-800">{career.duration}</p>
          </div>
          <div className="bg-green-50 rounded-lg p-3">
            <p className="text-xs text-green-600 font-semibold mb-1">Salary Range</p>
            <p className="text-sm font-bold text-green-800">{career.salary}</p>
          </div>
        </div>
        
        <div>
          <p className="text-xs text-gray-600 font-semibold mb-2">Entrance Exams</p>
          <div className="flex flex-wrap gap-1">
            {career.exams.map((exam: string, index: number) => (
              <Badge key={index} className={`bg-gradient-to-r ${categoryGradient} text-white border-0 text-xs`}>
                {exam}
              </Badge>
            ))}
          </div>
        </div>
        
        <div className="flex justify-between items-center">
          <div>
            <p className="text-xs text-gray-600 mb-1">Job Demand</p>
            <div className="flex items-center gap-1">
              <div className={`w-2 h-2 rounded-full ${
                career.demand === 'Very High' || career.demand === 'Extremely High' ? 'bg-green-500' :
                career.demand === 'High' ? 'bg-yellow-500' : 'bg-orange-500'
              }`}></div>
              <span className="text-sm font-medium text-gray-700">{career.demand}</span>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-600 mb-1">Eligibility</p>
            <p className="text-xs font-medium text-gray-700">{career.eligibility}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 via-purple-50 to-blue-50">
      <div className="container mx-auto px-4">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-full mb-6 shadow-lg">
            <Sparkles className="h-5 w-5" />
            <span className="font-bold">Complete Career Guide After 12th</span>
            <Sparkles className="h-5 w-5" />
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
            <span className="block bg-gradient-to-r from-purple-600 via-blue-600 to-green-600 bg-clip-text text-transparent">
              150+ Amazing Career Options
            </span>
            <span className="block text-gray-800 mt-2">Beyond Engineering & Medical! 🚀</span>
          </h2>
          
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Discover incredible opportunities in 
            <span className="text-transparent bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text font-semibold"> healthcare</span>, 
            <span className="text-transparent bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text font-semibold"> technology</span>, 
            <span className="text-transparent bg-gradient-to-r from-green-600 to-pink-600 bg-clip-text font-semibold"> creative fields</span>, and many more!
          </p>
        </div>

        {/* Category Tabs */}
        <div className="max-w-7xl mx-auto">
          <Tabs value={selectedCategory.toString()} onValueChange={(value) => setSelectedCategory(parseInt(value))}>
            {/* Enhanced Tab List */}
            <div className="mb-12 overflow-x-auto">
              <TabsList className="grid grid-cols-4 lg:grid-cols-8 gap-2 bg-transparent h-auto p-0 min-w-max">
                {careerCategories.map((category, index) => (
                  <TabsTrigger 
                    key={index} 
                    value={index.toString()} 
                    className={`
                      flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all duration-300 min-w-32
                      ${selectedCategory === index 
                        ? `bg-gradient-to-br ${category.bgColor} border-transparent shadow-lg scale-105` 
                        : 'bg-white/80 border-gray-200 hover:border-gray-300 hover:shadow-md'
                      }
                    `}
                  >
                    <span className="text-3xl">{category.emoji}</span>
                    <div className="text-center">
                      <div className="font-bold text-sm">{category.title}</div>
                      <div className="text-xs text-gray-600 mt-1">{category.description}</div>
                    </div>
                  </TabsTrigger>
                ))}
              </TabsList>
            </div>

            {/* Tab Content */}
            {careerCategories.map((category, index) => (
              <TabsContent key={index} value={index.toString()}>
                <div className={`bg-gradient-to-br ${category.bgColor} rounded-2xl p-8 mb-8`}>
                  <div className="text-center mb-8">
                    <div className="flex items-center justify-center gap-3 mb-4">
                      <span className="text-5xl">{category.emoji}</span>
                      <h3 className="text-3xl font-bold text-gray-800">{category.title}</h3>
                    </div>
                    <p className="text-lg text-gray-600 max-w-2xl mx-auto">{category.description}</p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {category.careers.map((career, careerIndex) => (
                      <CareerCard 
                        key={careerIndex} 
                        career={career} 
                        categoryGradient={category.gradient}
                      />
                    ))}
                  </div>
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>

        {/* Call to Action */}
        <div className="max-w-4xl mx-auto mt-16">
          <Card className="bg-gradient-to-r from-purple-500 via-blue-500 to-green-500 text-white border-0 shadow-2xl overflow-hidden">
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMjAiIGN5PSIyMCIgcj0iMiIgZmlsbD0iI2ZmZmZmZiIgZmlsbC1vcGFjaXR5PSIwLjEiLz4KPC9zdmc+')] opacity-30"></div>
            
            <CardContent className="relative z-10 text-center py-12">
              <div className="flex items-center justify-center gap-2 mb-6">
                <Zap className="h-8 w-8 animate-pulse" />
                <h3 className="text-3xl font-bold">Ready to Choose Your Perfect Career?</h3>
                <Zap className="h-8 w-8 animate-pulse" />
              </div>
              
              <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
                Take our comprehensive career assessment to discover which of these amazing career paths aligns perfectly with your interests, skills, and dreams!
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg" 
                  className="bg-white text-purple-600 hover:bg-gray-100 px-8 py-4 text-lg font-bold shadow-xl transform hover:scale-105 transition-all duration-300"
                >
                  🎯 Take Career Assessment
                  <ChevronRight className="h-5 w-5 ml-2" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline"
                  className="border-2 border-white text-white hover:bg-white hover:text-purple-600 px-8 py-4 text-lg font-bold transition-all duration-300"
                >
                  📚 Download Career Guide
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}