import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { CheckCircle } from 'lucide-react';
import { quizRecommendations } from '../data/quizData';

interface QuizResultProps {
  result: string;
  onReset: () => void;
}

export function QuizResult({ result, onReset }: QuizResultProps) {
  const recommendation = quizRecommendations[result as keyof typeof quizRecommendations];
  
  return (
    <Card>
      <CardHeader className="text-center">
        <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-green-100">
          <CheckCircle className="h-6 w-6 text-green-600" />
        </div>
        <CardTitle className="text-2xl">Quiz Complete!</CardTitle>
        <CardDescription>Here's your personalized career recommendation</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="text-center">
          <h3 className="text-xl font-semibold mb-2">Recommended Stream: {recommendation.title}</h3>
          <p className="text-muted-foreground mb-4">{recommendation.description}</p>
        </div>
        
        <div>
          <h4 className="font-semibold mb-2">Top Career Options for You:</h4>
          <div className="grid grid-cols-2 gap-2">
            {recommendation.careers.map((career, index) => (
              <div key={index} className="bg-muted/50 rounded p-2 text-sm text-center">
                {career}
              </div>
            ))}
          </div>
        </div>
        
        <div className="flex gap-4">
          <Button onClick={onReset} variant="outline" className="flex-1">
            Retake Quiz
          </Button>
          <Button className="flex-1">
            Explore This Stream
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}