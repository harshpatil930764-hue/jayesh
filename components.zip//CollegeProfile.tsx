import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { 
  ArrowLeft, 
  Star, 
  MapPin, 
  Users, 
  Calendar, 
  Award, 
  Building, 
  BookOpen, 
  TrendingUp, 
  IndianRupee,
  Phone,
  Mail,
  Globe,
  ChevronRight,
  Download,
  Share2,
  Heart,
  Check,
  X,
  Wifi,
  Car,
  Utensils,
  Home,
  Dumbbell,
  Bus,
  Shield,
  Microscope,
  Computer,
  Lightbulb,
  Monitor
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface CollegeProfileProps {
  college: {
    id: string;
    name: string;
    location: string;
    state: string;
    type: 'Government' | 'Private' | 'Deemed' | 'Central';
    courses: string[];
    ranking: number;
    rating: number;
    fees: string;
    placements: string;
    website: string;
    established: number;
    affiliation: string;
    specialization: string[];
    admissionProcess: string;
    totalSeats: number;
  };
  onClose: () => void;
}

export function CollegeProfile({ college, onClose }: CollegeProfileProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [isFavorite, setIsFavorite] = useState(false);

  // KBT College specific data (expanded for demonstration)
  const collegeDetails = {
    description: "K.B.T College of Engineering, Nashik is one of the leading engineering institutions in Maharashtra, offering quality technical education since 2001. The college is affiliated to Savitribai Phule Pune University and is known for its excellent faculty, modern infrastructure, and strong industry connections.",
    
    highlights: [
      "NAAC Accredited with 'A' Grade",
      "NBA Accredited Programs", 
      "AICTE Approved",
      "ISO 9001:2015 Certified",
      "100% Placement Assistance",
      "Research & Development Cell",
      "International Collaborations",
      "Industry-Oriented Curriculum"
    ],

    facilities: [
      { name: "Wi-Fi Campus", icon: Wifi, available: true },
      { name: "Transportation", icon: Bus, available: true },
      { name: "Hostel", icon: Home, available: true },
      { name: "Cafeteria", icon: Utensils, available: true },
      { name: "Sports Complex", icon: Dumbbell, available: true },
      { name: "Parking", icon: Car, available: true },
      { name: "Medical Facility", icon: Shield, available: true },
      { name: "Library", icon: BookOpen, available: true },
      { name: "Computer Labs", icon: Computer, available: true },
      { name: "Research Labs", icon: Microscope, available: true },
      { name: "Auditorium", icon: Monitor, available: true },
      { name: "Innovation Cell", icon: Lightbulb, available: true }
    ],

    departments: [
      {
        name: "Computer Science & Engineering",
        seats: 120,
        duration: "4 Years",
        accreditation: "NBA Accredited"
      },
      {
        name: "Information Technology",
        seats: 60,
        duration: "4 Years", 
        accreditation: "NBA Accredited"
      },
      {
        name: "Electronics & Telecommunication",
        seats: 60,
        duration: "4 Years",
        accreditation: "NBA Accredited"
      },
      {
        name: "Mechanical Engineering",
        seats: 120,
        duration: "4 Years",
        accreditation: "NBA Accredited"
      },
      {
        name: "Civil Engineering",
        seats: 60,
        duration: "4 Years",
        accreditation: "AICTE Approved"
      },
      {
        name: "Electrical Engineering",
        seats: 120,
        duration: "4 Years",
        accreditation: "AICTE Approved"
      }
    ],

    placementStats: {
      averagePackage: "4.5 LPA",
      highestPackage: "12 LPA", 
      placementRate: "85%",
      totalCompanies: 120,
      topRecruiters: ["TCS", "Infosys", "Wipro", "L&T", "Mahindra", "Bajaj", "Tech Mahindra", "Capgemini"]
    },

    admissionStats: {
      cutoffGeneral: "85.5 percentile",
      cutoffOBC: "78.2 percentile",
      cutoffSC: "65.8 percentile",
      cutoffST: "62.3 percentile",
      applicationDeadline: "July 15, 2025",
      counsellingRounds: 3
    },

    gallery: [
      {
        url: "https://images.unsplash.com/photo-1649259406421-922f26d4c39a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbmdpbmVlcmluZyUyMGNvbGxlZ2UlMjBidWlsZGluZyUyMGNhbXB1c3xlbnwxfHx8fDE3NTc3NDYwNTB8MA&ixlib=rb-4.1.0&q=80&w=1080",
        title: "Main Campus Building",
        description: "Modern infrastructure with state-of-the-art facilities"
      },
      {
        url: "https://images.unsplash.com/photo-1661475765552-9a0c80c8b44e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbmdpbmVlcmluZyUyMGNvbGxlZ2UlMjBjbGFzc3Jvb20lMjBsYWJ8ZW58MXx8fHwxNzU3NzQ2MDUzfDA&ixlib=rb-4.1.0&q=80&w=1080",
        title: "Engineering Laboratory",
        description: "Well-equipped labs for practical learning"
      },
      {
        url: "https://images.unsplash.com/photo-1722248540590-ba8b7af1d7b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwbGlicmFyeSUyMHN0dWRlbnRzJTIwc3R1ZHlpbmd8ZW58MXx8fHwxNzU3NzQ2MDU2fDA&ixlib=rb-4.1.0&q=80&w=1080",
        title: "Central Library",
        description: "Extensive collection of books and digital resources"
      },
      {
        url: "https://images.unsplash.com/photo-1627889587269-1ec7c8b29049?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbmdpbmVlcmluZyUyMGNvbGxlZ2UlMjBob3N0ZWwlMjBkb3JtaXRvcnl8ZW58MXx8fHwxNzU3NzQ2MDU5fDA&ixlib=rb-4.1.0&q=80&w=1080",
        title: "Student Hostel",
        description: "Comfortable accommodation for students"
      },
      {
        url: "https://images.unsplash.com/photo-1652817599311-7f52493beb90?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwc3BvcnRzJTIwZ3JvdW5kJTIwcGxheWdyb3VuZHxlbnwxfHx8fDE3NTc3NDYwNjJ8MA&ixlib=rb-4.1.0&q=80&w=1080",
        title: "Sports Complex",
        description: "Multi-sport facilities for student recreation"
      },
      {
        url: "https://images.unsplash.com/photo-1731834453355-df041245e7d7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwY29tcHV0ZXIlMjBsYWIlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc1Nzc0NjA2NXww&ixlib=rb-4.1.0&q=80&w=1080",
        title: "Computer Lab",
        description: "Latest technology and software for hands-on learning"
      }
    ],

    fees: {
      tuitionFee: "₹85,000",
      developmentFee: "₹15,000",
      examFee: "₹8,000",
      otherFees: "₹7,000",
      totalFirstYear: "₹1,15,000",
      hostelFee: "₹45,000",
      messFee: "₹35,000"
    },

    contact: {
      address: "Survey No. 35, Mohadi, Tal-Deola, Nashik - 422101, Maharashtra",
      phone: "+91-2550-123456",
      email: "info@kbtcoe.org",
      website: "www.kbtcoe.org"
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 overflow-y-auto">
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm border-b border-gray-200 shadow-sm">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={onClose}
                  className="hover:bg-gray-100"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Search
                </Button>
                <div className="h-6 w-px bg-gray-300"></div>
                <div>
                  <h1 className="font-bold text-lg">{college.name}</h1>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <MapPin className="h-3 w-3" />
                    {college.location}, {college.state}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsFavorite(!isFavorite)}
                  className={isFavorite ? "bg-red-50 border-red-200 text-red-600" : ""}
                >
                  <Heart className={`h-4 w-4 mr-2 ${isFavorite ? 'fill-current' : ''}`} />
                  {isFavorite ? 'Saved' : 'Save'}
                </Button>
                <Button variant="outline" size="sm">
                  <Share2 className="h-4 w-4 mr-2" />
                  Share
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Brochure
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-6">
          {/* Hero Section */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            {/* Main Image */}
            <div className="lg:col-span-2">
              <div className="relative rounded-xl overflow-hidden shadow-lg">
                <ImageWithFallback
                  src={collegeDetails.gallery[0].url}
                  alt={collegeDetails.gallery[0].title}
                  className="w-full h-80 object-cover"
                />
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="bg-white/90 backdrop-blur-sm rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h2 className="font-bold text-lg">{college.name}</h2>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <MapPin className="h-3 w-3" />
                          {college.location}, {college.state}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center gap-1 mb-1">
                          <Star className="h-4 w-4 text-yellow-500 fill-current" />
                          <span className="font-bold">{college.rating}</span>
                        </div>
                        <div className="text-xs text-gray-500">#{college.ranking} Ranking</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Info */}
            <div className="space-y-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Quick Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Established</span>
                    <span className="font-medium">{college.established}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Type</span>
                    <Badge variant="outline" className="text-xs">{college.type}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Total Seats</span>
                    <span className="font-medium">{college.totalSeats}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Admission</span>
                    <span className="font-medium text-blue-600">{college.admissionProcess}</span>
                  </div>
                  <div className="border-t pt-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Annual Fees</span>
                      <span className="font-bold text-green-600">{college.fees}</span>
                    </div>
                    <div className="flex justify-between items-center mt-1">
                      <span className="text-sm text-gray-600">Avg Package</span>
                      <span className="font-bold text-blue-600">{college.placements}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Apply Now</CardTitle>
                </CardHeader>
                <CardContent>
                  <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                    Start Application
                  </Button>
                  <p className="text-xs text-gray-500 mt-2 text-center">
                    Application Deadline: {collegeDetails.admissionStats.applicationDeadline}
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Tabs Section */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="courses">Courses</TabsTrigger>
              <TabsTrigger value="admissions">Admissions</TabsTrigger>
              <TabsTrigger value="placements">Placements</TabsTrigger>
              <TabsTrigger value="facilities">Facilities</TabsTrigger>
              <TabsTrigger value="gallery">Gallery</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>About {college.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    {collegeDetails.description}
                  </p>
                  
                  <h4 className="font-semibold mb-3">Key Highlights</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {collegeDetails.highlights.map((highlight, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-600" />
                        <span className="text-sm">{highlight}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">College Statistics</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Student Enrollment</span>
                      <span className="font-bold">2,500+</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Faculty Members</span>
                      <span className="font-bold">180+</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Departments</span>
                      <span className="font-bold">6</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Alumni Network</span>
                      <span className="font-bold">12,000+</span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Contact Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-start gap-3">
                      <MapPin className="h-4 w-4 text-gray-500 mt-1" />
                      <span className="text-sm">{collegeDetails.contact.address}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Phone className="h-4 w-4 text-gray-500" />
                      <span className="text-sm">{collegeDetails.contact.phone}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Mail className="h-4 w-4 text-gray-500" />
                      <span className="text-sm">{collegeDetails.contact.email}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Globe className="h-4 w-4 text-gray-500" />
                      <span className="text-sm text-blue-600">{collegeDetails.contact.website}</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Courses Tab */}
            <TabsContent value="courses" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Departments & Programs</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4">
                    {collegeDetails.departments.map((dept, index) => (
                      <div key={index} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold">{dept.name}</h4>
                          <Badge variant="outline" className="text-xs">{dept.accreditation}</Badge>
                        </div>
                        <div className="grid grid-cols-3 gap-4 text-sm text-gray-600">
                          <div>
                            <span className="font-medium">Duration:</span> {dept.duration}
                          </div>
                          <div>
                            <span className="font-medium">Seats:</span> {dept.seats}
                          </div>
                          <div>
                            <span className="font-medium">Degree:</span> B.Tech
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Admissions Tab */}
            <TabsContent value="admissions" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Admission Process</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2">Eligibility Criteria</h4>
                      <ul className="text-sm text-gray-600 space-y-1">
                        <li>• 12th pass with Physics, Chemistry & Mathematics</li>
                        <li>• Minimum 45% marks in 12th (40% for reserved)</li>
                        <li>• Valid MHT-CET score</li>
                        <li>• Age limit: 17-25 years</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2">Application Process</h4>
                      <ol className="text-sm text-gray-600 space-y-1">
                        <li>1. Fill online application form</li>
                        <li>2. Pay application fee (₹1,000)</li>
                        <li>3. Upload required documents</li>
                        <li>4. Attend counselling rounds</li>
                        <li>5. Document verification</li>
                        <li>6. Fee payment & admission</li>
                      </ol>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Cutoff Trends (2024)</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">General Category</span>
                      <span className="font-medium">{collegeDetails.admissionStats.cutoffGeneral}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">OBC Category</span>
                      <span className="font-medium">{collegeDetails.admissionStats.cutoffOBC}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">SC Category</span>
                      <span className="font-medium">{collegeDetails.admissionStats.cutoffSC}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">ST Category</span>
                      <span className="font-medium">{collegeDetails.admissionStats.cutoffST}</span>
                    </div>
                    <div className="border-t pt-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Counselling Rounds</span>
                        <span className="font-medium">{collegeDetails.admissionStats.counsellingRounds}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Fee Structure (2024-25)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium mb-3">Academic Fees (Annual)</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Tuition Fee</span>
                          <span>{collegeDetails.fees.tuitionFee}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Development Fee</span>
                          <span>{collegeDetails.fees.developmentFee}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Exam Fee</span>
                          <span>{collegeDetails.fees.examFee}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Other Fees</span>
                          <span>{collegeDetails.fees.otherFees}</span>
                        </div>
                        <div className="border-t pt-2 flex justify-between font-semibold">
                          <span>Total (First Year)</span>
                          <span className="text-green-600">{collegeDetails.fees.totalFirstYear}</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-medium mb-3">Accommodation Fees (Annual)</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Hostel Fee</span>
                          <span>{collegeDetails.fees.hostelFee}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Mess Fee</span>
                          <span>{collegeDetails.fees.messFee}</span>
                        </div>
                        <div className="border-t pt-2 flex justify-between font-semibold">
                          <span>Total Accommodation</span>
                          <span className="text-blue-600">₹80,000</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Placements Tab */}
            <TabsContent value="placements" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <Card className="text-center">
                  <CardContent className="pt-6">
                    <div className="text-2xl font-bold text-blue-600 mb-1">{collegeDetails.placementStats.placementRate}</div>
                    <div className="text-sm text-gray-600">Placement Rate</div>
                  </CardContent>
                </Card>
                <Card className="text-center">
                  <CardContent className="pt-6">
                    <div className="text-2xl font-bold text-green-600 mb-1">{collegeDetails.placementStats.averagePackage}</div>
                    <div className="text-sm text-gray-600">Average Package</div>
                  </CardContent>
                </Card>
                <Card className="text-center">
                  <CardContent className="pt-6">
                    <div className="text-2xl font-bold text-purple-600 mb-1">{collegeDetails.placementStats.highestPackage}</div>
                    <div className="text-sm text-gray-600">Highest Package</div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Top Recruiting Companies</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {collegeDetails.placementStats.topRecruiters.map((company, index) => (
                      <div key={index} className="border rounded-lg p-3 text-center hover:bg-gray-50 transition-colors">
                        <div className="font-medium text-sm">{company}</div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 text-center">
                    <Button variant="outline" size="sm">
                      View All {collegeDetails.placementStats.totalCompanies}+ Companies
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Department-wise Placement Statistics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {collegeDetails.departments.slice(0, 4).map((dept, index) => {
                      const placementPercentages = [92, 88, 85, 83];
                      return (
                        <div key={index} className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-sm font-medium">{dept.name}</span>
                            <span className="text-sm text-gray-600">{placementPercentages[index]}%</span>
                          </div>
                          <Progress value={placementPercentages[index]} className="h-2" />
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Facilities Tab */}
            <TabsContent value="facilities" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Campus Facilities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {collegeDetails.facilities.map((facility, index) => (
                      <div key={index} className="flex items-center gap-3 p-3 border rounded-lg hover:bg-gray-50 transition-colors">
                        <div className={`p-2 rounded-lg ${facility.available ? 'bg-green-100' : 'bg-red-100'}`}>
                          <facility.icon className={`h-5 w-5 ${facility.available ? 'text-green-600' : 'text-red-600'}`} />
                        </div>
                        <div className="flex-1">
                          <div className="font-medium text-sm">{facility.name}</div>
                          <div className={`text-xs ${facility.available ? 'text-green-600' : 'text-red-600'}`}>
                            {facility.available ? 'Available' : 'Not Available'}
                          </div>
                        </div>
                        {facility.available ? 
                          <Check className="h-4 w-4 text-green-600" /> : 
                          <X className="h-4 w-4 text-red-600" />
                        }
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Gallery Tab */}
            <TabsContent value="gallery" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {collegeDetails.gallery.map((image, index) => (
                  <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="relative">
                      <ImageWithFallback
                        src={image.url}
                        alt={image.title}
                        className="w-full h-48 object-cover"
                      />
                    </div>
                    <CardContent className="p-4">
                      <h4 className="font-semibold mb-1">{image.title}</h4>
                      <p className="text-sm text-gray-600">{image.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}