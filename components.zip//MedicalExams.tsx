import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import { Separator } from './ui/separator';
import { 
  Calendar, 
  Clock, 
  Users, 
  DollarSign, 
  ExternalLink, 
  BookOpen, 
  AlertCircle, 
  TrendingUp, 
  TrendingDown, 
  Minus,
  Trophy,
  Target,
  BarChart3,
  GraduationCap,
  Building,
  Star,
  FileText,
  CheckCircle,
  MapPin,
  Briefcase,
  School,
  Heart,
  Activity,
  Stethoscope,
  Brain,
  Zap,
  Award,
  UserCheck,
  BookOpenCheck
} from 'lucide-react';
import { medicalExamsData, medicalExamStats, type MedicalExamDetails, type MedicalCutOffTrend, type MedicalCollegeCutOff } from '../data/medicalExamsData';

export function MedicalExams() {
  const [selectedExam, setSelectedExam] = useState(0);
  const [selectedCutoffCategory, setSelectedCutoffCategory] = useState('all');
  const [highlightedTab, setHighlightedTab] = useState<number | null>(null);

  // Function to highlight exam based on name
  const highlightExamByName = (examName: string) => {
    const examMap: { [key: string]: number } = {
      'NEET': 0,
      'NEET UG': 0,
      'AIIMS': 1,
      'AIIMS INI-CET': 1,
      'JIPMER': 0, // Maps to NEET as JIPMER now uses NEET scores
      'FMGE': 2
    };
    
    const tabIndex = examMap[examName];
    if (tabIndex !== undefined) {
      setSelectedExam(tabIndex);
      setHighlightedTab(tabIndex);
      
      // Remove highlight after 3 seconds
      setTimeout(() => {
        setHighlightedTab(null);
      }, 3000);
    }
  };

  // Listen for navigation from career streams
  useEffect(() => {
    const handleExamNavigation = (event: CustomEvent) => {
      highlightExamByName(event.detail.examName);
    };

    window.addEventListener('navigateToExam', handleExamNavigation as EventListener);
    
    return () => {
      window.removeEventListener('navigateToExam', handleExamNavigation as EventListener);
    };
  }, []);

  const TrendIcon = ({ trend }: { trend: 'up' | 'down' | 'stable' }) => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="h-3 w-3 text-green-600" />;
      case 'down':
        return <TrendingDown className="h-3 w-3 text-red-600" />;
      default:
        return <Minus className="h-3 w-3 text-gray-600" />;
    }
  };

  const CutoffTrendsTable = ({ trends }: { trends: MedicalCutOffTrend[] }) => {
    const filteredTrends = selectedCutoffCategory === 'all' 
      ? trends 
      : trends.filter(trend => trend.category.toLowerCase().includes(selectedCutoffCategory.toLowerCase()));

    return (
      <div className="space-y-4">
        <div className="flex flex-wrap gap-2 mb-4">
          {['all', 'general', 'obc', 'sc', 'st', 'ews'].map((category) => (
            <Button
              key={category}
              variant={selectedCutoffCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCutoffCategory(category)}
              className="capitalize"
            >
              {category === 'all' ? 'All Categories' : category.toUpperCase()}
            </Button>
          ))}
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gradient-to-r from-red-50 to-pink-50">
                <th className="border border-red-200 p-3 text-left font-semibold text-red-800">Category</th>
                <th className="border border-red-200 p-3 text-center font-semibold text-red-800">2024</th>
                <th className="border border-red-200 p-3 text-center font-semibold text-red-800">2023</th>
                <th className="border border-red-200 p-3 text-center font-semibold text-red-800">2022</th>
                <th className="border border-red-200 p-3 text-center font-semibold text-red-800">2021</th>
                <th className="border border-red-200 p-3 text-center font-semibold text-red-800">Trend</th>
                <th className="border border-red-200 p-3 text-center font-semibold text-red-800">Expected 2025</th>
              </tr>
            </thead>
            <tbody>
              {filteredTrends.map((trend, index) => (
                <tr key={index} className="hover:bg-red-50 transition-colors">
                  <td className="border border-red-200 p-3 font-medium">{trend.category}</td>
                  <td className="border border-red-200 p-3 text-center font-bold text-red-600">{trend.cutoff2024}</td>
                  <td className="border border-red-200 p-3 text-center">{trend.cutoff2023}</td>
                  <td className="border border-red-200 p-3 text-center">{trend.cutoff2022}</td>
                  <td className="border border-red-200 p-3 text-center">{trend.cutoff2021}</td>
                  <td className="border border-red-200 p-3 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <TrendIcon trend={trend.trend} />
                      <span className={`text-sm font-medium ${
                        trend.trend === 'up' ? 'text-green-600' : 
                        trend.trend === 'down' ? 'text-red-600' : 'text-gray-600'
                      }`}>
                        {trend.trend}
                      </span>
                    </div>
                  </td>
                  <td className="border border-red-200 p-3 text-center font-bold text-blue-600">
                    {trend.expectedCutoff2025 || 'TBA'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const CollegeListTable = ({ colleges }: { colleges: MedicalCollegeCutOff[] }) => (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-gradient-to-r from-blue-50 to-indigo-50">
            <th className="border border-blue-200 p-3 text-left font-semibold text-blue-800">College</th>
            <th className="border border-blue-200 p-3 text-center font-semibold text-blue-800">Course</th>
            <th className="border border-blue-200 p-3 text-center font-semibold text-blue-800">Opening Rank</th>
            <th className="border border-blue-200 p-3 text-center font-semibold text-blue-800">Closing Rank</th>
            <th className="border border-blue-200 p-3 text-center font-semibold text-blue-800">Fees/Year</th>
            <th className="border border-blue-200 p-3 text-center font-semibold text-blue-800">Type</th>
            <th className="border border-blue-200 p-3 text-center font-semibold text-blue-800">Rating</th>
            <th className="border border-blue-200 p-3 text-center font-semibold text-blue-800">Seats</th>
          </tr>
        </thead>
        <tbody>
          {colleges.map((college, index) => (
            <tr key={index} className="hover:bg-blue-50 transition-colors">
              <td className="border border-blue-200 p-3">
                <div>
                  <div className="font-medium text-blue-900">{college.collegeName}</div>
                  <div className="text-sm text-blue-600 flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {college.location}
                  </div>
                </div>
              </td>
              <td className="border border-blue-200 p-3 text-center font-medium">{college.course}</td>
              <td className="border border-blue-200 p-3 text-center font-bold text-green-600">{college.openingRank}</td>
              <td className="border border-blue-200 p-3 text-center font-bold text-red-600">{college.closingRank}</td>
              <td className="border border-blue-200 p-3 text-center font-semibold text-purple-600">{college.fees}</td>
              <td className="border border-blue-200 p-3 text-center">
                <Badge variant="outline" className={`
                  ${college.type === 'AIIMS' ? 'bg-red-100 text-red-800 border-red-300' : ''}
                  ${college.type === 'Government' ? 'bg-green-100 text-green-800 border-green-300' : ''}
                  ${college.type === 'Private' ? 'bg-blue-100 text-blue-800 border-blue-300' : ''}
                  ${college.type === 'Deemed' ? 'bg-purple-100 text-purple-800 border-purple-300' : ''}
                  ${college.type === 'Central' ? 'bg-orange-100 text-orange-800 border-orange-300' : ''}
                `}>
                  {college.type}
                </Badge>
              </td>
              <td className="border border-blue-200 p-3 text-center">
                <div className="flex items-center justify-center gap-1">
                  <Star className="h-4 w-4 text-yellow-500 fill-current" />
                  <span className="font-medium">{college.rating}</span>
                </div>
              </td>
              <td className="border border-blue-200 p-3 text-center font-bold text-indigo-600">{college.seats}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  const ExamCard = ({ exam, index }: { exam: MedicalExamDetails; index: number }) => (
    <Card className="bg-gradient-to-br from-red-50 via-pink-50 to-red-100 border border-red-200 shadow-xl hover:shadow-2xl transition-all duration-300">
      <CardHeader className="bg-gradient-to-r from-red-500 via-pink-500 to-red-600 text-white">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-2xl font-bold flex items-center gap-2">
              <Heart className="h-6 w-6" />
              {exam.name}
            </CardTitle>
            <CardDescription className="text-red-100 text-lg mt-1">
              {exam.fullName}
            </CardDescription>
          </div>
          <div className="text-right">
            <div className="bg-white/20 rounded-lg p-2">
              <div className="text-sm opacity-90">Exam Level</div>
              <div className="font-bold">{exam.examLevel}</div>
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-6">
        <div className="mb-6">
          <p className="text-gray-700 leading-relaxed">{exam.description}</p>
          <div className="mt-4 flex items-center gap-2 text-sm">
            <Building className="h-4 w-4 text-red-600" />
            <span className="font-medium text-red-800">Conducted by: {exam.conductingBody}</span>
          </div>
        </div>

        <Accordion type="single" collapsible className="space-y-4">
          {/* Key Information */}
          <AccordionItem value="key-info" className="border-0">
            <AccordionTrigger className="text-left bg-gradient-to-r from-red-50 to-pink-50 px-4 py-3 rounded-lg hover:from-red-100 hover:to-pink-100 transition-colors border border-red-200">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-red-600" />
                <span className="font-semibold text-red-800">📋 Key Information</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 py-4 bg-gradient-to-br from-red-50/50 to-pink-50/50 rounded-b-lg">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="p-4 bg-white/80 border border-red-200">
                  <h5 className="font-semibold text-red-800 mb-3 flex items-center gap-2">
                    <School className="h-4 w-4" />
                    🎓 Eligibility Criteria
                  </h5>
                  <div className="space-y-2 text-sm">
                    <div><strong>Education:</strong> {exam.eligibility.education}</div>
                    <div><strong>Subjects:</strong> {exam.eligibility.subjects}</div>
                    <div><strong>Percentage:</strong> {exam.eligibility.percentage}</div>
                    <div><strong>Age Limit:</strong> {exam.eligibility.ageLimit}</div>
                    <div><strong>Attempts:</strong> {exam.eligibility.attempts}</div>
                  </div>
                </Card>
                
                <Card className="p-4 bg-white/80 border border-red-200">
                  <h5 className="font-semibold text-red-800 mb-3 flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    📅 Important Dates
                  </h5>
                  <div className="space-y-2 text-sm">
                    <div><strong>Notification:</strong> {exam.examSchedule.notification}</div>
                    <div><strong>Application:</strong> {exam.examSchedule.application}</div>
                    <div><strong>Exam Dates:</strong> {exam.examSchedule.examDates}</div>
                    <div><strong>Result:</strong> {exam.examSchedule.result}</div>
                    <div><strong>Counseling:</strong> {exam.examSchedule.counseling}</div>
                  </div>
                </Card>
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* Exam Pattern */}
          <AccordionItem value="exam-pattern" className="border-0">
            <AccordionTrigger className="text-left bg-gradient-to-r from-purple-50 to-pink-50 px-4 py-3 rounded-lg hover:from-purple-100 hover:to-pink-100 transition-colors border border-purple-200">
              <div className="flex items-center gap-2">
                <Brain className="h-5 w-5 text-purple-600" />
                <span className="font-semibold text-purple-800">🧠 Exam Pattern & Structure</span>
                <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white ml-2">
                  {exam.examPattern.totalQuestions} Questions
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 py-4 bg-gradient-to-br from-purple-50/50 to-pink-50/50 rounded-b-lg">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <Card className="p-3 bg-white/60 border border-purple-200">
                  <h5 className="font-semibold text-sm text-purple-700 mb-1">⏱️ Duration</h5>
                  <p className="text-sm">{exam.examPattern.duration}</p>
                </Card>
                <Card className="p-3 bg-white/60 border border-purple-200">
                  <h5 className="font-semibold text-sm text-purple-700 mb-1">📊 Total Marks</h5>
                  <p className="text-sm font-medium">{exam.examPattern.totalMarks}</p>
                </Card>
                <Card className="p-3 bg-white/60 border border-purple-200">
                  <h5 className="font-semibold text-sm text-purple-700 mb-1">⚠️ Negative Marking</h5>
                  <p className="text-sm">{exam.examPattern.negativeMarking}</p>
                </Card>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h5 className="font-semibold text-sm text-purple-700 mb-2">📈 Subject Distribution</h5>
                  <div className="flex flex-wrap gap-2">
                    {exam.examPattern.subjects.map((subject, index) => (
                      <Badge key={index} variant="outline" className="bg-purple-50 border-purple-200 text-purple-800">
                        {subject}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h5 className="font-semibold text-sm text-purple-700 mb-2">🌍 Languages</h5>
                  <div className="flex flex-wrap gap-2">
                    {exam.examPattern.language.map((lang, index) => (
                      <Badge key={index} variant="outline" className="bg-blue-50 border-blue-200 text-blue-800">
                        {lang}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* Syllabus */}
          <AccordionItem value="syllabus" className="border-0">
            <AccordionTrigger className="text-left bg-gradient-to-r from-indigo-50 to-purple-50 px-4 py-3 rounded-lg hover:from-indigo-100 hover:to-purple-100 transition-colors border border-indigo-200">
              <div className="flex items-center gap-2">
                <BookOpenCheck className="h-5 w-5 text-indigo-600" />
                <span className="font-semibold text-indigo-800">📚 Detailed Syllabus</span>
                <Badge className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white ml-2">
                  Complete
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 py-4 bg-gradient-to-br from-indigo-50/50 to-purple-50/50 rounded-b-lg">
              <div className="space-y-6">
                {exam.syllabus.physics.length > 0 && (
                  <div>
                    <h5 className="font-bold text-indigo-800 mb-3 flex items-center gap-2">
                      <Zap className="h-4 w-4" />
                      ⚛️ Physics
                    </h5>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {exam.syllabus.physics.map((topic, index) => (
                        <div key={index} className="flex items-start gap-2 text-sm bg-white/60 rounded p-2">
                          <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                          <span>{topic}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {exam.syllabus.chemistry.length > 0 && (
                  <div>
                    <h5 className="font-bold text-indigo-800 mb-3 flex items-center gap-2">
                      <Activity className="h-4 w-4" />
                      🧪 Chemistry
                    </h5>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {exam.syllabus.chemistry.map((topic, index) => (
                        <div key={index} className="flex items-start gap-2 text-sm bg-white/60 rounded p-2">
                          <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                          <span>{topic}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <div>
                  <h5 className="font-bold text-indigo-800 mb-3 flex items-center gap-2">
                    <Heart className="h-4 w-4" />
                    🧬 Biology/Medical Subjects
                  </h5>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {exam.syllabus.biology.map((topic, index) => (
                      <div key={index} className="flex items-start gap-2 text-sm bg-white/60 rounded p-2">
                        <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span>{topic}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* Cut-off Trends */}
          <AccordionItem value="cutoff" className="border-0">
            <AccordionTrigger className="text-left bg-gradient-to-r from-green-50 to-emerald-50 px-4 py-3 rounded-lg hover:from-green-100 hover:to-emerald-100 transition-colors border border-green-200">
              <div className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-green-600" />
                <span className="font-semibold text-green-800">📈 Cut-off Trends & Analysis</span>
                <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white ml-2">
                  2021-2025
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 py-4 bg-gradient-to-br from-green-50/50 to-emerald-50/50 rounded-b-lg">
              <CutoffTrendsTable trends={exam.cutoffTrends} />
            </AccordionContent>
          </AccordionItem>

          {/* Top Colleges */}
          {exam.topColleges.length > 0 && (
            <AccordionItem value="colleges" className="border-0">
              <AccordionTrigger className="text-left bg-gradient-to-r from-blue-50 to-cyan-50 px-4 py-3 rounded-lg hover:from-blue-100 hover:to-cyan-100 transition-colors border border-blue-200">
                <div className="flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-blue-600" />
                  <span className="font-semibold text-blue-800">🏆 Top Medical Colleges</span>
                  <Badge className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white ml-2">
                    {exam.topColleges.length} Colleges
                  </Badge>
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-4 py-4 bg-gradient-to-br from-blue-50/50 to-cyan-50/50 rounded-b-lg">
                <CollegeListTable colleges={exam.topColleges} />
              </AccordionContent>
            </AccordionItem>
          )}

          {/* Preparation Strategy */}
          <AccordionItem value="preparation" className="border-0">
            <AccordionTrigger className="text-left bg-gradient-to-r from-yellow-50 to-orange-50 px-4 py-3 rounded-lg hover:from-yellow-100 hover:to-orange-100 transition-colors border border-yellow-200">
              <div className="flex items-center gap-2">
                <Target className="h-5 w-5 text-yellow-600" />
                <span className="font-semibold text-yellow-800">🎯 Preparation Strategy & Tips</span>
                <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white ml-2">
                  Expert Tips
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 py-4 bg-gradient-to-br from-yellow-50/50 to-orange-50/50 rounded-b-lg">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <h5 className="font-bold text-yellow-800 mb-4 flex items-center gap-2">
                    <Award className="h-5 w-5" />
                    💡 Expert Preparation Tips
                  </h5>
                  <div className="space-y-3">
                    {exam.preparationTips.map((tip, index) => (
                      <div key={index} className="flex items-start gap-3 bg-white/60 rounded-lg p-3">
                        <div className="w-6 h-6 bg-yellow-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-white font-bold text-xs">{index + 1}</span>
                        </div>
                        <span className="text-sm text-yellow-800">{tip}</span>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h5 className="font-bold text-yellow-800 mb-4 flex items-center gap-2">
                    <BookOpen className="h-5 w-5" />
                    📚 Recommended Books
                  </h5>
                  <div className="space-y-4">
                    {exam.importantBooks.map((subject, index) => (
                      <div key={index} className="bg-white/60 rounded-lg p-3">
                        <h6 className="font-semibold text-yellow-700 mb-2">{subject.subject}</h6>
                        <div className="space-y-1">
                          {subject.books.map((book, bookIndex) => (
                            <div key={bookIndex} className="text-sm">
                              <span className="font-medium">{book.name}</span>
                              <span className="text-gray-600"> - {book.author}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* Fees & Seats */}
          <AccordionItem value="fees-seats" className="border-0">
            <AccordionTrigger className="text-left bg-gradient-to-r from-teal-50 to-cyan-50 px-4 py-3 rounded-lg hover:from-teal-100 hover:to-cyan-100 transition-colors border border-teal-200">
              <div className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-teal-600" />
                <span className="font-semibold text-teal-800">💰 Fees & Seat Matrix</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 py-4 bg-gradient-to-br from-teal-50/50 to-cyan-50/50 rounded-b-lg">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="p-4 bg-white/80 border border-teal-200">
                  <h5 className="font-semibold text-teal-800 mb-3">💳 Fee Structure</h5>
                  <div className="space-y-2 text-sm">
                    <div><strong>Application Fee:</strong> {exam.fees.application}</div>
                    <div><strong>Counseling Fee:</strong> {exam.fees.counseling}</div>
                  </div>
                </Card>
                
                {exam.seats.total > 0 && (
                  <Card className="p-4 bg-white/80 border border-teal-200">
                    <h5 className="font-semibold text-teal-800 mb-3">🪑 Seat Distribution</h5>
                    <div className="space-y-2 text-sm">
                      <div><strong>Total Seats:</strong> {exam.seats.total.toLocaleString()}</div>
                      <div><strong>Government:</strong> {exam.seats.government.toLocaleString()}</div>
                      <div><strong>Private:</strong> {exam.seats.private.toLocaleString()}</div>
                      <div><strong>Deemed:</strong> {exam.seats.deemed.toLocaleString()}</div>
                    </div>
                  </Card>
                )}
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );

  return (
    <section id="medical-exams" className="py-20 bg-gradient-to-br from-red-50 via-pink-50 to-rose-100">
      <div className="container mx-auto px-4">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-red-500 to-pink-500 text-white px-6 py-3 rounded-full mb-6 shadow-lg">
            <Stethoscope className="h-5 w-5" />
            <span className="font-bold">Medical Entrance Examinations</span>
            <Heart className="h-5 w-5" />
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
            <span className="block bg-gradient-to-r from-red-600 via-pink-600 to-rose-600 bg-clip-text text-transparent">
              Your Gateway to
            </span>
            <span className="block text-gray-800 mt-2">Medical Education! 🩺</span>
          </h2>
          
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Comprehensive guide to medical entrance exams in India. Get detailed information about 
            <span className="text-transparent bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text font-semibold"> NEET</span>, 
            <span className="text-transparent bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text font-semibold"> AIIMS</span>, and 
            <span className="text-transparent bg-gradient-to-r from-rose-600 to-red-600 bg-clip-text font-semibold"> other medical exams</span>!
          </p>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-12 max-w-6xl mx-auto">
          <Card className="p-4 text-center bg-gradient-to-br from-red-100 to-pink-100 border border-red-200">
            <Users className="h-6 w-6 mx-auto mb-2 text-red-600" />
            <div className="text-xl font-bold text-red-700">{medicalExamStats.totalCandidates}</div>
            <div className="text-xs opacity-90">Total Candidates</div>
          </Card>
          <Card className="p-4 text-center bg-gradient-to-br from-pink-100 to-rose-100 border border-pink-200">
            <School className="h-6 w-6 mx-auto mb-2 text-pink-600" />
            <div className="text-xl font-bold text-pink-700">{medicalExamStats.totalSeats}</div>
            <div className="text-xs opacity-90">Total Seats</div>
          </Card>
          <Card className="p-4 text-center bg-gradient-to-br from-rose-100 to-red-100 border border-rose-200">
            <Target className="h-6 w-6 mx-auto mb-2 text-rose-600" />
            <div className="text-xl font-bold text-rose-700">{medicalExamStats.averageScore}</div>
            <div className="text-xs opacity-90">Average Score</div>
          </Card>
          <Card className="p-4 text-center bg-gradient-to-br from-orange-100 to-red-100 border border-orange-200">
            <UserCheck className="h-6 w-6 mx-auto mb-2 text-orange-600" />
            <div className="text-xl font-bold text-orange-700">{medicalExamStats.passPercentage}</div>
            <div className="text-xs opacity-90">Pass Rate</div>
          </Card>
          <Card className="p-4 text-center bg-gradient-to-br from-purple-100 to-pink-100 border border-purple-200">
            <Trophy className="h-6 w-6 mx-auto mb-2 text-purple-600" />
            <div className="text-xl font-bold text-purple-700">{medicalExamStats.competitionRatio}</div>
            <div className="text-xs opacity-90">Competition</div>
          </Card>
          <Card className="p-4 text-center bg-gradient-to-br from-blue-100 to-purple-100 border border-blue-200">
            <BarChart3 className="h-6 w-6 mx-auto mb-2 text-blue-600" />
            <div className="text-xl font-bold text-blue-700">{medicalExamStats.successRate}</div>
            <div className="text-xs opacity-90">Success Rate</div>
          </Card>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto">
          <Tabs value={selectedExam.toString()} onValueChange={(value) => setSelectedExam(parseInt(value))}>
            <TabsList className="grid w-full grid-cols-3 mb-8 bg-white/80 backdrop-blur-sm border-2 border-red-200 shadow-xl">
              {medicalExamsData.map((exam, index) => (
                <TabsTrigger 
                  key={index} 
                  value={index.toString()} 
                  className={`text-sm font-semibold data-[state=active]:bg-gradient-to-r data-[state=active]:from-red-500 data-[state=active]:to-pink-500 data-[state=active]:text-white transition-all duration-300 py-3 ${
                    highlightedTab === index ? 'animate-pulse bg-gradient-to-r from-yellow-400 to-orange-400 text-white shadow-lg' : ''
                  }`}
                >
                  <Stethoscope className="h-4 w-4 mr-2" />
                  {exam.name}
                </TabsTrigger>
              ))}
            </TabsList>

            {medicalExamsData.map((exam, index) => (
              <TabsContent key={index} value={index.toString()}>
                <ExamCard exam={exam} index={index} />
              </TabsContent>
            ))}
          </Tabs>
        </div>

        {/* Call to Action */}
        <div className="max-w-4xl mx-auto mt-16">
          <Card className="bg-gradient-to-r from-red-500 via-pink-500 to-rose-500 text-white border-0 shadow-2xl">
            <CardContent className="pt-8 pb-8 text-center">
              <Heart className="h-12 w-12 mx-auto mb-4" />
              <h3 className="text-2xl font-bold mb-4">Ready to Start Your Medical Journey?</h3>
              <p className="text-white/90 mb-6 text-lg">
                Join thousands of students who have achieved their dream of becoming doctors. Get personalized guidance and preparation strategies.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg" 
                  className="bg-white text-red-600 hover:bg-gray-100 px-8 py-4 text-lg font-bold shadow-xl"
                  onClick={() => {
                    const element = document.getElementById('career-quiz');
                    if (element) {
                      element.scrollIntoView({ 
                        behavior: 'smooth',
                        block: 'start'
                      });
                    }
                  }}
                >
                  🎯 Take Career Assessment
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-white text-white hover:bg-white hover:text-red-600 px-8 py-4 text-lg font-bold"
                  onClick={() => {
                    const element = document.getElementById('resources');
                    if (element) {
                      element.scrollIntoView({ 
                        behavior: 'smooth',
                        block: 'start'
                      });
                    }
                  }}
                >
                  📚 Study Resources
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}