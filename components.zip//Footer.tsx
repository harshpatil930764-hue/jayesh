import { GraduationCap, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';
import { Button } from './ui/button';

export function Footer() {
  const footerLinks = {
    'Quick Links': [
      { name: 'Career Streams', href: '#streams' },
      { name: 'Government Exams', href: '#exams' },
      { name: 'Career Quiz', href: '#quiz' },
      { name: 'Resources', href: '#resources' }
    ],
    'Support': [
      { name: 'Contact Us', href: '#contact' },
      { name: 'FAQ', href: '#' },
      { name: 'Career Counseling', href: '#' },
      { name: 'Help Center', href: '#' }
    ],
    'Resources': [
      { name: 'Study Materials', href: '#resources' },
      { name: 'Video Guides', href: '#resources' },
      { name: 'Career Articles', href: '#' },
      { name: 'Success Stories', href: '#' }
    ]
  };

  return (
    <footer className="bg-card border-t">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <GraduationCap className="h-6 w-6 text-primary" />
              <span className="text-lg font-semibold">CareerPath</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Empowering rural students with career guidance and helping them make informed decisions about their future.
            </p>
            <div className="flex space-x-2">
              <Button variant="outline" size="icon">
                <Facebook className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Twitter className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Instagram className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Linkedin className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Footer Links */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category} className="space-y-4">
              <h4 className="font-semibold">{category}</h4>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link.name}>
                    <a 
                      href={link.href} 
                      className="text-sm text-muted-foreground hover:text-primary transition-colors"
                    >
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-muted-foreground">
            © 2024 CareerPath. All rights reserved. Made with ❤️ for rural students.
          </p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <a href="#" className="text-sm text-muted-foreground hover:text-primary">Privacy Policy</a>
            <a href="#" className="text-sm text-muted-foreground hover:text-primary">Terms of Service</a>
            <a href="#" className="text-sm text-muted-foreground hover:text-primary">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}