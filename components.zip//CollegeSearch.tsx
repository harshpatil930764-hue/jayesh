import { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { CollegeProfile } from './CollegeProfile';
import { 
  Search, 
  MapPin, 
  GraduationCap, 
  Star, 
  ArrowRight, 
  Building, 
  Users, 
  Award,
  Filter,
  X,
  BookOpen,
  Zap,
  Target,
  TrendingUp,
  School,
  Heart,
  Brain,
  Briefcase,
  Code,
  Calculator,
  PenTool,
  Lightbulb,
  Globe
} from 'lucide-react';

interface College {
  id: string;
  name: string;
  location: string;
  state: string;
  type: 'Government' | 'Private' | 'Deemed' | 'Central';
  courses: string[];
  ranking: number;
  rating: number;
  fees: string;
  placements: string;
  website: string;
  established: number;
  affiliation: string;
  specialization: string[];
  admissionProcess: string;
  totalSeats: number;
}

interface Course {
  id: string;
  name: string;
  fullName: string;
  category: string;
  duration: string;
  icon: React.ComponentType<any>;
  popular: boolean;
}

const popularCourses: Course[] = [
  { id: 'btech', name: 'B.Tech', fullName: 'Bachelor of Technology', category: 'Engineering', duration: '4 years', icon: Code, popular: true },
  { id: 'mbbs', name: 'MBBS', fullName: 'Bachelor of Medicine and Bachelor of Surgery', category: 'Medical', duration: '5.5 years', icon: Heart, popular: true },
  { id: 'bba', name: 'BBA', fullName: 'Bachelor of Business Administration', category: 'Management', duration: '3 years', icon: Briefcase, popular: true },
  { id: 'bcom', name: 'B.Com', fullName: 'Bachelor of Commerce', category: 'Commerce', duration: '3 years', icon: Calculator, popular: true },
  { id: 'ba', name: 'BA', fullName: 'Bachelor of Arts', category: 'Arts', duration: '3 years', icon: PenTool, popular: true },
  { id: 'bsc', name: 'B.Sc', fullName: 'Bachelor of Science', category: 'Science', duration: '3 years', icon: Brain, popular: true },
  { id: 'llb', name: 'LLB', fullName: 'Bachelor of Laws', category: 'Law', duration: '3-5 years', icon: Award, popular: false },
  { id: 'bds', name: 'BDS', fullName: 'Bachelor of Dental Surgery', category: 'Medical', duration: '5 years', icon: Heart, popular: false },
  { id: 'barch', name: 'B.Arch', fullName: 'Bachelor of Architecture', category: 'Design', duration: '5 years', icon: Building, popular: false },
  { id: 'bjmc', name: 'BJMC', fullName: 'Bachelor of Journalism and Mass Communication', category: 'Media', duration: '3 years', icon: Globe, popular: false },
];

const allColleges: College[] = [
  // National Institutes
  {
    id: '1',
    name: 'Indian Institute of Technology Delhi',
    location: 'New Delhi',
    state: 'Delhi',
    type: 'Central',
    courses: ['B.Tech', 'M.Tech', 'Ph.D', 'MBA'],
    ranking: 1,
    rating: 4.8,
    fees: '₹2,50,000/year',
    placements: '₹20,00,000 avg',
    website: 'iitd.ac.in',
    established: 1961,
    affiliation: 'Autonomous',
    specialization: ['Computer Science', 'Electrical', 'Mechanical', 'Civil'],
    admissionProcess: 'JEE Advanced',
    totalSeats: 1000
  },
  {
    id: '2',
    name: 'All India Institute of Medical Sciences',
    location: 'New Delhi',
    state: 'Delhi',
    type: 'Central',
    courses: ['MBBS', 'MD', 'MS', 'B.Sc Nursing'],
    ranking: 1,
    rating: 4.9,
    fees: '₹5,856/year',
    placements: 'Direct PG/Jobs',
    website: 'aiims.edu',
    established: 1956,
    affiliation: 'Autonomous',
    specialization: ['General Medicine', 'Surgery', 'Pediatrics', 'Cardiology'],
    admissionProcess: 'NEET',
    totalSeats: 125
  },
  {
    id: '3',
    name: 'University of Delhi',
    location: 'New Delhi',
    state: 'Delhi',
    type: 'Central',
    courses: ['BA', 'B.Sc', 'B.Com', 'MA', 'M.Sc', 'M.Com'],
    ranking: 3,
    rating: 4.5,
    fees: '₹15,000/year',
    placements: '₹6,00,000 avg',
    website: 'du.ac.in',
    established: 1922,
    affiliation: 'UGC',
    specialization: ['Arts', 'Science', 'Commerce', 'Social Sciences'],
    admissionProcess: 'CUET',
    totalSeats: 65000
  },
  
  // Maharashtra B.Tech Colleges - Government/Autonomous
  {
    id: 'mh1',
    name: 'Indian Institute of Technology Bombay',
    location: 'Mumbai',
    state: 'Maharashtra',
    type: 'Central',
    courses: ['B.Tech', 'M.Tech', 'Ph.D', 'MBA'],
    ranking: 3,
    rating: 4.8,
    fees: '₹2,50,000/year',
    placements: '₹21,00,000 avg',
    website: 'iitb.ac.in',
    established: 1958,
    affiliation: 'Autonomous',
    specialization: ['Computer Science', 'Electrical', 'Mechanical', 'Chemical', 'Civil', 'Aerospace'],
    admissionProcess: 'JEE Advanced',
    totalSeats: 1100
  },
  {
    id: 'mh2',
    name: 'Visvesvaraya National Institute of Technology',
    location: 'Nagpur',
    state: 'Maharashtra',
    type: 'Central',
    courses: ['B.Tech', 'M.Tech', 'Ph.D'],
    ranking: 11,
    rating: 4.6,
    fees: '₹1,50,000/year',
    placements: '₹12,00,000 avg',
    website: 'vnit.ac.in',
    established: 1960,
    affiliation: 'NIT',
    specialization: ['Computer Science', 'Electronics', 'Mechanical', 'Civil', 'Chemical', 'Mining'],
    admissionProcess: 'JEE Main',
    totalSeats: 1200
  },
  {
    id: 'mh3',
    name: 'Institute of Chemical Technology',
    location: 'Mumbai',
    state: 'Maharashtra',
    type: 'Deemed',
    courses: ['B.Tech', 'M.Tech', 'Ph.D'],
    ranking: 15,
    rating: 4.5,
    fees: '₹1,80,000/year',
    placements: '₹15,00,000 avg',
    website: 'ictmumbai.edu.in',
    established: 1933,
    affiliation: 'Deemed University',
    specialization: ['Chemical Engineering', 'Biotechnology', 'Food Technology', 'Pharmaceutical'],
    admissionProcess: 'JEE Main + GATE',
    totalSeats: 400
  },
  {
    id: 'mh4',
    name: 'College of Engineering Pune (COEP)',
    location: 'Pune',
    state: 'Maharashtra',
    type: 'Government',
    courses: ['B.Tech', 'M.Tech', 'Ph.D'],
    ranking: 25,
    rating: 4.4,
    fees: '₹1,20,000/year',
    placements: '₹8,50,000 avg',
    website: 'coep.org.in',
    established: 1854,
    affiliation: 'SPPU',
    specialization: ['Computer', 'IT', 'Mechanical', 'Civil', 'Electrical', 'Electronics'],
    admissionProcess: 'MHT-CET',
    totalSeats: 960
  },
  {
    id: 'mh5',
    name: 'Sardar Patel Institute of Technology',
    location: 'Mumbai',
    state: 'Maharashtra',
    type: 'Government',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 35,
    rating: 4.3,
    fees: '₹1,15,000/year',
    placements: '₹7,50,000 avg',
    website: 'spit.ac.in',
    established: 1962,
    affiliation: 'Mumbai University',
    specialization: ['Computer', 'IT', 'Electronics', 'Electrical', 'Mechanical'],
    admissionProcess: 'MHT-CET',
    totalSeats: 720
  },
  {
    id: 'mh6',
    name: 'Veermata Jijabai Technological Institute',
    location: 'Mumbai',
    state: 'Maharashtra',
    type: 'Government',
    courses: ['B.Tech', 'M.Tech', 'Ph.D'],
    ranking: 40,
    rating: 4.2,
    fees: '₹1,25,000/year',
    placements: '₹7,00,000 avg',
    website: 'vjti.ac.in',
    established: 1887,
    affiliation: 'Mumbai University',
    specialization: ['Computer', 'IT', 'Electronics', 'Mechanical', 'Civil', 'Textile'],
    admissionProcess: 'MHT-CET',
    totalSeats: 840
  },
  {
    id: 'mh7',
    name: 'Government College of Engineering Aurangabad',
    location: 'Aurangabad',
    state: 'Maharashtra',
    type: 'Government',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 50,
    rating: 4.1,
    fees: '₹95,000/year',
    placements: '₹6,00,000 avg',
    website: 'geca.ac.in',
    established: 1960,
    affiliation: 'Dr. Babasaheb Ambedkar Technological University',
    specialization: ['Computer Science', 'IT', 'Electronics', 'Mechanical', 'Civil', 'Chemical'],
    admissionProcess: 'MHT-CET',
    totalSeats: 600
  },
  {
    id: 'mh8',
    name: 'Walchand College of Engineering Sangli',
    location: 'Sangli',
    state: 'Maharashtra',
    type: 'Government',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 55,
    rating: 4.0,
    fees: '₹1,10,000/year',
    placements: '₹5,50,000 avg',
    website: 'walchandsangli.ac.in',
    established: 1947,
    affiliation: 'Shivaji University',
    specialization: ['Computer', 'IT', 'Electronics', 'Mechanical', 'Civil', 'Electrical'],
    admissionProcess: 'MHT-CET',
    totalSeats: 480
  },
  {
    id: 'mh9',
    name: 'Government College of Engineering Nagpur',
    location: 'Nagpur',
    state: 'Maharashtra',
    type: 'Government',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 60,
    rating: 4.0,
    fees: '₹90,000/year',
    placements: '₹5,20,000 avg',
    website: 'rknec.edu',
    established: 1951,
    affiliation: 'RTM Nagpur University',
    specialization: ['Computer Science', 'IT', 'Electronics', 'Mechanical', 'Civil'],
    admissionProcess: 'MHT-CET',
    totalSeats: 540
  },
  {
    id: 'mh10',
    name: 'Government College of Engineering Amravati',
    location: 'Amravati',
    state: 'Maharashtra',
    type: 'Government',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 65,
    rating: 3.9,
    fees: '₹85,000/year',
    placements: '₹4,80,000 avg',
    website: 'gcoea.ac.in',
    established: 1965,
    affiliation: 'Sant Gadge Baba Amravati University',
    specialization: ['Computer Science', 'IT', 'Electronics', 'Mechanical', 'Civil'],
    admissionProcess: 'MHT-CET',
    totalSeats: 420
  },
  
  // Maharashtra B.Tech Colleges - Private/Autonomous
  {
    id: 'mh11',
    name: 'Pune Institute of Computer Technology',
    location: 'Pune',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 45,
    rating: 4.2,
    fees: '₹1,50,000/year',
    placements: '₹8,00,000 avg',
    website: 'pict.edu',
    established: 1983,
    affiliation: 'SPPU',
    specialization: ['Computer', 'IT', 'Electronics & Telecom', 'E&TC'],
    admissionProcess: 'MHT-CET',
    totalSeats: 480
  },
  {
    id: 'mh12',
    name: 'Vishwakarma Institute of Technology',
    location: 'Pune',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech', 'MBA'],
    ranking: 48,
    rating: 4.1,
    fees: '₹1,45,000/year',
    placements: '₹7,20,000 avg',
    website: 'vit.edu',
    established: 1983,
    affiliation: 'SPPU',
    specialization: ['Computer', 'IT', 'Electronics', 'Mechanical', 'Civil', 'Chemical'],
    admissionProcess: 'MHT-CET',
    totalSeats: 720
  },
  {
    id: 'mh13',
    name: 'Maharashtra Institute of Technology',
    location: 'Pune',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 52,
    rating: 4.0,
    fees: '₹1,35,000/year',
    placements: '₹6,80,000 avg',
    website: 'mitpune.edu.in',
    established: 1983,
    affiliation: 'SPPU',
    specialization: ['Computer', 'IT', 'Electronics', 'Mechanical', 'Civil'],
    admissionProcess: 'MHT-CET',
    totalSeats: 600
  },
  {
    id: 'mh14',
    name: 'Symbiosis Institute of Technology',
    location: 'Pune',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 58,
    rating: 4.0,
    fees: '₹2,50,000/year',
    placements: '₹7,50,000 avg',
    website: 'sitpune.edu.in',
    established: 2008,
    affiliation: 'Symbiosis International University',
    specialization: ['Computer Science', 'Electronics', 'Mechanical', 'Civil'],
    admissionProcess: 'SET + JEE Main',
    totalSeats: 360
  },
  {
    id: 'mh15',
    name: 'Bharati Vidyapeeth College of Engineering',
    location: 'Pune',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 62,
    rating: 3.9,
    fees: '₹1,25,000/year',
    placements: '₹5,80,000 avg',
    website: 'bvcoepune.edu.in',
    established: 1983,
    affiliation: 'Bharati Vidyapeeth University',
    specialization: ['Computer', 'IT', 'Electronics', 'Mechanical', 'Civil', 'Electrical'],
    admissionProcess: 'MHT-CET',
    totalSeats: 540
  },
  {
    id: 'mh16',
    name: 'Fr. Conceicao Rodrigues College of Engineering',
    location: 'Mumbai',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 68,
    rating: 3.8,
    fees: '₹1,40,000/year',
    placements: '₹6,20,000 avg',
    website: 'fragnel.edu.in',
    established: 1984,
    affiliation: 'Mumbai University',
    specialization: ['Computer', 'IT', 'Electronics', 'Mechanical'],
    admissionProcess: 'MHT-CET',
    totalSeats: 360
  },
  {
    id: 'mh17',
    name: 'Thadomal Shahani Engineering College',
    location: 'Mumbai',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 72,
    rating: 3.8,
    fees: '₹1,35,000/year',
    placements: '₹5,90,000 avg',
    website: 'tsec.edu',
    established: 1983,
    affiliation: 'Mumbai University',
    specialization: ['Computer', 'IT', 'Electronics', 'Mechanical'],
    admissionProcess: 'MHT-CET',
    totalSeats: 480
  },
  {
    id: 'mh18',
    name: 'D.J. Sanghvi College of Engineering',
    location: 'Mumbai',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 75,
    rating: 3.7,
    fees: '₹1,50,000/year',
    placements: '₹6,50,000 avg',
    website: 'djsce.ac.in',
    established: 1994,
    affiliation: 'Mumbai University',
    specialization: ['Computer', 'IT', 'Electronics', 'Mechanical'],
    admissionProcess: 'MHT-CET',
    totalSeats: 480
  },
  {
    id: 'mh19',
    name: 'K.J. Somaiya College of Engineering',
    location: 'Mumbai',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 78,
    rating: 3.7,
    fees: '₹1,45,000/year',
    placements: '₹6,10,000 avg',
    website: 'somaiya.edu',
    established: 1983,
    affiliation: 'Mumbai University',
    specialization: ['Computer', 'IT', 'Electronics', 'Mechanical'],
    admissionProcess: 'MHT-CET',
    totalSeats: 540
  },
  {
    id: 'mh20',
    name: 'Atharva College of Engineering',
    location: 'Mumbai',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 85,
    rating: 3.6,
    fees: '₹1,30,000/year',
    placements: '₹5,50,000 avg',
    website: 'atharvacoe.ac.in',
    established: 1999,
    affiliation: 'Mumbai University',
    specialization: ['Computer', 'IT', 'Electronics', 'Mechanical'],
    admissionProcess: 'MHT-CET',
    totalSeats: 360
  },
  {
    id: 'mh21',
    name: 'Sinhgad College of Engineering',
    location: 'Pune',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 88,
    rating: 3.6,
    fees: '₹1,25,000/year',
    placements: '₹5,30,000 avg',
    website: 'scoe.org',
    established: 1996,
    affiliation: 'SPPU',
    specialization: ['Computer', 'IT', 'Electronics', 'Mechanical', 'Civil'],
    admissionProcess: 'MHT-CET',
    totalSeats: 600
  },
  {
    id: 'mh22',
    name: 'AISSMS College of Engineering',
    location: 'Pune',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 92,
    rating: 3.5,
    fees: '₹1,20,000/year',
    placements: '₹5,00,000 avg',
    website: 'aissmscoe.com',
    established: 1992,
    affiliation: 'SPPU',
    specialization: ['Computer', 'IT', 'Electronics', 'Mechanical', 'Civil'],
    admissionProcess: 'MHT-CET',
    totalSeats: 540
  },
  {
    id: 'mh23',
    name: 'Modern Education Society College of Engineering',
    location: 'Pune',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 95,
    rating: 3.5,
    fees: '₹1,15,000/year',
    placements: '₹4,80,000 avg',
    website: 'mescoepune.org',
    established: 2001,
    affiliation: 'SPPU',
    specialization: ['Computer', 'IT', 'Electronics', 'Mechanical'],
    admissionProcess: 'MHT-CET',
    totalSeats: 420
  },
  {
    id: 'mh24',
    name: 'Yeshwantrao Chavan College of Engineering',
    location: 'Nagpur',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 98,
    rating: 3.4,
    fees: '₹1,10,000/year',
    placements: '₹4,50,000 avg',
    website: 'ycce.edu',
    established: 1984,
    affiliation: 'RTM Nagpur University',
    specialization: ['Computer Science', 'IT', 'Electronics', 'Mechanical', 'Civil'],
    admissionProcess: 'MHT-CET',
    totalSeats: 480
  },
  {
    id: 'mh25',
    name: 'G.H. Raisoni College of Engineering',
    location: 'Nagpur',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 102,
    rating: 3.4,
    fees: '₹1,08,000/year',
    placements: '₹4,20,000 avg',
    website: 'ghrce.raisoni.net',
    established: 1996,
    affiliation: 'RTM Nagpur University',
    specialization: ['Computer Science', 'IT', 'Electronics', 'Mechanical', 'Civil'],
    admissionProcess: 'MHT-CET',
    totalSeats: 540
  },
  {
    id: 'mh26',
    name: 'Shri Guru Gobind Singhji Institute of Engineering',
    location: 'Nanded',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 105,
    rating: 3.3,
    fees: '₹95,000/year',
    placements: '₹4,00,000 avg',
    website: 'sggs.ac.in',
    established: 1983,
    affiliation: 'SRTM University',
    specialization: ['Computer Science', 'IT', 'Electronics', 'Mechanical', 'Civil'],
    admissionProcess: 'MHT-CET',
    totalSeats: 420
  },
  {
    id: 'mh27',
    name: 'Pillai College of Engineering',
    location: 'Mumbai',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 108,
    rating: 3.3,
    fees: '₹1,25,000/year',
    placements: '₹4,80,000 avg',
    website: 'pce.ac.in',
    established: 1999,
    affiliation: 'Mumbai University',
    specialization: ['Computer', 'IT', 'Electronics', 'Mechanical'],
    admissionProcess: 'MHT-CET',
    totalSeats: 360
  },
  {
    id: 'mh28',
    name: 'Rajarshi Shahu College of Engineering',
    location: 'Pune',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 112,
    rating: 3.2,
    fees: '₹1,12,000/year',
    placements: '₹4,30,000 avg',
    website: 'rscoe.co.in',
    established: 1992,
    affiliation: 'SPPU',
    specialization: ['Computer', 'IT', 'Electronics', 'Mechanical'],
    admissionProcess: 'MHT-CET',
    totalSeats: 420
  },
  {
    id: 'mh29',
    name: 'Sandip Institute of Technology & Research Centre',
    location: 'Nashik',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 115,
    rating: 3.2,
    fees: '₹1,05,000/year',
    placements: '₹4,10,000 avg',
    website: 'sitrc.org',
    established: 2008,
    affiliation: 'Sandip University',
    specialization: ['Computer Science', 'IT', 'Electronics', 'Mechanical'],
    admissionProcess: 'MHT-CET',
    totalSeats: 480
  },
  {
    id: 'mh30',
    name: 'Zeal College of Engineering & Research',
    location: 'Pune',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech'],
    ranking: 118,
    rating: 3.1,
    fees: '₹1,08,000/year',
    placements: '₹3,90,000 avg',
    website: 'zealcoe.org.in',
    established: 2004,
    affiliation: 'SPPU',
    specialization: ['Computer', 'IT', 'Electronics', 'Mechanical'],
    admissionProcess: 'MHT-CET',
    totalSeats: 360
  },
  {
    id: 'mh31',
    name: 'K.B.T College of Engineering',
    location: 'Nashik',
    state: 'Maharashtra',
    type: 'Private',
    courses: ['B.Tech', 'M.Tech', 'MBA'],
    ranking: 95,
    rating: 3.5,
    fees: '₹1,15,000/year',
    placements: '₹4,50,000 avg',
    website: 'kbtcoe.org',
    established: 2001,
    affiliation: 'Savitribai Phule Pune University',
    specialization: ['Computer Science', 'Information Technology', 'Electronics & Telecom', 'Mechanical', 'Civil', 'Electrical'],
    admissionProcess: 'MHT-CET',
    totalSeats: 540
  }
];

const states = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Delhi', 
  'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 
  'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 
  'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 
  'Uttar Pradesh', 'Uttarakhand', 'West Bengal'
];

export function CollegeSearch() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCourse, setSelectedCourse] = useState('');
  const [selectedState, setSelectedState] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [searchResults, setSearchResults] = useState<College[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedCollege, setSelectedCollege] = useState<College | null>(null);
  const searchRef = useRef<HTMLDivElement>(null);

  const searchColleges = () => {
    setIsSearching(true);
    
    // Simulate API call delay
    setTimeout(() => {
      let results = allColleges;
      
      if (searchQuery) {
        results = results.filter(college => 
          college.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          college.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
          college.courses.some(course => course.toLowerCase().includes(searchQuery.toLowerCase()))
        );
      }
      
      if (selectedCourse) {
        results = results.filter(college => 
          college.courses.some(course => course.toLowerCase().includes(selectedCourse.toLowerCase()))
        );
      }
      
      if (selectedState) {
        results = results.filter(college => college.state === selectedState);
      }
      
      if (selectedType) {
        results = results.filter(college => college.type === selectedType);
      }
      
      setSearchResults(results);
      setShowResults(true);
      setIsSearching(false);
    }, 800);
  };

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCourse('');
    setSelectedState('');
    setSelectedType('');
    setShowResults(false);
    setSearchResults([]);
  };

  // Close results when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowResults(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <>
      {selectedCollege && (
        <CollegeProfile 
          college={selectedCollege} 
          onClose={() => setSelectedCollege(null)} 
        />
      )}
      
      <section id="college-search" className="py-16 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 w-32 h-32 bg-gradient-to-r from-blue-400/20 to-purple-400/20 rounded-full blur-xl"></div>
        <div className="absolute bottom-10 right-10 w-40 h-40 bg-gradient-to-r from-pink-400/20 to-red-400/20 rounded-full blur-xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-60 h-60 bg-gradient-to-r from-green-400/10 to-blue-400/10 rounded-full blur-2xl"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white px-6 py-3 rounded-full mb-6 shadow-lg">
            <Search className="h-5 w-5" />
            <span className="font-bold">🎓 Find Your Perfect College</span>
            <Search className="h-5 w-5" />
          </div>
          
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 leading-tight">
            <span className="block bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              Discover Top Colleges
            </span>
            <span className="block text-gray-800 mt-2">
              Across India 🇮🇳
            </span>
          </h2>
          
          <p className="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Search from <span className="font-bold text-blue-600">10,000+ colleges</span> and 
            <span className="font-bold text-purple-600"> 500+ courses</span> with detailed information about 
            admissions, fees, placements, and rankings.
          </p>
        </div>

        {/* Popular Courses */}
        <div className="mb-8">
          <h3 className="text-xl font-bold text-gray-800 mb-4 text-center">🔥 Popular Courses</h3>
          <div className="flex flex-wrap justify-center gap-3">
            {popularCourses.filter(course => course.popular).map((course) => (
              <Button
                key={course.id}
                variant="outline"
                size="sm"
                className={`border-2 transition-all duration-300 hover:scale-105 ${
                  selectedCourse === course.name 
                    ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white border-transparent shadow-lg' 
                    : 'border-blue-200 text-blue-700 hover:bg-blue-50'
                }`}
                onClick={() => setSelectedCourse(selectedCourse === course.name ? '' : course.name)}
              >
                <course.icon className="h-4 w-4 mr-2" />
                {course.name}
                <span className="ml-2 text-xs opacity-75">({course.duration})</span>
              </Button>
            ))}
          </div>
        </div>

        {/* Main Search Interface */}
        <div ref={searchRef} className="relative max-w-6xl mx-auto">
          <Card className="bg-white/90 backdrop-blur-sm border-2 border-blue-200 shadow-2xl">
            <CardContent className="p-6">
              {/* Primary Search Bar */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mb-4">
                <div className="md:col-span-5">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <Input
                      placeholder="Search colleges, courses, or locations..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 pr-4 py-3 border-2 border-gray-200 focus:border-blue-500 rounded-lg text-base"
                    />
                  </div>
                </div>

                <div className="md:col-span-2">
                  <Select value={selectedCourse || 'all-courses'} onValueChange={(value) => setSelectedCourse(value === 'all-courses' ? '' : value)}>
                    <SelectTrigger className="border-2 border-gray-200 focus:border-blue-500 py-3">
                      <SelectValue placeholder="Course" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all-courses">All Courses</SelectItem>
                      {popularCourses.map((course) => (
                        <SelectItem key={course.id} value={course.name}>
                          <div className="flex items-center gap-2">
                            <course.icon className="h-4 w-4" />
                            {course.name}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="md:col-span-2">
                  <Select value={selectedState || 'all-states'} onValueChange={(value) => setSelectedState(value === 'all-states' ? '' : value)}>
                    <SelectTrigger className="border-2 border-gray-200 focus:border-blue-500 py-3">
                      <SelectValue placeholder="State" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all-states">All States</SelectItem>
                      {states.map((state) => (
                        <SelectItem key={state} value={state}>
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4" />
                            {state}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="md:col-span-2">
                  <Button
                    onClick={searchColleges}
                    disabled={isSearching}
                    className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white py-3 font-bold shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                  >
                    {isSearching ? (
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        Searching...
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <Search className="h-4 w-4" />
                        Search
                      </div>
                    )}
                  </Button>
                </div>

                <div className="md:col-span-1">
                  <Button
                    variant="outline"
                    onClick={() => setShowFilters(!showFilters)}
                    className="w-full border-2 border-gray-200 hover:bg-gray-50 py-3"
                  >
                    <Filter className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Advanced Filters */}
              {showFilters && (
                <div className="border-t border-gray-200 pt-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Select value={selectedType || 'all-types'} onValueChange={(value) => setSelectedType(value === 'all-types' ? '' : value)}>
                      <SelectTrigger className="border-2 border-gray-200 focus:border-blue-500">
                        <SelectValue placeholder="College Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all-types">All Types</SelectItem>
                        <SelectItem value="Government">Government</SelectItem>
                        <SelectItem value="Private">Private</SelectItem>
                        <SelectItem value="Deemed">Deemed University</SelectItem>
                        <SelectItem value="Central">Central University</SelectItem>
                      </SelectContent>
                    </Select>

                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        onClick={clearFilters}
                        className="flex-1 border-2 border-red-200 text-red-600 hover:bg-red-50"
                      >
                        <X className="h-4 w-4 mr-2" />
                        Clear All
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {/* Active Filters */}
              {(selectedCourse || selectedState || selectedType) && (
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <div className="flex flex-wrap gap-2">
                    <span className="text-sm text-gray-600 font-medium">Active filters:</span>
                    {selectedCourse && (
                      <Badge 
                        className="bg-blue-100 text-blue-800 hover:bg-blue-200 cursor-pointer"
                        onClick={() => setSelectedCourse('')}
                      >
                        {selectedCourse} <X className="h-3 w-3 ml-1" />
                      </Badge>
                    )}
                    {selectedState && (
                      <Badge 
                        className="bg-green-100 text-green-800 hover:bg-green-200 cursor-pointer"
                        onClick={() => setSelectedState('')}
                      >
                        {selectedState} <X className="h-3 w-3 ml-1" />
                      </Badge>
                    )}
                    {selectedType && (
                      <Badge 
                        className="bg-purple-100 text-purple-800 hover:bg-purple-200 cursor-pointer"
                        onClick={() => setSelectedType('')}
                      >
                        {selectedType} <X className="h-3 w-3 ml-1" />
                      </Badge>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Search Results */}
          {showResults && (
            <Card className="mt-4 bg-white/95 backdrop-blur-sm border-2 border-blue-200 shadow-2xl max-h-96 overflow-y-auto">
              <CardContent className="p-0">
                {searchResults.length > 0 ? (
                  <>
                    <div className="p-4 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-purple-50">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-gray-800">
                          Found {searchResults.length} colleges
                        </span>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => setShowResults(false)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="divide-y divide-gray-200">
                      {searchResults.map((college) => (
                        <div 
                          key={college.id} 
                          className="p-4 hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50 transition-all duration-200 cursor-pointer group"
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-start gap-3">
                                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg flex items-center justify-center flex-shrink-0">
                                  <Building className="h-6 w-6 text-white" />
                                </div>
                                
                                <div className="flex-1 min-w-0">
                                  <h3 className="font-bold text-gray-900 group-hover:text-blue-600 transition-colors">
                                    {college.name}
                                  </h3>
                                  
                                  <div className="flex items-center gap-4 mt-1 text-sm text-gray-600">
                                    <div className="flex items-center gap-1">
                                      <MapPin className="h-3 w-3" />
                                      {college.location}, {college.state}
                                    </div>
                                    <div className="flex items-center gap-1">
                                      <Star className="h-3 w-3 text-yellow-500 fill-current" />
                                      {college.rating}
                                    </div>
                                    <Badge 
                                      variant="outline" 
                                      className={`text-xs ${
                                        college.type === 'Government' ? 'bg-green-50 text-green-700 border-green-200' :
                                        college.type === 'Central' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                                        college.type === 'Private' ? 'bg-purple-50 text-purple-700 border-purple-200' :
                                        'bg-orange-50 text-orange-700 border-orange-200'
                                      }`}
                                    >
                                      {college.type}
                                    </Badge>
                                  </div>
                                  
                                  <div className="flex flex-wrap gap-2 mt-2">
                                    {college.courses.slice(0, 3).map((course, index) => (
                                      <Badge key={index} className="bg-gray-100 text-gray-700 text-xs">
                                        {course}
                                      </Badge>
                                    ))}
                                    {college.courses.length > 3 && (
                                      <Badge className="bg-gray-100 text-gray-700 text-xs">
                                        +{college.courses.length - 3} more
                                      </Badge>
                                    )}
                                  </div>
                                  
                                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-3 text-xs">
                                    <div>
                                      <span className="text-gray-500">Fees:</span>
                                      <span className="font-medium text-green-600 ml-1">{college.fees}</span>
                                    </div>
                                    <div>
                                      <span className="text-gray-500">Placements:</span>
                                      <span className="font-medium text-blue-600 ml-1">{college.placements}</span>
                                    </div>
                                    <div>
                                      <span className="text-gray-500">Ranking:</span>
                                      <span className="font-medium text-purple-600 ml-1">#{college.ranking}</span>
                                    </div>
                                    <div>
                                      <span className="text-gray-500">Seats:</span>
                                      <span className="font-medium text-orange-600 ml-1">{college.totalSeats}</span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            
                            <Button 
                              size="sm" 
                              className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white opacity-0 group-hover:opacity-100 transition-all duration-200 ml-4"
                              onClick={() => setSelectedCollege(college)}
                            >
                              View Details
                              <ArrowRight className="h-3 w-3 ml-1" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <div className="p-8 text-center">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Search className="h-8 w-8 text-gray-400" />
                    </div>
                    <h3 className="font-bold text-gray-800 mb-2">No colleges found</h3>
                    <p className="text-gray-600 text-sm">
                      Try adjusting your search criteria or clearing some filters.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12 max-w-4xl mx-auto">
          <Card className="text-center p-4 bg-white/80 backdrop-blur-sm border border-blue-200 hover:shadow-lg transition-all duration-300">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg flex items-center justify-center mx-auto mb-2">
              <School className="h-5 w-5 text-white" />
            </div>
            <div className="font-bold text-gray-800">10,000+</div>
            <div className="text-xs text-gray-600">Colleges</div>
          </Card>
          
          <Card className="text-center p-4 bg-white/80 backdrop-blur-sm border border-green-200 hover:shadow-lg transition-all duration-300">
            <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-500 rounded-lg flex items-center justify-center mx-auto mb-2">
              <BookOpen className="h-5 w-5 text-white" />
            </div>
            <div className="font-bold text-gray-800">500+</div>
            <div className="text-xs text-gray-600">Courses</div>
          </Card>
          
          <Card className="text-center p-4 bg-white/80 backdrop-blur-sm border border-purple-200 hover:shadow-lg transition-all duration-300">
            <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center mx-auto mb-2">
              <Users className="h-5 w-5 text-white" />
            </div>
            <div className="font-bold text-gray-800">50L+</div>
            <div className="text-xs text-gray-600">Students</div>
          </Card>
          
          <Card className="text-center p-4 bg-white/80 backdrop-blur-sm border border-orange-200 hover:shadow-lg transition-all duration-300">
            <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg flex items-center justify-center mx-auto mb-2">
              <TrendingUp className="h-5 w-5 text-white" />
            </div>
            <div className="font-bold text-gray-800">95%</div>
            <div className="text-xs text-gray-600">Success Rate</div>
          </Card>
        </div>
      </div>
      </section>
    </>
  );
}