import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Progress } from './ui/progress';
import { quizQuestions } from '../data/quizData';
import { QuizResult } from './QuizResult';

export function CareerQuiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [showResult, setShowResult] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState('');

  const handleNext = () => {
    if (selectedAnswer) {
      const newAnswers = [...answers, selectedAnswer];
      setAnswers(newAnswers);
      
      if (currentQuestion < quizQuestions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer('');
      } else {
        setShowResult(true);
      }
    }
  };

  const calculateResult = () => {
    const counts = answers.reduce((acc, answer) => {
      acc[answer] = (acc[answer] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    return Object.entries(counts).reduce((a, b) => counts[a[0]] > counts[b[0]] ? a : b)[0];
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setAnswers([]);
    setShowResult(false);
    setSelectedAnswer('');
  };

  if (showResult) {
    const result = calculateResult();
    return (
      <section id="quiz" className="py-20 px-4 bg-muted/30">
        <div className="container mx-auto max-w-2xl">
          <QuizResult result={result} onReset={resetQuiz} />
        </div>
      </section>
    );
  }

  return (
    <section id="quiz" className="py-20 px-4 bg-muted/30">
      <div className="container mx-auto max-w-2xl">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-4">Career Assessment Quiz</h2>
          <p className="text-lg text-muted-foreground">
            Answer a few questions to get personalized career stream recommendations
          </p>
        </div>
        
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center mb-4">
              <span className="text-sm text-muted-foreground">
                Question {currentQuestion + 1} of {quizQuestions.length}
              </span>
              <span className="text-sm font-medium">
                {Math.round(((currentQuestion + 1) / quizQuestions.length) * 100)}%
              </span>
            </div>
            <Progress value={((currentQuestion + 1) / quizQuestions.length) * 100} className="mb-4" />
            <CardTitle className="text-lg">{quizQuestions[currentQuestion].question}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <RadioGroup value={selectedAnswer} onValueChange={setSelectedAnswer}>
              {quizQuestions[currentQuestion].options.map((option, index) => (
                <div key={index} className="flex items-center space-x-2 p-3 rounded border hover:bg-muted/50">
                  <RadioGroupItem value={option.value} id={`option-${index}`} />
                  <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                    {option.label}
                  </Label>
                </div>
              ))}
            </RadioGroup>
            
            <Button 
              onClick={handleNext} 
              disabled={!selectedAnswer}
              className="w-full"
            >
              {currentQuestion === quizQuestions.length - 1 ? 'Get Results' : 'Next Question'}
            </Button>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}