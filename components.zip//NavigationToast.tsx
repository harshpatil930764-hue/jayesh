import { useEffect, useState } from 'react';
import { Card } from './ui/card';
import { CheckCircle, ExternalLink, ArrowDown } from 'lucide-react';

export function NavigationToast() {
  const [showToast, setShowToast] = useState(false);
  const [examName, setExamName] = useState('');

  useEffect(() => {
    const handleNavigation = (event: CustomEvent) => {
      setExamName(event.detail.examName);
      setShowToast(true);
      
      // Hide toast after 3 seconds
      setTimeout(() => {
        setShowToast(false);
      }, 3000);
    };

    window.addEventListener('navigateToExam', handleNavigation as EventListener);
    
    return () => {
      window.removeEventListener('navigateToExam', handleNavigation as EventListener);
    };
  }, []);

  if (!showToast) return null;

  return (
    <div className="fixed top-4 right-4 z-50 animate-in slide-in-from-right duration-300">
      <Card className="p-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white border-0 shadow-xl max-w-sm">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-white/20 rounded-full">
            <CheckCircle className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <h4 className="font-bold text-sm">Navigating to {examName}</h4>
            <p className="text-white/90 text-xs">Scrolling to detailed exam information...</p>
          </div>
          <ArrowDown className="h-4 w-4 animate-bounce" />
        </div>
      </Card>
    </div>
  );
}