import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { ArrowRight, BookOpen, Target, Users, TrendingUp, Sparkles, Star, Zap } from 'lucide-react';

export function HeroSection() {
  const [isHovered, setIsHovered] = useState(false);

  const stats = [
    { icon: Users, value: '50,000+', label: 'Students Guided', color: 'from-blue-500 to-cyan-500' },
    { icon: BookOpen, value: '200+', label: 'Career Options', color: 'from-green-500 to-emerald-500' },
    { icon: Target, value: '95%', label: 'Success Rate', color: 'from-purple-500 to-pink-500' },
    { icon: TrendingUp, value: '₹8L+', label: 'Avg. Package', color: 'from-orange-500 to-red-500' }
  ];

  const highlights = [
    { text: '🎓 Smart Career Matching', icon: Zap, color: 'bg-blue-100 text-blue-800' },
    { text: '⚡ Instant Insights', icon: Star, color: 'bg-green-100 text-green-800' },
    { text: '🧠 AI-Powered Guidance', icon: Sparkles, color: 'bg-purple-100 text-purple-800' }
  ];

  return (
    <section className="relative py-20 overflow-hidden bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-10 left-10 w-20 h-20 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-full opacity-20 animate-float"></div>
        <div className="absolute top-32 right-20 w-16 h-16 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-20 animate-float" style={{ animationDelay: '1s' }}></div>
        <div className="absolute bottom-20 left-1/4 w-24 h-24 bg-gradient-to-r from-green-400 to-emerald-400 rounded-full opacity-20 animate-float" style={{ animationDelay: '2s' }}></div>
        <div className="absolute bottom-32 right-1/3 w-12 h-12 bg-gradient-to-r from-orange-400 to-red-400 rounded-full opacity-20 animate-float" style={{ animationDelay: '1.5s' }}></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-12">
          {/* Hero badge */}
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white px-6 py-3 rounded-full mb-6 shadow-lg animate-pulse-slow">
            <Sparkles className="h-5 w-5" />
            <span className="font-semibold">🚀 Empowering India's Future Leaders</span>
            <Sparkles className="h-5 w-5" />
          </div>

          {/* Main heading */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
            <span className="block bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent animate-gradient">
              Discover Your Dream
            </span>
            <span className="block text-gray-800 mt-2">
              Career Path
            </span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-4xl mx-auto leading-relaxed">
            Unlock limitless possibilities with personalized career guidance, expert insights into
            <span className="text-transparent bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text font-semibold"> entrance exams</span>, 
            <span className="text-transparent bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text font-semibold"> college rankings</span>, and
            <span className="text-transparent bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text font-semibold"> success strategies</span>
          </p>

          {/* Highlight badges */}
          <div className="flex flex-wrap justify-center gap-3 mb-10">
            {highlights.map((highlight, index) => (
              <Badge key={index} className={`${highlight.color} px-4 py-2 text-sm font-medium border-0 shadow-md`}>
                <highlight.icon className="h-4 w-4 mr-2" />
                {highlight.text}
              </Badge>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white px-8 py-4 text-lg font-semibold shadow-xl transform hover:scale-105 transition-all duration-300"
              onMouseEnter={() => setIsHovered(true)}
              onMouseLeave={() => setIsHovered(false)}
              onClick={() => {
                const element = document.getElementById('college-search');
                if (element) {
                  element.scrollIntoView({ 
                    behavior: 'smooth',
                    block: 'start'
                  });
                }
              }}
            >
              🏫 Find Perfect College
              <ArrowRight className={`h-5 w-5 ml-2 transition-transform duration-300 ${isHovered ? 'translate-x-1' : ''}`} />
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="border-2 border-purple-500 text-purple-700 hover:bg-purple-50 px-8 py-4 text-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
              onClick={() => {
                const element = document.getElementById('career-quiz');
                if (element) {
                  element.scrollIntoView({ 
                    behavior: 'smooth',
                    block: 'start'
                  });
                }
              }}
            >
              <BookOpen className="h-5 w-5 mr-2" />
              🎯 Take Career Quiz
            </Button>
          </div>
        </div>

        {/* Stats section */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
          {stats.map((stat, index) => (
            <Card 
              key={index} 
              className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 bg-white/80 backdrop-blur-sm"
            >
              <CardContent className="pt-6 text-center">
                <div className={`inline-flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-r ${stat.color} mb-4 shadow-lg`}>
                  <stat.icon className="h-6 w-6 text-white" />
                </div>
                <div className="text-2xl lg:text-3xl font-bold text-gray-800 mb-1">
                  {stat.value}
                </div>
                <div className="text-sm text-gray-600 font-medium">
                  {stat.label}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Trust indicators */}
        <div className="text-center mt-16">
          <p className="text-gray-600 mb-6 font-medium">Trusted by students from</p>
          <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
            <div className="px-6 py-3 bg-white/50 rounded-lg backdrop-blur-sm border border-gray-200">
              <span className="font-semibold text-gray-700">Rural Areas</span>
            </div>
            <div className="px-6 py-3 bg-white/50 rounded-lg backdrop-blur-sm border border-gray-200">
              <span className="font-semibold text-gray-700">Tier 2/3 Cities</span>
            </div>
            <div className="px-6 py-3 bg-white/50 rounded-lg backdrop-blur-sm border border-gray-200">
              <span className="font-semibold text-gray-700">Metro Cities</span>
            </div>
            <div className="px-6 py-3 bg-white/50 rounded-lg backdrop-blur-sm border border-gray-200">
              <span className="font-semibold text-gray-700">All Boards</span>
            </div>
          </div>
        </div>

        {/* Announcement banner */}
        <div className="mt-12 max-w-4xl mx-auto">
          <Card className="bg-gradient-to-r from-yellow-400 via-orange-400 to-red-400 text-white border-0 shadow-2xl">
            <CardContent className="pt-6 text-center">
              <div className="flex items-center justify-center gap-2 mb-3">
                <Zap className="h-6 w-6 animate-pulse" />
                <span className="font-bold text-lg">🚨 Latest Updates 2025</span>
                <Zap className="h-6 w-6 animate-pulse" />
              </div>
              <p className="text-white/90 font-medium">
                New JEE Main & NEET cut-offs released! Check the latest trends and college-wise cut-offs for 2024-25.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}