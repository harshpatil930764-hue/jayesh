import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import { Separator } from './ui/separator';
import { 
  GraduationCap,
  Calendar,
  Clock,
  Users,
  DollarSign,
  ExternalLink,
  BookOpen,
  AlertCircle,
  TrendingUp,
  TrendingDown,
  Target,
  Trophy,
  Star,
  BarChart3,
  Building,
  MapPin,
  Zap,
  CheckCircle,
  Calculator,
  Brain,
  Award,
  Sparkles,
  ArrowRight,
  LineChart,
  PieChart,
  Activity
} from 'lucide-react';
import { engineeringExamsData, examStats, preparationTimeline, subjectWiseTips, type ExamDetails, type CutOffTrend, type CollegeCutOff } from '../data/engineeringExamsData';

export function EngineeringExams() {
  const [selectedExam, setSelectedExam] = useState(0);
  const [selectedCutoffCategory, setSelectedCutoffCategory] = useState('all');
  const [highlightedTab, setHighlightedTab] = useState<number | null>(null);

  // Function to highlight exam based on name
  const highlightExamByName = (examName: string) => {
    const examMap: { [key: string]: number } = {
      'JEE Main': 0,
      'MHT CET': 1, 
      'JEE Advanced': 2,
      'BITSAT': 0, // Maps to JEE Main tab as BITSAT info would be there
      'KCET': 1, // Maps to MHT CET tab as state exam
      'COMEDK': 1,
      'WBJEE': 1,
      'GATE': 0
    };
    
    const tabIndex = examMap[examName];
    if (tabIndex !== undefined) {
      setSelectedExam(tabIndex);
      setHighlightedTab(tabIndex);
      
      // Remove highlight after 3 seconds
      setTimeout(() => {
        setHighlightedTab(null);
      }, 3000);
    }
  };

  // Listen for navigation from career streams
  useEffect(() => {
    const handleExamNavigation = (event: CustomEvent) => {
      highlightExamByName(event.detail.examName);
    };

    window.addEventListener('navigateToExam', handleExamNavigation as EventListener);
    
    return () => {
      window.removeEventListener('navigateToExam', handleExamNavigation as EventListener);
    };
  }, []);

  const CutOffChart = ({ cutOffs }: { cutOffs: CutOffTrend[] }) => (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <BarChart3 className="h-5 w-5 text-primary" />
          <h4 className="text-lg font-semibold">Cut-off Trends Analysis</h4>
        </div>
        <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white animate-pulse">
          🔥 Live Data 2024
        </Badge>
      </div>

      <div className="grid gap-4">
        {cutOffs.map((cutoff, index) => (
          <Card key={index} className={`p-4 bg-gradient-to-r ${cutoff.color} text-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105`}>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/20 rounded-lg">
                  {cutoff.trend === 'up' ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                </div>
                <div>
                  <h5 className="font-bold text-lg">{cutoff.category}</h5>
                  <p className="text-white/80 text-sm">
                    Trend: {cutoff.trend === 'up' ? 'Increasing' : cutoff.trend === 'down' ? 'Decreasing' : 'Stable'}
                  </p>
                </div>
              </div>
              {cutoff.expectedCutoff2025 && (
                <div className="text-right">
                  <div className="text-sm text-white/80">Expected 2025</div>
                  <div className="text-xl font-bold">⭐ {cutoff.expectedCutoff2025}</div>
                </div>
              )}
            </div>
            
            <div className="grid grid-cols-4 gap-3">
              <div className="text-center p-2 bg-white/10 rounded-lg">
                <div className="text-xs text-white/70">2024</div>
                <div className="text-lg font-bold">{cutoff.cutoff2024}</div>
              </div>
              <div className="text-center p-2 bg-white/10 rounded-lg">
                <div className="text-xs text-white/70">2023</div>
                <div className="text-sm font-semibold">{cutoff.cutoff2023}</div>
              </div>
              <div className="text-center p-2 bg-white/10 rounded-lg">
                <div className="text-xs text-white/70">2022</div>
                <div className="text-sm font-semibold">{cutoff.cutoff2022}</div>
              </div>
              <div className="text-center p-2 bg-white/10 rounded-lg">
                <div className="text-xs text-white/70">2021</div>
                <div className="text-sm font-semibold">{cutoff.cutoff2021}</div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );

  const CollegeRankings = ({ colleges }: { colleges: CollegeCutOff[] }) => (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-4">
        <Building className="h-5 w-5 text-primary" />
        <h4 className="text-lg font-semibold">Top Colleges & Placements</h4>
        <Badge className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white">
          2024 Data
        </Badge>
      </div>

      <div className="grid gap-4">
        {colleges.map((college, index) => (
          <Card key={index} className="p-4 bg-gradient-to-br from-white to-gray-50 border-2 border-gray-200 hover:border-blue-300 hover:shadow-xl transition-all duration-300">
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-lg ${
                    college.type === 'IIT' ? 'bg-gradient-to-r from-red-500 to-pink-500' :
                    college.type === 'NIT' ? 'bg-gradient-to-r from-blue-500 to-indigo-500' :
                    college.type === 'IIIT' ? 'bg-gradient-to-r from-green-500 to-emerald-500' :
                    college.type === 'State' ? 'bg-gradient-to-r from-orange-500 to-red-500' :
                    'bg-gradient-to-r from-purple-500 to-pink-500'
                  } text-white shadow-lg`}>
                    <Trophy className="h-5 w-5" />
                  </div>
                  <div>
                    <h5 className="font-bold text-lg text-gray-800">{college.collegeName}</h5>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="h-3 w-3" />
                      <span>{college.location}</span>
                      <Separator orientation="vertical" className="h-3" />
                      <span className="font-medium">{college.branch}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1 mb-1">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`h-3 w-3 ${i < Math.floor(college.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                      />
                    ))}
                    <span className="text-sm font-medium ml-1">{college.rating}</span>
                  </div>
                  <Badge className={`${
                    college.type === 'IIT' ? 'bg-red-100 text-red-800' :
                    college.type === 'NIT' ? 'bg-blue-100 text-blue-800' :
                    college.type === 'IIIT' ? 'bg-green-100 text-green-800' :
                    college.type === 'State' ? 'bg-orange-100 text-orange-800' :
                    'bg-purple-100 text-purple-800'
                  }`}>
                    {college.type}
                  </Badge>
                </div>
              </div>

              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                <div className="text-center p-3 bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg border border-green-200">
                  <div className="text-xs text-green-600 font-medium">Opening Rank</div>
                  <div className="text-lg font-bold text-green-700">{college.openingRank.toLocaleString()}</div>
                </div>
                <div className="text-center p-3 bg-gradient-to-br from-red-50 to-pink-50 rounded-lg border border-red-200">
                  <div className="text-xs text-red-600 font-medium">Closing Rank</div>
                  <div className="text-lg font-bold text-red-700">{college.closingRank.toLocaleString()}</div>
                </div>
                <div className="text-center p-3 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-lg border border-blue-200">
                  <div className="text-xs text-blue-600 font-medium">Annual Fees</div>
                  <div className="text-sm font-bold text-blue-700">{college.fees}</div>
                </div>
                <div className="text-center p-3 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg border border-purple-200">
                  <div className="text-xs text-purple-600 font-medium">Placement %</div>
                  <div className="text-lg font-bold text-purple-700">{college.placement.percentage}</div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-gray-50 to-blue-50 p-3 rounded-lg border border-gray-200">
                <div className="flex items-center justify-between text-sm mb-2">
                  <div>
                    <span className="text-gray-600">Average Package: </span>
                    <span className="font-semibold text-green-600">{college.placement.average}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">Highest Package: </span>
                    <span className="font-semibold text-blue-600">{college.placement.highest}</span>
                  </div>
                </div>
                <div className="text-center pt-2 border-t border-gray-200">
                  <Button variant="outline" size="sm" className="bg-white hover:bg-blue-50 text-blue-600 border-blue-300" asChild>
                    <a href={`https://${college.website}`} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-3 w-3 mr-1" />
                      Visit Website
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );

  const ExamCard = ({ exam, index }: { exam: ExamDetails; index: number }) => (
    <Card className={`mb-8 bg-gradient-to-br ${exam.bgGradient} text-white border-0 shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:-translate-y-2`}>
      <CardHeader className="relative overflow-hidden pb-6">
        <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -translate-y-20 translate-x-20"></div>
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/10 rounded-full translate-y-16 -translate-x-16"></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="p-4 bg-white/20 rounded-xl shadow-lg">
                <GraduationCap className="h-8 w-8" />
              </div>
              <div>
                <CardTitle className="text-3xl mb-2">{exam.name}</CardTitle>
                <p className="text-white/90 text-lg">{exam.fullName}</p>
                <Badge className="bg-white/20 text-white border-white/30 mt-2">
                  {exam.examLevel} Level • {exam.conductingBody}
                </Badge>
              </div>
            </div>
            <div className="text-right">
              <Badge className="bg-gradient-to-r from-yellow-400 to-orange-400 text-black border-0 mb-2 text-lg px-4 py-2">
                🎯 {exam.seats.total} Seats
              </Badge>
            </div>
          </div>
          <CardDescription className="text-white/80 text-lg leading-relaxed">
            {exam.description}
          </CardDescription>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        <Accordion type="single" collapsible className="w-full space-y-2">
          {/* Eligibility */}
          <AccordionItem value="eligibility" className="border-0">
            <AccordionTrigger className="text-left bg-white/10 px-6 py-4 rounded-xl hover:bg-white/20 transition-colors">
              <div className="flex items-center gap-3">
                <Users className="h-6 w-6" />
                <span className="font-bold text-lg">Eligibility Criteria</span>
                <Badge className="bg-gradient-to-r from-green-400 to-emerald-400 text-white">
                  Essential
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-6 py-4 bg-white/5 rounded-b-xl">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <Card className="p-4 bg-white/90 text-gray-800 border-0">
                  <h5 className="font-bold text-sm text-blue-700 mb-2 flex items-center gap-2">
                    <BookOpen className="h-4 w-4" />
                    Education
                  </h5>
                  <p className="text-sm">{exam.eligibility.education}</p>
                </Card>
                <Card className="p-4 bg-white/90 text-gray-800 border-0">
                  <h5 className="font-bold text-sm text-green-700 mb-2 flex items-center gap-2">
                    <Target className="h-4 w-4" />
                    Subjects
                  </h5>
                  <p className="text-sm">{exam.eligibility.subjects}</p>
                </Card>
                <Card className="p-4 bg-white/90 text-gray-800 border-0">
                  <h5 className="font-bold text-sm text-orange-700 mb-2 flex items-center gap-2">
                    <BarChart3 className="h-4 w-4" />
                    Percentage
                  </h5>
                  <p className="text-sm">{exam.eligibility.percentage}</p>
                </Card>
                <Card className="p-4 bg-white/90 text-gray-800 border-0">
                  <h5 className="font-bold text-sm text-purple-700 mb-2 flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Attempts
                  </h5>
                  <p className="text-sm">{exam.eligibility.attempts}</p>
                </Card>
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* Important Dates */}
          <AccordionItem value="dates" className="border-0">
            <AccordionTrigger className="text-left bg-white/10 px-6 py-4 rounded-xl hover:bg-white/20 transition-colors">
              <div className="flex items-center gap-3">
                <Calendar className="h-6 w-6" />
                <span className="font-bold text-lg">Important Dates 2025</span>
                <Badge className="bg-gradient-to-r from-blue-400 to-cyan-400 text-white animate-pulse">
                  Updated
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-6 py-4 bg-white/5 rounded-b-xl">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <Card className="p-4 bg-gradient-to-br from-amber-400 to-orange-400 text-white border-0 shadow-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="h-5 w-5" />
                    <div className="font-bold">Notification</div>
                  </div>
                  <div className="text-lg font-semibold">{exam.examSchedule.notification}</div>
                </Card>
                <Card className="p-4 bg-gradient-to-br from-blue-400 to-indigo-400 text-white border-0 shadow-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="h-5 w-5" />
                    <div className="font-bold">Application</div>
                  </div>
                  <div className="text-lg font-semibold">{exam.examSchedule.application}</div>
                </Card>
                <Card className="p-4 bg-gradient-to-br from-green-400 to-emerald-400 text-white border-0 shadow-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <BookOpen className="h-5 w-5" />
                    <div className="font-bold">Exam Dates</div>
                  </div>
                  <div className="text-lg font-semibold">{exam.examSchedule.examDates}</div>
                </Card>
                <Card className="p-4 bg-gradient-to-br from-purple-400 to-pink-400 text-white border-0 shadow-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Trophy className="h-5 w-5" />
                    <div className="font-bold">Result</div>
                  </div>
                  <div className="text-lg font-semibold">{exam.examSchedule.result}</div>
                </Card>
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* Exam Pattern */}
          <AccordionItem value="pattern" className="border-0">
            <AccordionTrigger className="text-left bg-white/10 px-6 py-4 rounded-xl hover:bg-white/20 transition-colors">
              <div className="flex items-center gap-3">
                <Calculator className="h-6 w-6" />
                <span className="font-bold text-lg">Exam Pattern & Structure</span>
                <Badge className="bg-gradient-to-r from-indigo-400 to-purple-400 text-white">
                  Detailed
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-6 py-4 bg-white/5 rounded-b-xl space-y-4">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <Card className="p-4 bg-white/90 text-gray-800 text-center border-0">
                  <h5 className="font-bold text-sm text-blue-700 mb-1">Mode</h5>
                  <p className="text-sm">{exam.examPattern.mode}</p>
                </Card>
                <Card className="p-4 bg-white/90 text-gray-800 text-center border-0">
                  <h5 className="font-bold text-sm text-green-700 mb-1">Duration</h5>
                  <p className="text-sm">{exam.examPattern.duration}</p>
                </Card>
                <Card className="p-4 bg-white/90 text-gray-800 text-center border-0">
                  <h5 className="font-bold text-sm text-orange-700 mb-1">Questions</h5>
                  <p className="text-sm">{exam.examPattern.totalQuestions}</p>
                </Card>
                <Card className="p-4 bg-white/90 text-gray-800 text-center border-0">
                  <h5 className="font-bold text-sm text-purple-700 mb-1">Marks</h5>
                  <p className="text-sm">{exam.examPattern.totalMarks}</p>
                </Card>
              </div>
              
              <Card className="p-4 bg-white/90 text-gray-800 border-0">
                <h5 className="font-bold text-sm text-red-700 mb-2">⚠️ Negative Marking</h5>
                <p className="text-sm">{exam.examPattern.negativeMarking}</p>
              </Card>
              
              <Card className="p-4 bg-white/90 text-gray-800 border-0">
                <h5 className="font-bold text-sm text-indigo-700 mb-2">🌐 Available Languages</h5>
                <div className="flex flex-wrap gap-2">
                  {exam.examPattern.languages.map((lang, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {lang}
                    </Badge>
                  ))}
                </div>
              </Card>
            </AccordionContent>
          </AccordionItem>

          {/* Cut-offs */}
          <AccordionItem value="cutoffs" className="border-0">
            <AccordionTrigger className="text-left bg-gradient-to-r from-orange-400/20 to-red-400/20 px-6 py-4 rounded-xl hover:from-orange-400/30 hover:to-red-400/30 transition-colors border border-orange-300/30">
              <div className="flex items-center gap-3">
                <Target className="h-6 w-6 text-orange-300" />
                <span className="font-bold text-lg">Cut-off Trends & Analysis</span>
                <Badge className="bg-gradient-to-r from-orange-400 to-red-400 text-white animate-bounce">
                  🔥 Hot Topic
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-6 py-4 bg-gradient-to-br from-orange-400/10 to-red-400/10 rounded-b-xl">
              <CutOffChart cutOffs={exam.cutOffTrends} />
            </AccordionContent>
          </AccordionItem>

          {/* Top Colleges */}
          <AccordionItem value="colleges" className="border-0">
            <AccordionTrigger className="text-left bg-gradient-to-r from-blue-400/20 to-indigo-400/20 px-6 py-4 rounded-xl hover:from-blue-400/30 hover:to-indigo-400/30 transition-colors border border-blue-300/30">
              <div className="flex items-center gap-3">
                <Building className="h-6 w-6 text-blue-300" />
                <span className="font-bold text-lg">Top Colleges & Placements</span>
                <Badge className="bg-gradient-to-r from-blue-400 to-indigo-400 text-white">
                  🏆 Premium
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-6 py-4 bg-gradient-to-br from-blue-400/10 to-indigo-400/10 rounded-b-xl">
              <CollegeRankings colleges={exam.topColleges} />
            </AccordionContent>
          </AccordionItem>

          {/* Syllabus */}
          <AccordionItem value="syllabus" className="border-0">
            <AccordionTrigger className="text-left bg-white/10 px-6 py-4 rounded-xl hover:bg-white/20 transition-colors">
              <div className="flex items-center gap-3">
                <Brain className="h-6 w-6" />
                <span className="font-bold text-lg">Detailed Syllabus</span>
                <Badge className="bg-gradient-to-r from-green-400 to-emerald-400 text-white">
                  Complete
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-6 py-4 bg-white/5 rounded-b-xl space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                <Card className="p-4 bg-gradient-to-br from-red-50 to-pink-50 border border-red-200">
                  <h5 className="font-bold text-red-700 mb-3 flex items-center gap-2">
                    <Zap className="h-4 w-4" />
                    Physics
                  </h5>
                  <div className="space-y-1 max-h-40 overflow-y-auto">
                    {exam.syllabus.physics.map((topic, index) => (
                      <Badge key={index} variant="outline" className="text-xs mr-1 mb-1 bg-white/60">
                        {topic}
                      </Badge>
                    ))}
                  </div>
                </Card>
                <Card className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200">
                  <h5 className="font-bold text-green-700 mb-3 flex items-center gap-2">
                    <Activity className="h-4 w-4" />
                    Chemistry
                  </h5>
                  <div className="space-y-1 max-h-40 overflow-y-auto">
                    {exam.syllabus.chemistry.map((topic, index) => (
                      <Badge key={index} variant="outline" className="text-xs mr-1 mb-1 bg-white/60">
                        {topic}
                      </Badge>
                    ))}
                  </div>
                </Card>
                <Card className="p-4 bg-gradient-to-br from-blue-50 to-cyan-50 border border-blue-200">
                  <h5 className="font-bold text-blue-700 mb-3 flex items-center gap-2">
                    <PieChart className="h-4 w-4" />
                    Mathematics
                  </h5>
                  <div className="space-y-1 max-h-40 overflow-y-auto">
                    {exam.syllabus.mathematics.map((topic, index) => (
                      <Badge key={index} variant="outline" className="text-xs mr-1 mb-1 bg-white/60">
                        {topic}
                      </Badge>
                    ))}
                  </div>
                </Card>
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* Preparation Tips */}
          <AccordionItem value="tips" className="border-0">
            <AccordionTrigger className="text-left bg-white/10 px-6 py-4 rounded-xl hover:bg-white/20 transition-colors">
              <div className="flex items-center gap-3">
                <Sparkles className="h-6 w-6" />
                <span className="font-bold text-lg">Expert Preparation Tips</span>
                <Badge className="bg-gradient-to-r from-yellow-400 to-orange-400 text-black">
                  💡 Pro Tips
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-6 py-4 bg-white/5 rounded-b-xl">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div>
                  <h5 className="font-bold text-white mb-3 flex items-center gap-2">
                    <Target className="h-4 w-4" />
                    General Strategy
                  </h5>
                  <div className="space-y-2">
                    {exam.preparationTips.map((tip, index) => (
                      <Card key={index} className="p-3 bg-white/90 text-gray-800 border-0">
                        <div className="flex items-start gap-2">
                          <div className="w-6 h-6 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                            <span className="text-white text-xs font-bold">{index + 1}</span>
                          </div>
                          <span className="text-sm">{tip}</span>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
                <div>
                  <h5 className="font-bold text-white mb-3 flex items-center gap-2">
                    <BookOpen className="h-4 w-4" />
                    Key Information
                  </h5>
                  <div className="space-y-2">
                    {exam.keyInfo.map((info, index) => (
                      <Card key={index} className="p-3 bg-white/90 text-gray-800 border-0">
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                          <span className="text-sm">{info}</span>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* Application Details */}
          <AccordionItem value="application" className="border-0">
            <AccordionTrigger className="text-left bg-white/10 px-6 py-4 rounded-xl hover:bg-white/20 transition-colors">
              <div className="flex items-center gap-3">
                <DollarSign className="h-6 w-6" />
                <span className="font-bold text-lg">Application & Fee Details</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-6 py-4 bg-white/5 rounded-b-xl">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <Card className="p-4 bg-white/90 text-gray-800 border-0">
                  <h5 className="font-bold text-green-700 mb-2">💳 Application Fee</h5>
                  <p className="text-sm">{exam.fees.application}</p>
                  {exam.fees.counseling && (
                    <p className="text-sm mt-2"><strong>Counseling Fee:</strong> {exam.fees.counseling}</p>
                  )}
                </Card>
                <Card className="p-4 bg-white/90 text-gray-800 border-0">
                  <h5 className="font-bold text-blue-700 mb-2">🌐 Official Website</h5>
                  <Button variant="outline" size="sm" className="bg-white hover:bg-blue-50" asChild>
                    <a href={`https://${exam.officialWebsite}`} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-3 w-3 mr-1" />
                      {exam.officialWebsite}
                    </a>
                  </Button>
                </Card>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );

  return (
    <section id="engineering-exams" className="py-20 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-4 rounded-full mb-6 shadow-2xl animate-pulse">
            <GraduationCap className="h-6 w-6" />
            <span className="font-bold text-lg">Engineering Entrance Exams</span>
            <Sparkles className="h-6 w-6" />
          </div>
          <h2 className="text-4xl md:text-6xl mb-6 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent font-black leading-tight">
            JEE Main, MHT CET & More
          </h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Complete guide to engineering entrance exams with latest cut-offs, college rankings, 
            and expert preparation strategies for your engineering career success.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-12 max-w-5xl mx-auto">
          <Card className="text-center p-4 bg-gradient-to-br from-blue-500 to-cyan-500 text-white border-0 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
            <BookOpen className="h-6 w-6 mx-auto mb-2" />
            <div className="text-xl font-bold">{examStats.totalExams}</div>
            <div className="text-xs opacity-90">Major Exams</div>
          </Card>
          <Card className="text-center p-4 bg-gradient-to-br from-green-500 to-emerald-500 text-white border-0 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
            <Users className="h-6 w-6 mx-auto mb-2" />
            <div className="text-xl font-bold">{examStats.totalSeats}</div>
            <div className="text-xs opacity-90">Total Seats</div>
          </Card>
          <Card className="text-center p-4 bg-gradient-to-br from-purple-500 to-pink-500 text-white border-0 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
            <Building className="h-6 w-6 mx-auto mb-2" />
            <div className="text-xl font-bold">{examStats.topColleges}</div>
            <div className="text-xs opacity-90">Top Colleges</div>
          </Card>
          <Card className="text-center p-4 bg-gradient-to-br from-orange-500 to-red-500 text-white border-0 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
            <Trophy className="h-6 w-6 mx-auto mb-2" />
            <div className="text-xl font-bold">{examStats.averagePackage}</div>
            <div className="text-xs opacity-90">Avg Package</div>
          </Card>
          <Card className="text-center p-4 bg-gradient-to-br from-yellow-500 to-orange-500 text-white border-0 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
            <BarChart3 className="h-6 w-6 mx-auto mb-2" />
            <div className="text-xl font-bold">{examStats.successRate}</div>
            <div className="text-xs opacity-90">Success Rate</div>
          </Card>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto">
          <Tabs value={selectedExam.toString()} onValueChange={(value) => setSelectedExam(parseInt(value))}>
            <TabsList className="grid w-full grid-cols-3 mb-8 bg-white/80 backdrop-blur-sm border-2 border-gray-200 shadow-xl">
              {engineeringExamsData.map((exam, index) => (
                <TabsTrigger 
                  key={index} 
                  value={index.toString()} 
                  className={`text-sm font-semibold data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-500 data-[state=active]:to-purple-500 data-[state=active]:text-white transition-all duration-300 py-3 ${
                    highlightedTab === index ? 'animate-pulse bg-gradient-to-r from-yellow-400 to-orange-400 text-white shadow-lg' : ''
                  }`}
                >
                  <GraduationCap className="h-4 w-4 mr-2" />
                  {exam.name}
                </TabsTrigger>
              ))}
            </TabsList>

            {engineeringExamsData.map((exam, index) => (
              <TabsContent key={index} value={index.toString()}>
                <ExamCard exam={exam} index={index} />
              </TabsContent>
            ))}
          </Tabs>
        </div>

        {/* Preparation Timeline */}
        <div className="max-w-4xl mx-auto mt-16">
          <Card className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white border-0 shadow-2xl">
            <CardContent className="pt-8 pb-8">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold mb-2">🚀 Your Engineering Success Timeline</h3>
                <p className="text-white/90">Strategic preparation phases for maximum success</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {preparationTimeline.map((phase, index) => (
                  <Card key={index} className="p-6 bg-white/10 border border-white/20 text-center">
                    <div className="text-3xl mb-4">
                      {index === 0 ? '🏗️' : index === 1 ? '🎯' : '⚡'}
                    </div>
                    <h4 className="font-bold text-lg mb-2">{phase.phase}</h4>
                    <Badge className="bg-white/20 text-white border-white/30 mb-3">
                      {phase.duration}
                    </Badge>
                    <p className="text-sm text-white/80">{phase.focus}</p>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Subject-wise Tips */}
        <div className="max-w-6xl mx-auto mt-12">
          <Card className="bg-gradient-to-br from-yellow-400 via-orange-400 to-red-400 text-white border-0 shadow-2xl">
            <CardContent className="pt-8 pb-8">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold mb-2">📚 Subject-wise Mastery Tips</h3>
                <p className="text-white/90">Expert strategies for each core subject</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="p-6 bg-white/90 text-gray-800 border-0">
                  <div className="text-center mb-4">
                    <div className="text-3xl mb-2">⚡</div>
                    <h4 className="font-bold text-lg text-red-600">Physics</h4>
                  </div>
                  <ul className="space-y-2 text-sm">
                    {subjectWiseTips.physics.map((tip, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </Card>
                
                <Card className="p-6 bg-white/90 text-gray-800 border-0">
                  <div className="text-center mb-4">
                    <div className="text-3xl mb-2">🧪</div>
                    <h4 className="font-bold text-lg text-green-600">Chemistry</h4>
                  </div>
                  <ul className="space-y-2 text-sm">
                    {subjectWiseTips.chemistry.map((tip, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </Card>
                
                <Card className="p-6 bg-white/90 text-gray-800 border-0">
                  <div className="text-center mb-4">
                    <div className="text-3xl mb-2">📊</div>
                    <h4 className="font-bold text-lg text-blue-600">Mathematics</h4>
                  </div>
                  <ul className="space-y-2 text-sm">
                    {subjectWiseTips.mathematics.map((tip, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </Card>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <Card className="max-w-4xl mx-auto bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white border-0 shadow-2xl">
            <CardContent className="pt-8 pb-8">
              <div className="mb-6">
                <h3 className="text-3xl font-bold mb-4">🎯 Ready to Crack Your Engineering Entrance?</h3>
                <p className="text-white/90 text-lg max-w-2xl mx-auto">
                  Get personalized study plans, expert mentorship, and cutting-edge preparation resources 
                  to maximize your chances of success in JEE Main, MHT CET, and other top engineering exams.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="bg-white text-indigo-600 hover:bg-gray-100 font-bold text-lg px-8 py-4">
                  <Target className="h-5 w-5 mr-2" />
                  Get Personal Mentorship
                </Button>
                <Button variant="outline" size="lg" className="border-white text-white hover:bg-white/10 font-bold text-lg px-8 py-4">
                  <ArrowRight className="h-5 w-5 mr-2" />
                  Download Cut-off Analysis
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}