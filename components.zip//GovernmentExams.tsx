import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import { Separator } from './ui/separator';
import { 
  Calendar, 
  Clock, 
  Users, 
  DollarSign, 
  ExternalLink, 
  BookOpen, 
  AlertCircle, 
  TrendingUp, 
  TrendingDown, 
  Minus,
  Trophy,
  Target,
  BarChart3,
  GraduationCap,
  Building,
  Star,
  FileText,
  CheckCircle,
  MapPin,
  Briefcase,
  School,
  Shield,
  IndianRupee,
  Users2,
  Calculator,
  Brain,
  Zap
} from 'lucide-react';
import { examCategoriesData, type ExamDetails, type CutOffData, type SyllabusSection } from '../data/governmentExamsData';

export function GovernmentExams() {
  const [selectedCategory, setSelectedCategory] = useState(0);
  const [highlightedTab, setHighlightedTab] = useState<number | null>(null);

  // Function to highlight exam category based on exam name
  const highlightExamByName = (examName: string) => {
    const examMap: { [key: string]: number } = {
      'CLAT': 1, // Law exams category  
      'NDA': 2, // Defense exams category
      'CDS': 2,
      'UPSC CSE': 0, // Civil services category (moved to 0 since medical is separate)
      'SSC CGL': 0,
      'Bank PO': 3, // Banking category
      'Railway': 0,
      'CAT': 4, // Management category
      'XAT': 4,
      'SNAP': 4,
      'NMAT': 4,
      'BBA Entrance': 4,
      'Hotel Management': 5, // Other category
      'NIFT': 5,
      'NID': 5,
      'JMI': 5,
      'BHU': 5,
      'IIMC': 5,
      'FTII': 5
    };
    
    const tabIndex = examMap[examName];
    if (tabIndex !== undefined) {
      setSelectedCategory(tabIndex);
      setHighlightedTab(tabIndex);
      
      // Remove highlight after 3 seconds
      setTimeout(() => {
        setHighlightedTab(null);
      }, 3000);
    }
  };

  // Listen for navigation from career streams
  useEffect(() => {
    const handleExamNavigation = (event: CustomEvent) => {
      highlightExamByName(event.detail.examName);
    };

    window.addEventListener('navigateToExam', handleExamNavigation as EventListener);
    
    return () => {
      window.removeEventListener('navigateToExam', handleExamNavigation as EventListener);
    };
  }, []);

  const TrendIcon = ({ trend }: { trend: 'up' | 'down' | 'stable' }) => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="h-3 w-3 text-green-600" />;
      case 'down':
        return <TrendingDown className="h-3 w-3 text-red-600" />;
      default:
        return <Minus className="h-3 w-3 text-gray-600" />;
    }
  };

  const CutOffAnalysis = ({ cutOffs }: { cutOffs: CutOffData[] }) => (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-4">
        <BarChart3 className="h-5 w-5 text-primary" />
        <h4 className="text-lg font-semibold">Cut-off Trends Analysis</h4>
        <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white">Live Data</Badge>
      </div>
      <div className="grid gap-3">
        {cutOffs.map((cutoff, index) => (
          <Card key={index} className="p-4 bg-gradient-to-r from-white to-gray-50/50 border-l-4 border-primary hover:shadow-md transition-all duration-300">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Badge className={cutoff.color} variant="secondary">
                  {cutoff.category}
                </Badge>
                <div className="flex items-center gap-1">
                  <TrendIcon trend={cutoff.trend} />
                  <span className={`text-xs font-medium ${
                    cutoff.trend === 'up' ? 'text-green-600' : 
                    cutoff.trend === 'down' ? 'text-red-600' : 'text-gray-600'
                  }`}>
                    {cutoff.trend === 'up' ? 'Increasing' : cutoff.trend === 'down' ? 'Decreasing' : 'Stable'}
                  </span>
                </div>
              </div>
              <div className="flex gap-4 text-sm">
                <div className="text-center p-2 bg-green-50 rounded-lg border border-green-200">
                  <div className="text-xs text-green-600 font-medium">2024</div>
                  <div className="font-bold text-green-700">{cutoff.cutoff2024}</div>
                </div>
                <div className="text-center p-2 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="text-xs text-blue-600 font-medium">2023</div>
                  <div className="font-semibold text-blue-700">{cutoff.cutoff2023}</div>
                </div>
                <div className="text-center p-2 bg-gray-50 rounded-lg border border-gray-200">
                  <div className="text-xs text-gray-600 font-medium">2022</div>
                  <div className="font-semibold text-gray-700">{cutoff.cutoff2022}</div>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );

  const SyllabusBreakdown = ({ syllabus }: { syllabus: SyllabusSection[] }) => (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-4">
        <Brain className="h-5 w-5 text-primary" />
        <h4 className="text-lg font-semibold">Detailed Syllabus Breakdown</h4>
      </div>
      <div className="grid gap-4">
        {syllabus.map((section, index) => (
          <Card key={index} className="p-4 bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-200">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h5 className="font-semibold text-indigo-900">{section.subject}</h5>
                <div className="flex gap-3 text-xs">
                  <Badge variant="outline" className="bg-white/60">
                    {section.marks} marks
                  </Badge>
                  <Badge variant="outline" className="bg-white/60">
                    {section.questions} questions
                  </Badge>
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-sm text-indigo-700 font-medium">Key Topics:</p>
                <div className="flex flex-wrap gap-2">
                  {section.topics.map((topic, topicIndex) => (
                    <Badge key={topicIndex} variant="secondary" className="text-xs bg-white/80 text-indigo-800 border border-indigo-200">
                      {topic}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );

  const SalaryBreakdown = ({ salary }: { salary: ExamDetails['salary'] }) => (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-4">
        <IndianRupee className="h-5 w-5 text-primary" />
        <h4 className="text-lg font-semibold">Salary & Benefits Package</h4>
      </div>
      
      <Card className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200">
        <div className="space-y-4">
          <div>
            <h5 className="font-semibold text-green-800 mb-2">💰 Salary Range</h5>
            <p className="text-lg font-bold text-green-700">{salary.range}</p>
          </div>
          
          <div>
            <h5 className="font-semibold text-green-800 mb-2">🎯 Allowances</h5>
            <div className="flex flex-wrap gap-2">
              {salary.allowances.map((allowance, index) => (
                <Badge key={index} className="bg-green-100 text-green-800 border border-green-300">
                  {allowance}
                </Badge>
              ))}
            </div>
          </div>
          
          <div>
            <h5 className="font-semibold text-green-800 mb-2">🌟 Additional Benefits</h5>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {salary.benefits.map((benefit, index) => (
                <div key={index} className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-green-700">{benefit}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Card>
    </div>
  );

  const PostsReservation = ({ posts }: { posts: ExamDetails['posts'] }) => (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-4">
        <Users2 className="h-5 w-5 text-primary" />
        <h4 className="text-lg font-semibold">Posts & Reservation Details</h4>
      </div>
      
      <Card className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200">
        <div className="space-y-4">
          <div className="text-center p-3 bg-white/60 rounded-lg">
            <h5 className="font-semibold text-blue-800 mb-1">Total Posts</h5>
            <p className="text-2xl font-bold text-blue-700">{posts.total}</p>
          </div>
          
          <div>
            <h5 className="font-semibold text-blue-800 mb-3">Category-wise Reservation</h5>
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
              <div className="text-center p-2 bg-red-50 rounded-lg border border-red-200">
                <div className="text-xs text-red-600 font-medium">General</div>
                <div className="text-sm font-bold text-red-700">{posts.reservation.general}</div>
              </div>
              <div className="text-center p-2 bg-orange-50 rounded-lg border border-orange-200">
                <div className="text-xs text-orange-600 font-medium">OBC</div>
                <div className="text-sm font-bold text-orange-700">{posts.reservation.obc}</div>
              </div>
              <div className="text-center p-2 bg-green-50 rounded-lg border border-green-200">
                <div className="text-xs text-green-600 font-medium">SC</div>
                <div className="text-sm font-bold text-green-700">{posts.reservation.sc}</div>
              </div>
              <div className="text-center p-2 bg-blue-50 rounded-lg border border-blue-200">
                <div className="text-xs text-blue-600 font-medium">ST</div>
                <div className="text-sm font-bold text-blue-700">{posts.reservation.st}</div>
              </div>
              <div className="text-center p-2 bg-yellow-50 rounded-lg border border-yellow-200">
                <div className="text-xs text-yellow-600 font-medium">EWS</div>
                <div className="text-sm font-bold text-yellow-700">{posts.reservation.ews}</div>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );

  const ExamCard = ({ exam }: { exam: ExamDetails }) => (
    <Card className={`mb-8 ${exam.bgColor} border-2 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1`}>
      <CardHeader className="relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full translate-y-12 -translate-x-12"></div>
        <div className="relative z-10">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <div className={`p-2 rounded-lg bg-white/20`}>
                  <Trophy className={`h-6 w-6 ${exam.iconColor}`} />
                </div>
                <div>
                  <CardTitle className={`text-2xl mb-1 ${exam.accentColor}`}>{exam.name}</CardTitle>
                  <p className="text-sm font-medium opacity-80">{exam.fullName}</p>
                </div>
              </div>
              <CardDescription className="text-base font-medium mb-3">{exam.description}</CardDescription>
              <Badge variant="outline" className="bg-white/20 border-white/30">
                {exam.conductingBody}
              </Badge>
            </div>
            <div className="text-right">
              <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white border-0 mb-2">
                💰 {exam.salary.range.split(' ')[0]} - {exam.salary.range.split(' ')[2]}
              </Badge>
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-6">
        <Accordion type="single" collapsible className="w-full">
          {/* Eligibility */}
          <AccordionItem value="eligibility" className="border-0">
            <AccordionTrigger className="text-left bg-white/50 px-4 py-3 rounded-lg hover:bg-white/80 transition-colors">
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-blue-600" />
                <span className="font-semibold">Eligibility Criteria</span>
                <Badge className="bg-blue-100 text-blue-800 ml-2">Essential</Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 py-4 bg-white/30 rounded-b-lg">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="p-3 bg-white/60 border border-blue-200">
                  <h5 className="font-semibold text-sm text-blue-700 mb-2">📚 Education</h5>
                  <p className="text-sm">{exam.eligibility.education}</p>
                </Card>
                <Card className="p-3 bg-white/60 border border-blue-200">
                  <h5 className="font-semibold text-sm text-blue-700 mb-2">🎂 Age Limit</h5>
                  <p className="text-sm">{exam.eligibility.ageLimit}</p>
                </Card>
                <Card className="p-3 bg-white/60 border border-blue-200">
                  <h5 className="font-semibold text-sm text-blue-700 mb-2">🇮🇳 Nationality</h5>
                  <p className="text-sm">{exam.eligibility.nationality}</p>
                </Card>
                {exam.eligibility.attempts && (
                  <Card className="p-3 bg-white/60 border border-blue-200">
                    <h5 className="font-semibold text-sm text-blue-700 mb-2">🔄 Attempts</h5>
                    <p className="text-sm">{exam.eligibility.attempts}</p>
                  </Card>
                )}
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* Important Dates */}
          <AccordionItem value="dates" className="border-0">
            <AccordionTrigger className="text-left bg-white/50 px-4 py-3 rounded-lg hover:bg-white/80 transition-colors">
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-green-600" />
                <span className="font-semibold">Important Dates 2025</span>
                <Badge className="bg-green-100 text-green-800 ml-2">Updated</Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 py-4 bg-white/30 rounded-b-lg">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="p-4 bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="h-4 w-4 text-amber-600" />
                    <div className="text-sm font-semibold text-amber-700">Notification</div>
                  </div>
                  <div className="text-sm font-medium text-amber-800">{exam.examDates.notification}</div>
                </Card>
                <Card className="p-4 bg-gradient-to-br from-blue-50 to-cyan-50 border border-blue-200">
                  <div className="flex items-center gap-2 mb-2">
                    <FileText className="h-4 w-4 text-blue-600" />
                    <div className="text-sm font-semibold text-blue-700">Application</div>
                  </div>
                  <div className="text-sm font-medium text-blue-800">{exam.examDates.application}</div>
                </Card>
                <Card className="p-4 bg-gradient-to-br from-purple-50 to-pink-50 border border-purple-200">
                  <div className="flex items-center gap-2 mb-2">
                    <BookOpen className="h-4 w-4 text-purple-600" />
                    <div className="text-sm font-semibold text-purple-700">Exam Date</div>
                  </div>
                  <div className="text-sm font-medium text-purple-800">{exam.examDates.exam}</div>
                </Card>
                <Card className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200">
                  <div className="flex items-center gap-2 mb-2">
                    <Trophy className="h-4 w-4 text-green-600" />
                    <div className="text-sm font-semibold text-green-700">Result</div>
                  </div>
                  <div className="text-sm font-medium text-green-800">{exam.examDates.result}</div>
                </Card>
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* Exam Pattern */}
          <AccordionItem value="pattern" className="border-0">
            <AccordionTrigger className="text-left bg-white/50 px-4 py-3 rounded-lg hover:bg-white/80 transition-colors">
              <div className="flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-purple-600" />
                <span className="font-semibold">Exam Pattern & Structure</span>
                <Badge className="bg-purple-100 text-purple-800 ml-2">Detailed</Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 py-4 bg-white/30 rounded-b-lg space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="p-3 bg-white/60 border border-purple-200">
                  <h5 className="font-semibold text-sm text-purple-700 mb-1">💻 Mode</h5>
                  <p className="text-sm">{exam.examPattern.mode}</p>
                </Card>
                <Card className="p-3 bg-white/60 border border-purple-200">
                  <h5 className="font-semibold text-sm text-purple-700 mb-1">⏱️ Duration</h5>
                  <p className="text-sm">{exam.examPattern.duration}</p>
                </Card>
                <Card className="p-3 bg-white/60 border border-purple-200">
                  <h5 className="font-semibold text-sm text-purple-700 mb-1">📊 Total Marks</h5>
                  <p className="text-sm font-medium">{exam.examPattern.totalMarks}</p>
                </Card>
                <Card className="p-3 bg-white/60 border border-purple-200">
                  <h5 className="font-semibold text-sm text-purple-700 mb-1">⚠️ Negative Marking</h5>
                  <p className="text-sm">{exam.examPattern.negativeMarking}</p>
                </Card>
              </div>
              
              <div>
                <h5 className="font-semibold text-sm text-purple-700 mb-2">📈 Exam Stages</h5>
                <div className="flex flex-wrap gap-2">
                  {exam.examPattern.stages.map((stage, index) => (
                    <Badge key={index} variant="outline" className="bg-purple-50 border-purple-200 text-purple-800">
                      Stage {index + 1}: {stage}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <div>
                <h5 className="font-semibold text-sm text-purple-700 mb-2">📚 Subjects</h5>
                <div className="flex flex-wrap gap-2">
                  {exam.examPattern.subjects.map((subject, index) => (
                    <Badge key={index} variant="outline" className="bg-blue-50 border-blue-200 text-blue-800">
                      {subject}
                    </Badge>
                  ))}
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* Syllabus */}
          <AccordionItem value="syllabus" className="border-0">
            <AccordionTrigger className="text-left bg-gradient-to-r from-indigo-50 to-purple-50 px-4 py-3 rounded-lg hover:from-indigo-100 hover:to-purple-100 transition-colors border border-indigo-200">
              <div className="flex items-center gap-2">
                <Brain className="h-5 w-5 text-indigo-600" />
                <span className="font-semibold text-indigo-800">Detailed Syllabus</span>
                <Badge className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white ml-2">
                  Complete
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 py-4 bg-gradient-to-br from-indigo-50/50 to-purple-50/50 rounded-b-lg">
              <SyllabusBreakdown syllabus={exam.syllabus} />
            </AccordionContent>
          </AccordionItem>

          {/* Cut-offs */}
          {exam.cutOffs && (
            <AccordionItem value="cutoffs" className="border-0">
              <AccordionTrigger className="text-left bg-gradient-to-r from-orange-50 to-red-50 px-4 py-3 rounded-lg hover:from-orange-100 hover:to-red-100 transition-colors border border-orange-200">
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-orange-600" />
                  <span className="font-semibold text-orange-800">Cut-off Trends & Analysis</span>
                  <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white ml-2">
                    🔥 Trending
                  </Badge>
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-4 py-4 bg-gradient-to-br from-orange-50/50 to-red-50/50 rounded-b-lg">
                <CutOffAnalysis cutOffs={exam.cutOffs} />
              </AccordionContent>
            </AccordionItem>
          )}

          {/* Salary & Benefits */}
          <AccordionItem value="salary" className="border-0">
            <AccordionTrigger className="text-left bg-gradient-to-r from-green-50 to-emerald-50 px-4 py-3 rounded-lg hover:from-green-100 hover:to-emerald-100 transition-colors border border-green-200">
              <div className="flex items-center gap-2">
                <IndianRupee className="h-5 w-5 text-green-600" />
                <span className="font-semibold text-green-800">Salary & Benefits</span>
                <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white ml-2">
                  💰 Detailed
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 py-4 bg-gradient-to-br from-green-50/50 to-emerald-50/50 rounded-b-lg">
              <SalaryBreakdown salary={exam.salary} />
            </AccordionContent>
          </AccordionItem>

          {/* Posts & Reservation */}
          <AccordionItem value="posts" className="border-0">
            <AccordionTrigger className="text-left bg-gradient-to-r from-blue-50 to-indigo-50 px-4 py-3 rounded-lg hover:from-blue-100 hover:to-indigo-100 transition-colors border border-blue-200">
              <div className="flex items-center gap-2">
                <Users2 className="h-5 w-5 text-blue-600" />
                <span className="font-semibold text-blue-800">Posts & Reservation</span>
                <Badge className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white ml-2">
                  📊 Stats
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 py-4 bg-gradient-to-br from-blue-50/50 to-indigo-50/50 rounded-b-lg">
              <PostsReservation posts={exam.posts} />
            </AccordionContent>
          </AccordionItem>

          {/* Application Details */}
          <AccordionItem value="application" className="border-0">
            <AccordionTrigger className="text-left bg-white/50 px-4 py-3 rounded-lg hover:bg-white/80 transition-colors">
              <div className="flex items-center gap-2">
                <Calculator className="h-5 w-5 text-amber-600" />
                <span className="font-semibold">Application Details</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 py-4 bg-white/30 rounded-b-lg">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="p-4 bg-amber-50 border border-amber-200">
                  <h5 className="font-semibold text-amber-800 mb-2">💳 Application Fee</h5>
                  <div className="space-y-1 text-sm">
                    <div><span className="font-medium">General:</span> {exam.applicationFee.general}</div>
                    <div><span className="font-medium">Reserved:</span> {exam.applicationFee.reserved}</div>
                  </div>
                </Card>
                <Card className="p-4 bg-blue-50 border border-blue-200">
                  <h5 className="font-semibold text-blue-800 mb-2">🌐 Official Website</h5>
                  <Button variant="outline" size="sm" className="bg-white hover:bg-blue-50" asChild>
                    <a href={`https://${exam.officialWebsite}`} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-3 w-3 mr-1" />
                      {exam.officialWebsite}
                    </a>
                  </Button>
                </Card>
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* Important Information */}
          <AccordionItem value="info" className="border-0">
            <AccordionTrigger className="text-left bg-white/50 px-4 py-3 rounded-lg hover:bg-white/80 transition-colors">
              <div className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-yellow-600" />
                <span className="font-semibold">Key Success Tips</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 py-4 bg-white/30 rounded-b-lg">
              <div className="space-y-3">
                {exam.importantInfo.map((info, index) => (
                  <Card key={index} className="p-3 bg-gradient-to-r from-yellow-50 to-amber-50 border border-yellow-200">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 bg-gradient-to-r from-yellow-400 to-amber-400 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-white text-xs font-bold">{index + 1}</span>
                      </div>
                      <span className="text-sm text-amber-800">{info}</span>
                    </div>
                  </Card>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );

  return (
    <section id="government-exams" className="py-20 bg-gradient-to-br from-gray-50 via-blue-50/30 to-purple-50/30">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-indigo-500 to-purple-500 text-white px-6 py-3 rounded-full mb-4 shadow-lg animate-pulse-slow">
            <Trophy className="h-5 w-5" />
            <span className="font-semibold">Complete Government Exams Guide</span>
            <Zap className="h-5 w-5" />
          </div>
          <h2 className="text-4xl md:text-5xl mb-4 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent font-bold">
            All Government Exams 2025
          </h2>
          <p className="text-lg text-muted-foreground max-w-4xl mx-auto">
            Comprehensive guide covering all major central and state government examinations with latest cut-offs, 
            detailed syllabus, salary information, and expert preparation strategies.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12 max-w-4xl mx-auto">
          <Card className="text-center p-4 bg-gradient-to-br from-blue-500 to-cyan-500 text-white border-0 shadow-lg">
            <div className="text-2xl font-bold">50+</div>
            <div className="text-sm opacity-90">Exams Covered</div>
          </Card>
          <Card className="text-center p-4 bg-gradient-to-br from-green-500 to-emerald-500 text-white border-0 shadow-lg">
            <div className="text-2xl font-bold">1000+</div>
            <div className="text-sm opacity-90">Questions Analyzed</div>
          </Card>
          <Card className="text-center p-4 bg-gradient-to-br from-purple-500 to-pink-500 text-white border-0 shadow-lg">
            <div className="text-2xl font-bold">Live</div>
            <div className="text-sm opacity-90">Cut-off Updates</div>
          </Card>
          <Card className="text-center p-4 bg-gradient-to-br from-orange-500 to-red-500 text-white border-0 shadow-lg">
            <div className="text-2xl font-bold">100%</div>
            <div className="text-sm opacity-90">Accurate Data</div>
          </Card>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto">
          <Tabs value={selectedCategory.toString()} onValueChange={(value) => setSelectedCategory(parseInt(value))}>
            <TabsList className="grid w-full grid-cols-2 lg:grid-cols-7 mb-8 bg-white/80 backdrop-blur-sm border border-gray-200 shadow-lg">
              {examCategoriesData.map((category, index) => (
                <TabsTrigger 
                  key={index} 
                  value={index.toString()} 
                  className={`text-xs lg:text-sm data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-500 data-[state=active]:to-purple-500 data-[state=active]:text-white transition-all duration-300 font-medium ${
                    highlightedTab === index ? 'animate-pulse bg-gradient-to-r from-yellow-400 to-orange-400 text-white shadow-lg' : ''
                  }`}
                >
                  <category.icon className="h-4 w-4 mr-1 lg:mr-2" />
                  <span className="hidden sm:inline">{category.title}</span>
                </TabsTrigger>
              ))}
            </TabsList>

            {examCategoriesData.map((category, categoryIndex) => (
              <TabsContent key={categoryIndex} value={categoryIndex.toString()}>
                {/* Category Header */}
                <div className="mb-8">
                  <Card className={`bg-gradient-to-r ${category.categoryColor} text-white border-0 shadow-2xl`}>
                    <CardContent className="pt-6 pb-6">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="p-4 bg-white/20 rounded-xl shadow-lg">
                          <category.icon className="h-8 w-8" />
                        </div>
                        <div>
                          <h3 className="text-3xl font-bold mb-2">{category.title}</h3>
                          <p className="text-white/90 text-lg">{category.description}</p>
                        </div>
                      </div>
                      <div className="bg-white/10 rounded-lg p-4">
                        <div className="flex items-center gap-2 text-sm">
                          <Star className="h-4 w-4" />
                          <span>Updated with latest 2025 notifications and cut-offs</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Exams List */}
                <div className="space-y-8">
                  {category.exams.map((exam, examIndex) => (
                    <ExamCard key={examIndex} exam={exam} />
                  ))}
                </div>

                {/* Category-specific Tips */}
                <Card className="mt-8 bg-gradient-to-r from-yellow-400 via-orange-400 to-red-400 text-white border-0 shadow-2xl">
                  <CardContent className="pt-6 pb-6">
                    <div className="flex items-start gap-4">
                      <div className="p-3 bg-white/20 rounded-xl">
                        <Zap className="h-6 w-6" />
                      </div>
                      <div>
                        <h4 className="font-bold text-xl mb-3">
                          {categoryIndex === 0 && "Central Government Exam Success Strategy"}
                          {categoryIndex === 1 && "State PSC Preparation Tips"}
                          {categoryIndex === 2 && "Railway Exam Mastery Guide"}
                          {categoryIndex === 3 && "Banking Exam Excellence Tips"}
                          {categoryIndex === 4 && "Defense Service Preparation"}
                          {categoryIndex === 5 && "Teaching Exam Success"}
                          {categoryIndex === 6 && "Police Exam Victory Plan"}
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-white/90">
                          <div>
                            <h5 className="font-semibold mb-2">🎯 Preparation Focus</h5>
                            <ul className="text-sm space-y-1">
                              {categoryIndex === 0 && (
                                <>
                                  <li>• Current affairs from last 12 months essential</li>
                                  <li>• Practice previous year papers extensively</li>
                                  <li>• Focus on conceptual clarity over rote learning</li>
                                  <li>• Time management crucial for success</li>
                                </>
                              )}
                              {categoryIndex === 1 && (
                                <>
                                  <li>• State-specific GK carries high weightage</li>
                                  <li>• Regional language knowledge advantageous</li>
                                  <li>• Local current affairs very important</li>
                                  <li>• Mock tests with state-level questions</li>
                                </>
                              )}
                              {categoryIndex === 2 && (
                                <>
                                  <li>• Strong mathematics foundation required</li>
                                  <li>• Railway-specific technical knowledge</li>
                                  <li>• Physical fitness for certain posts</li>
                                  <li>• Multiple RRB applications possible</li>
                                </>
                              )}
                              {categoryIndex === 3 && (
                                <>
                                  <li>• Banking awareness and current affairs</li>
                                  <li>• Computer knowledge increasingly important</li>
                                  <li>• Interview preparation crucial</li>
                                  <li>• Economic survey and budget analysis</li>
                                </>
                              )}
                              {categoryIndex === 4 && (
                                <>
                                  <li>• Physical and medical fitness mandatory</li>
                                  <li>• Leadership qualities assessed in SSB</li>
                                  <li>• National security awareness important</li>
                                  <li>• Communication skills crucial</li>
                                </>
                              )}
                              {categoryIndex === 5 && (
                                <>
                                  <li>• Child psychology and pedagogy focus</li>
                                  <li>• Teaching methodologies important</li>
                                  <li>• Subject knowledge depth required</li>
                                  <li>• Practical teaching experience helps</li>
                                </>
                              )}
                              {categoryIndex === 6 && (
                                <>
                                  <li>• Physical efficiency test preparation</li>
                                  <li>• Law and constitution knowledge</li>
                                  <li>• Local language proficiency needed</li>
                                  <li>• Character verification important</li>
                                </>
                              )}
                            </ul>
                          </div>
                          <div>
                            <h5 className="font-semibold mb-2">🏆 Success Factors</h5>
                            <ul className="text-sm space-y-1">
                              <li>• Consistent daily study routine</li>
                              <li>• Regular revision and self-assessment</li>
                              <li>• Joining test series for practice</li>
                              <li>• Staying updated with latest changes</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <Card className="max-w-4xl mx-auto bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white border-0 shadow-2xl">
            <CardContent className="pt-8 pb-8">
              <div className="flex items-center justify-center gap-3 mb-4">
                <div className="p-3 bg-white/20 rounded-xl">
                  <Users className="h-6 w-6" />
                </div>
                <h3 className="text-2xl font-bold">Ready to Start Your Government Job Journey?</h3>
              </div>
              <p className="text-white/90 mb-6 max-w-2xl mx-auto">
                Get personalized guidance, study plans, and expert mentorship to crack your target government exam. 
                Our counselors have helped thousands of students achieve their dreams.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100 font-semibold">
                  <Target className="h-4 w-4 mr-2" />
                  Get Personal Mentorship
                </Button>
                <Button variant="outline" size="lg" className="border-white text-white hover:bg-white/10">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Download Study Material
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}