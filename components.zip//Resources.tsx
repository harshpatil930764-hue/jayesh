import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import { Separator } from './ui/separator';
import { ExternalLink, Star, Users, Clock, CheckCircle, Lightbulb } from 'lucide-react';
import { resourcesData, studyTips, type Resource } from '../data/resourcesData';

export function Resources() {
  const [selectedCategory, setSelectedCategory] = useState(0);

  const ResourceCard = ({ resource }: { resource: Resource }) => (
    <Card className="mb-4">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg">{resource.title}</CardTitle>
            <CardDescription className="mt-1">{resource.description}</CardDescription>
          </div>
          <div className="flex flex-col gap-2 ml-4">
            <Badge 
              variant={resource.type === 'free' ? 'default' : resource.type === 'government' ? 'secondary' : 'outline'}
              className="text-xs"
            >
              {resource.type === 'free' ? 'Free' : resource.type === 'government' ? 'Government' : 'Paid'}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible>
          <AccordionItem value="details">
            <AccordionTrigger className="text-left">
              <span className="text-sm">View Details</span>
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-4">
                <div>
                  <h5 className="font-medium text-sm text-muted-foreground mb-2">Key Features</h5>
                  <ul className="space-y-1">
                    {resource.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm">
                        <CheckCircle className="h-3 w-3 text-green-600 mt-1 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h5 className="font-medium text-sm text-muted-foreground mb-2">Best For</h5>
                  <div className="flex flex-wrap gap-1">
                    {resource.suitableFor.map((suit, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {suit}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h5 className="font-medium text-sm text-muted-foreground mb-2">Available Languages</h5>
                  <div className="flex flex-wrap gap-1">
                    {resource.language.map((lang, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {lang}
                      </Badge>
                    ))}
                  </div>
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Category: {resource.category}</span>
                  <Button variant="outline" size="sm" asChild>
                    <a href={resource.link} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-3 w-3 mr-1" />
                      Visit
                    </a>
                  </Button>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );

  return (
    <section id="resources" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl mb-4">Study Resources & Materials</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Comprehensive collection of free and paid resources to support your academic journey and career preparation.
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <Tabs value={selectedCategory.toString()} onValueChange={(value) => setSelectedCategory(parseInt(value))}>
            <TabsList className="grid w-full grid-cols-2 lg:grid-cols-6 mb-8">
              {resourcesData.map((category, index) => (
                <TabsTrigger key={index} value={index.toString()} className="text-xs lg:text-sm">
                  <category.icon className="h-4 w-4 mr-1 lg:mr-2" />
                  <span className="hidden sm:inline">{category.title}</span>
                </TabsTrigger>
              ))}
            </TabsList>

            {resourcesData.map((category, categoryIndex) => (
              <TabsContent key={categoryIndex} value={categoryIndex.toString()}>
                <div className="mb-6">
                  <div className="flex items-center gap-3 mb-4">
                    <category.icon className="h-6 w-6 text-primary" />
                    <h3 className="text-2xl font-semibold">{category.title}</h3>
                  </div>
                  <p className="text-muted-foreground">{category.description}</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {category.resources.map((resource, resourceIndex) => (
                    <ResourceCard key={resourceIndex} resource={resource} />
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>

        <div className="max-w-4xl mx-auto mt-16">
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-xl flex items-center gap-2">
                <Lightbulb className="h-5 w-5 text-yellow-600" />
                Study Tips & Strategies
              </CardTitle>
              <CardDescription>
                Expert advice to make your learning more effective and efficient
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {studyTips.map((tipCategory, index) => (
                  <div key={index}>
                    <h4 className="font-medium mb-3 text-blue-900">{tipCategory.category}</h4>
                    <ul className="space-y-2">
                      {tipCategory.tips.map((tip, tipIndex) => (
                        <li key={tipIndex} className="flex items-start gap-2 text-sm text-blue-800">
                          <Star className="h-3 w-3 text-yellow-500 mt-1 flex-shrink-0" />
                          <span>{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-12">
          <Card className="max-w-3xl mx-auto">
            <CardContent className="pt-6">
              <h3 className="text-xl font-semibold mb-4">Need More Help?</h3>
              <p className="text-muted-foreground mb-6">
                Our education counselors are here to help you navigate through these resources and create a personalized study plan.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg">
                  <Users className="h-4 w-4 mr-2" />
                  Contact Counselor
                </Button>
                <Button variant="outline" size="lg">
                  <Clock className="h-4 w-4 mr-2" />
                  Schedule Call
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}