import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Separator } from './ui/separator';
import { CheckCircle, XCircle, Target, TrendingUp, Clock, Users, BookOpen, AlertCircle, Sparkles, Zap, Star, Rocket, Brain, Heart } from 'lucide-react';
import { streamsData, postTwelfthOptions, type StreamData, type StreamOption } from '../data/careerStreamsData';

export function CareerStreams() {
  const [selectedStream, setSelectedStream] = useState(0);

  // Enhanced colorful stream configurations
  const streamConfigs = [
    {
      bgGradient: 'bg-gradient-to-br from-blue-400 via-blue-500 to-blue-600',
      cardBg: 'bg-gradient-to-br from-blue-50 via-cyan-50 to-blue-100',
      accentColor: 'text-blue-600',
      iconBg: 'bg-gradient-to-r from-blue-500 to-cyan-500',
      shadowColor: 'shadow-blue-200',
      emoji: '🔬',
      title: 'Science Stream',
      subtitle: 'Innovation & Discovery'
    },
    {
      bgGradient: 'bg-gradient-to-br from-green-400 via-emerald-500 to-green-600',
      cardBg: 'bg-gradient-to-br from-green-50 via-emerald-50 to-green-100',
      accentColor: 'text-green-600',
      iconBg: 'bg-gradient-to-r from-green-500 to-emerald-500',
      shadowColor: 'shadow-green-200',
      emoji: '💼',
      title: 'Commerce Stream',
      subtitle: 'Business & Finance'
    },
    {
      bgGradient: 'bg-gradient-to-br from-purple-400 via-pink-500 to-purple-600',
      cardBg: 'bg-gradient-to-br from-purple-50 via-pink-50 to-purple-100',
      accentColor: 'text-purple-600',
      iconBg: 'bg-gradient-to-r from-purple-500 to-pink-500',
      shadowColor: 'shadow-purple-200',
      emoji: '🎨',
      title: 'Arts & Humanities',
      subtitle: 'Creativity & Society'
    }
  ];

  // Navigation function to scroll to exam section
  const navigateToExam = (examName: string) => {
    // Map exam names to their corresponding sections
    const examSectionMap: { [key: string]: string } = {
      'JEE Main': 'engineering-exams',
      'JEE Advanced': 'engineering-exams', 
      'BITSAT': 'engineering-exams',
      'MHT CET': 'engineering-exams',
      'KCET': 'engineering-exams',
      'COMEDK': 'engineering-exams',
      'WBJEE': 'engineering-exams',
      'GATE': 'engineering-exams',
      'NEET': 'medical-exams',
      'NEET UG': 'medical-exams',
      'AIIMS': 'medical-exams',
      'AIIMS INI-CET': 'medical-exams',
      'JIPMER': 'medical-exams',
      'FMGE': 'medical-exams',
      'CLAT': 'government-exams',
      'NDA': 'government-exams',
      'CDS': 'government-exams',
      'UPSC CSE': 'government-exams',
      'SSC CGL': 'government-exams',
      'Bank PO': 'government-exams',
      'Railway': 'government-exams',
      'CAT': 'government-exams',
      'XAT': 'government-exams',
      'SNAP': 'government-exams',
      'NMAT': 'government-exams',
      'BBA Entrance': 'government-exams',
      'Hotel Management': 'government-exams',
      'NIFT': 'government-exams',
      'NID': 'government-exams',
      'JMI': 'government-exams',
      'BHU': 'government-exams',
      'IIMC': 'government-exams',
      'FTII': 'government-exams'
    };

    const sectionId = examSectionMap[examName];
    if (sectionId) {
      // Dispatch custom event to highlight specific exam
      const navigationEvent = new CustomEvent('navigateToExam', {
        detail: { examName }
      });
      window.dispatchEvent(navigationEvent);

      // Smooth scroll to section
      setTimeout(() => {
        const element = document.getElementById(sectionId);
        if (element) {
          element.scrollIntoView({ 
            behavior: 'smooth',
            block: 'start'
          });
          
          // Add a visual highlight effect to section
          element.style.boxShadow = '0 0 20px rgba(99, 102, 241, 0.5)';
          setTimeout(() => {
            element.style.boxShadow = '';
          }, 3000);
        }
      }, 100);
    }
  };

  const CareerOptionCard = ({ career, streamIndex }: { career: StreamOption; streamIndex: number }) => {
    const config = streamConfigs[streamIndex];
    return (
      <Card className={`mb-4 ${config.cardBg} border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1`}>
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-lg font-bold">{career.name}</CardTitle>
              <CardDescription className="text-gray-700 mt-1">{career.description}</CardDescription>
            </div>
            <div className={`${config.iconBg} p-2 rounded-full`}>
              <Star className="h-5 w-5 text-white" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h5 className="font-semibold text-sm text-gray-700 mb-2 flex items-center gap-1">
                <Zap className="h-4 w-4" />
                Entrance Exams
              </h5>
              <div className="flex flex-wrap gap-2">
                {career.entranceExams.map((exam, index) => (
                  <Badge 
                    key={index} 
                    className={`${config.iconBg} text-white border-0 text-xs font-medium shadow-md cursor-pointer hover:scale-105 transition-transform duration-200 hover:shadow-lg`}
                    onClick={() => navigateToExam(exam)}
                    data-track="exam-navigate"
                  >
                    {exam}
                  </Badge>
                ))}
              </div>
              <p className="text-xs text-gray-500 mt-2 italic">
                💡 Click on any exam to get detailed information!
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/60 rounded-lg p-3 border border-white/50">
                <h5 className="font-semibold text-sm text-gray-700 mb-1 flex items-center gap-1">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                  Average Salary
                </h5>
                <p className="font-bold text-green-600">{career.averageSalary}</p>
              </div>
              <div className="bg-white/60 rounded-lg p-3 border border-white/50">
                <h5 className="font-semibold text-sm text-gray-700 mb-1 flex items-center gap-1">
                  <Target className="h-4 w-4 text-blue-600" />
                  Job Market
                </h5>
                <p className="font-medium text-blue-600">{career.jobProspects.split(' - ')[0]}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  const StreamDetailCard = ({ stream, streamIndex }: { stream: StreamData; streamIndex: number }) => {
    const config = streamConfigs[streamIndex];
    
    return (
      <div className="space-y-6">
        {/* Main Stream Card */}
        <Card className={`${config.cardBg} border-0 shadow-2xl overflow-hidden`}>
          <div className={`${config.bgGradient} p-6 text-white relative overflow-hidden`}>
            {/* Decorative elements */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full translate-y-12 -translate-x-12"></div>
            
            <div className="relative z-10">
              <div className="flex items-start gap-4">
                <div className="text-6xl">{config.emoji}</div>
                <div className="flex-1">
                  <h2 className="text-3xl font-bold mb-2">{config.title}</h2>
                  <p className="text-xl text-white/90 mb-4">{config.subtitle}</p>
                  <p className="text-white/80 text-lg leading-relaxed">{stream.description}</p>
                </div>
              </div>
              
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white/20 rounded-lg p-4 backdrop-blur-sm">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="h-5 w-5" />
                    <span className="font-semibold">Duration</span>
                  </div>
                  <p className="text-white/90">{stream.duration}</p>
                </div>
                <div className="bg-white/20 rounded-lg p-4 backdrop-blur-sm">
                  <div className="flex items-center gap-2 mb-2">
                    <BookOpen className="h-5 w-5" />
                    <span className="font-semibold">Eligibility</span>
                  </div>
                  <p className="text-white/90">{stream.eligibility}</p>
                </div>
              </div>
            </div>
          </div>
          
          <CardContent className="p-6">
            <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg p-4 border border-orange-200">
              <div className="flex items-center gap-2 mb-2">
                <Rocket className="h-5 w-5 text-orange-600" />
                <h4 className="font-bold text-orange-800">Career Scope & Future</h4>
              </div>
              <p className="text-orange-700">{stream.scope}</p>
            </div>
          </CardContent>
        </Card>

        {/* Advantages & Challenges */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200 border-2 shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2 text-green-800">
                <CheckCircle className="h-6 w-6 text-green-600" />
                ✨ Amazing Advantages
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {stream.advantages.map((advantage, index) => (
                  <li key={index} className="flex items-start gap-3 text-sm">
                    <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle className="h-4 w-4 text-white" />
                    </div>
                    <span className="text-green-800 font-medium">{advantage}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-red-50 to-pink-50 border-red-200 border-2 shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2 text-red-800">
                <AlertCircle className="h-6 w-6 text-red-600" />
                ⚠️ Challenges to Consider
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {stream.challenges.map((challenge, index) => (
                  <li key={index} className="flex items-start gap-3 text-sm">
                    <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <AlertCircle className="h-4 w-4 text-white" />
                    </div>
                    <span className="text-red-800 font-medium">{challenge}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>

        {/* Best Suited For */}
        <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200 border-2 shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2 text-blue-800">
              <Brain className="h-6 w-6 text-blue-600" />
              🎯 Perfect For Students Who...
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {stream.bestFor.map((trait, index) => (
                <div key={index} className="flex items-center gap-3 bg-white/60 rounded-lg p-3">
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                    <Heart className="h-5 w-5 text-white" />
                  </div>
                  <span className="text-blue-800 font-medium">{trait}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Career Options */}
        <div>
          <div className="text-center mb-6">
            <h3 className="text-2xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent mb-2">
              🚀 Exciting Career Pathways
            </h3>
            <p className="text-gray-600">Explore the amazing opportunities waiting for you!</p>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {stream.careers.map((career, index) => (
              <CareerOptionCard key={index} career={career} streamIndex={streamIndex} />
            ))}
          </div>
        </div>
      </div>
    );
  };

  return (
    <section id="career-streams" className="py-20 bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
      <div className="container mx-auto px-4">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-orange-500 to-pink-500 text-white px-6 py-3 rounded-full mb-6 shadow-lg">
            <Sparkles className="h-5 w-5" />
            <span className="font-bold">Choose Your Future After 10th</span>
            <Sparkles className="h-5 w-5" />
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
            <span className="block bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              Discover Your Perfect
            </span>
            <span className="block text-gray-800 mt-2">Academic Stream! 🎓</span>
          </h2>
          
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Each stream opens doors to incredible opportunities. Find the path that matches your 
            <span className="text-transparent bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text font-semibold"> interests</span>, 
            <span className="text-transparent bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text font-semibold"> strengths</span>, and 
            <span className="text-transparent bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text font-semibold"> dreams!</span>
          </p>
        </div>

        {/* Colorful Stream Tabs */}
        <div className="max-w-6xl mx-auto">
          <Tabs value={selectedStream.toString()} onValueChange={(value) => setSelectedStream(parseInt(value))}>
            <TabsList className="grid w-full grid-cols-3 mb-8 bg-white/80 backdrop-blur-sm p-2 shadow-xl rounded-2xl border-0">
              {streamsData.map((stream, index) => {
                const config = streamConfigs[index];
                return (
                  <TabsTrigger 
                    key={index} 
                    value={index.toString()} 
                    className={`
                      text-sm font-semibold rounded-xl transition-all duration-300 data-[state=active]:shadow-lg
                      ${selectedStream === index 
                        ? `${config.bgGradient} text-white data-[state=active]:text-white` 
                        : 'text-gray-600 hover:bg-gray-100'
                      }
                    `}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{config.emoji}</span>
                      <div className="text-left">
                        <div className="font-bold">{config.title}</div>
                        <div className="text-xs opacity-80">{config.subtitle}</div>
                      </div>
                    </div>
                  </TabsTrigger>
                );
              })}
            </TabsList>

            {streamsData.map((stream, index) => (
              <TabsContent key={index} value={index.toString()}>
                <StreamDetailCard stream={stream} streamIndex={index} />
              </TabsContent>
            ))}
          </Tabs>
        </div>

        {/* After 12th Options */}
        <div className="max-w-5xl mx-auto mt-20">
          <Card className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white border-0 shadow-2xl overflow-hidden">
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMjAiIGN5PSIyMCIgcj0iMiIgZmlsbD0iI2ZmZmZmZiIgZmlsbC1vcGFjaXR5PSIwLjEiLz4KPC9zdmc+')] opacity-30"></div>
            
            <CardHeader className="relative z-10 text-center">
              <div className="flex items-center justify-center gap-2 mb-4">
                <Rocket className="h-8 w-8 animate-bounce" />
                <CardTitle className="text-3xl font-bold">🎊 What Happens After 12th?</CardTitle>
                <Rocket className="h-8 w-8 animate-bounce" />
              </div>
              <CardDescription className="text-white/90 text-lg">
                Amazing opportunities await you regardless of your stream choice!
              </CardDescription>
            </CardHeader>
            
            <CardContent className="relative z-10">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white/20 rounded-xl p-6 backdrop-blur-sm">
                  <h4 className="font-bold mb-4 flex items-center gap-2 text-xl">
                    <Users className="h-6 w-6" />
                    🎯 Immediate Options
                  </h4>
                  <ul className="space-y-2">
                    {postTwelfthOptions.immediate.map((option, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <div className="w-2 h-2 bg-yellow-300 rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-white/90">{option}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="bg-white/20 rounded-xl p-6 backdrop-blur-sm">
                  <h4 className="font-bold mb-4 flex items-center gap-2 text-xl">
                    <BookOpen className="h-6 w-6" />
                    🏆 Competitive Exams
                  </h4>
                  <ul className="space-y-2">
                    {postTwelfthOptions.competitive.map((option, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <div className="w-2 h-2 bg-green-300 rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-white/90">{option}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="bg-white/20 rounded-xl p-6 backdrop-blur-sm">
                  <h4 className="font-bold mb-4 flex items-center gap-2 text-xl">
                    <AlertCircle className="h-6 w-6" />
                    🌟 Alternative Paths
                  </h4>
                  <ul className="space-y-2">
                    {postTwelfthOptions.alternative.map((option, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <div className="w-2 h-2 bg-pink-300 rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-white/90">{option}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              
              <Separator className="my-8 bg-white/30" />
              
              <div className="text-center">
                <p className="text-white/90 mb-6 text-lg">
                  💡 Remember: Your stream choice doesn't limit your dreams! Many successful people have switched fields and created their own unique paths.
                </p>
                <Button 
                  size="lg" 
                  className="bg-white text-purple-600 hover:bg-gray-100 px-8 py-4 text-lg font-bold shadow-xl transform hover:scale-105 transition-all duration-300"
                  onClick={() => {
                    const element = document.getElementById('career-quiz');
                    if (element) {
                      element.scrollIntoView({ 
                        behavior: 'smooth',
                        block: 'start'
                      });
                    }
                  }}
                  data-track="quiz-start"
                >
                  🎯 Take Our Career Assessment
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}